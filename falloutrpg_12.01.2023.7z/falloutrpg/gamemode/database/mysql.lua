/*FO.MySQL = {
	EnableMySQL = true,
	Host = '127.0.0.1',
	Username = 'root',
	Password = '',
	Database_name = 'fallout_rpg',
	Database_port = 3306,
	Preferred_module = 'mysqloo'
}

MySQLite.initialize(rp.MySQL)*/