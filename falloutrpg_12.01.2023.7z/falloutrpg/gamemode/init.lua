AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')
include('shared.lua')

function GM:PlayerLoadout(ply)
    ply:SetupHands()
	ply:SetJumpPower(FO.JumpPower)
    ply:SetRunSpeed(FO.RunSpeed)
	ply:SetWalkSpeed(FO.WalkSpeed)
end

AddCSLuaFile(GM.FolderName..'/gamemode/config/cfg.lua')
AddCSLuaFile(GM.FolderName..'/gamemode/config/jobs.lua')

include(GM.FolderName..'/gamemode/config/cfg.lua')
include(GM.FolderName..'/gamemode/config/jobs.lua')

--[[function GM:GravGunPunt(ply, ent)

	if (ent:GetClass() == 'ammo_sispenser') then
		return false
	end

	return true

end]]
