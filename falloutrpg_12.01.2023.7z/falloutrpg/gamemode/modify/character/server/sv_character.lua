util.AddNetworkString('CharacterCreate')
util.AddNetworkString('CharacterMenu')
util.AddNetworkString('SendBodygroups')

local Meta = FindMetaTable('Player')

function Meta:SetRRModel(mdl)
	self:SetModel(mdl)
	self:SetNWString('RPModel', self:GetModel())
end

function Meta:SaveRPModel()
	local mdl = self:GetRPModel()

	self:SetPData('RPModel', mdl)
end

function Meta:GetSaveRPModel()
	return self:GetPData('RPModel')
end

net.Receive('CharacterCreate', function( len, ply )
	local mdl = net.ReadString()
	
	ply:SetRRModel(mdl)
end)

net.Receive( 'SendBodygroups', function( len, ply )
	local tab = net.ReadTable()

	hook.Run( 'EditPlayerBodyGroups', tab[1], tab[2], ply )

	ply:SetBodygroup(tab[1], tab[2])
end)

/*
function MenuCharacter(ply)
	net.Start('CharacterMenu')
		net.WriteEntity(ply)
	net.Send(ply)
end
hook.Add ('ShowSpare1', 'MenuCharacter', MenuCharacter)
*/