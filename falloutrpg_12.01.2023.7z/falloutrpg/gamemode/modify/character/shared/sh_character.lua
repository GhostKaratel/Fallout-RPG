local Meta = FindMetaTable('Player')

function Meta:GetRPModel()
	return self:GetNWString('RPModel')
end