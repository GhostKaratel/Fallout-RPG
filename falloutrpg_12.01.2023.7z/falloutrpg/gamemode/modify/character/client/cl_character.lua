net.Receive('CharacterMenu', function(ply)

    local ply = net.ReadEntity()
    
    local jobsTable = ply:GetJob(ply:Team())
    local models = jobsTable.models
    local bodygroups = ply:GetBodyGroups()

    local CharacterMenu = vgui.Create('DFrame')
    CharacterMenu:SetSize(ScrW(), ScrH())
    CharacterMenu:Center()
    CharacterMenu:SetTitle('')
    CharacterMenu:SetDraggable(false)
    CharacterMenu:ShowCloseButton(true)
    CharacterMenu:MakePopup()
    CharacterMenu.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,245))
        FO.BackgroundBlur(self, 8)
        draw.RoundedBox(0, w/4, h/6, w/2, h/1.5, Color(20,22,25,255)) 
    end 
        
    local mdl = CharacterMenu:Add('DModelPanel')
    mdl:SetSize(ScrW()/3.5, ScrH()/1.5)
    mdl:SetPos(ScrW()/4, ScrH()/6)
    mdl:SetFOV( 15 )
    mdl:SetCamPos( Vector( 95, 0, 60 ) )
    mdl:SetDirectionalLight( BOX_RIGHT, Color( 48, 151, 93, 200 ) )
    mdl:SetDirectionalLight( BOX_LEFT, Color( 240, 170, 80, 255 ) )
    mdl:SetAmbientLight( Vector( -64, -64, -64 ) )
    mdl:SetLookAt( Vector( -300, 0, 80 ) )
    mdl:SetModel(LocalPlayer():GetModel())
    function mdl:LayoutEntity( ent )
    end    

    local CharacterPanel = vgui.Create('DPanel', CharacterMenu)
    CharacterPanel:SetSize(ScrW(), ScrH())
    CharacterPanel:Center()  
    CharacterPanel.Paint = function(self,w,h)
        FO.Image( w/2 - surface.ScreenWidth()/2, h/2 - surface.ScreenHeight()/2,surface.ScreenWidth(), surface.ScreenHeight(), color_white, 'main/robco.png') 
    end  

    CharacterTabs = vgui.Create('DLabel', CharacterMenu)
    CharacterTabs:SetSize(CharacterMenu:GetWide()/6, CharacterMenu:GetTall()/10)
    CharacterTabs:SetPos(CharacterMenu:GetWide()/1.72, CharacterMenu:GetTall()/3.8) 
    CharacterTabs:SetFont( 'CH_BTN' )
    CharacterTabs:SetTextColor( Color( 240, 170, 80) )

    function Sex()
        CharacterTabs:SetText( '1. Пол' )

        local CharacterMale = vgui.Create('DButton',CharacterMenu)
        CharacterMale:SetText('')
        CharacterMale:SetPos(CharacterMenu:GetWide()/1.74, CharacterMenu:GetTall()/2.85) 
        CharacterMale:SetSize(75, 35)
        CharacterMale.Paint = function( self, w, h )
            if self:IsHovered() then 
                draw.RoundedBox(0, 6, h-24, 12, 12, Color(240,170,80))
                surface.SetDrawColor(240,170,80)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            draw.SimpleText('Муж.', 'CH_BTN', w, h/2, Color(240,170,80), 2, 1)
        end
    
        CharacterMale.DoClick = function() 
            net.Start('CharacterCreate')
                net.WriteString( models[1] )
            net.SendToServer()

            mdl:SetModel(models[1])
        end 

        local CharacterFemale = vgui.Create('DButton',CharacterMenu)
        CharacterFemale:SetText('')
        CharacterFemale:SetPos(CharacterMenu:GetWide()/1.74, CharacterMenu:GetTall()/2.5) 
        CharacterFemale:SetSize(75, 35)
        CharacterFemale.Paint = function( self, w, h )
            if self:IsHovered() then 
                draw.RoundedBox(0, 6, h-24, 12, 12, Color(240,170,80))
                surface.SetDrawColor(240,170,80)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            draw.SimpleText('Жен.', 'CH_BTN', w, h/2, Color(240,170,80), 2, 1)
        end
    
        CharacterFemale.DoClick = function() 
            net.Start('CharacterCreate')
                net.WriteString( models[2] )
            net.SendToServer()

            mdl:SetModel(models[2])
        end 

        local CharacterNext = vgui.Create('DButton',CharacterMenu)
        CharacterNext:SetText('')
        CharacterNext:SetPos(CharacterMenu:GetWide()/1.61, CharacterMenu:GetTall()/1.45) 
        CharacterNext:SetSize(100, 35)
        CharacterNext.Paint = function( self, w, h )
            if self:IsHovered() then 
                surface.SetDrawColor(240,170,80)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            draw.SimpleText('Вперёд', 'CH_BTN', w/2, h/2, Color(240,170,80), 1, 1)
        end
    
        CharacterNext.DoClick = function() 
            Face()
            CharacterNext:Remove()
            CharacterFemale:Remove()
            CharacterMale:Remove()
        end 
    
    end

    function Face()
        CharacterTabs:SetText( '2. Внешность' )

        CharacterFaceSettings = vgui.Create('DPanel', CharacterMenu)
        CharacterFaceSettings:SetSize(CharacterMenu:GetWide()/6.7, CharacterMenu:GetTall()/3.5)
        CharacterFaceSettings:SetPos(CharacterMenu:GetWide()/1.75, CharacterMenu:GetTall()/3) 
        CharacterFaceSettings.Paint = function( self, w, h )
        end

        for _, v in ipairs(bodygroups) do
            if v.num > 1 then
                local bgslider = CharacterFaceSettings:Add('DNumSlider')

                local curbg = ply:GetBodygroup( v.id )
                local ent = mdl:GetEntity()

                ent:SetBodygroup( v.id, curbg )

                bgslider.bg = v

                bgslider:Dock( TOP )
                bgslider:DockMargin( 5, 10, 5, 10 )
                bgslider:SetText( v.name )
                bgslider:SetMinMax( 0, v.num - 1 )
                bgslider:SetDecimals( 0 )
                bgslider:SetValue( curbg )
                function bgslider:Paint(w,h)		
                    draw.RoundedBox(0, 0, h/2 - 3, w, 3, Color(240,170,80))
                end	

                bgslider.PerformLayout = function()
                    bgslider:GetTextArea():SetWide(0)
                    bgslider.Label:SetWide(0)
                    bgslider.Slider:SetPos(0,0)
                    bgslider.Slider.Knob:SetSize(5,25)
                    bgslider.Slider.Paint = function( self, w, h ) end
                    bgslider.Slider.Knob.Paint = function( self, w, h ) 
                        draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80))
                    end
                end  

                function bgslider:OnValueChanged( value )
                    local val = math.Round(value)

                    ent:SetBodygroup( v.id, val )

                    net.Start('SendBodygroups')
                        net.WriteTable( { v.id, val } )
                    net.SendToServer()
                end
            end
        end        

        local CharacterFace = vgui.Create('DButton',CharacterMenu)
        CharacterFace:SetText('')
        CharacterFace:SetPos(CharacterMenu:GetWide()/1.62, CharacterMenu:GetTall()/1.45) 
        CharacterFace:SetSize(125, 35)
        CharacterFace.Paint = function( self, w, h )
            if self:IsHovered() then 
                surface.SetDrawColor(240,170,80)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            draw.SimpleText('Завершить', 'CH_BTN', w/2, h/2, Color(240,170,80), 1, 1)
        end
    
        CharacterFace.DoClick = function() 
            CharacterMenu:Remove()
        end 
    
    end

    Sex()

end)