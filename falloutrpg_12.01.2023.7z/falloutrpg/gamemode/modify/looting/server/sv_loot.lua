local nets_loot = {
    'inv_loot_request',
    'inv_loot_panel',
    'inv_loot_give',
    'inv_loot_give_cl',
    'inv_loot_remove',
    'inv_loot_remove_cl',
    'inv_loot_all',
    'inv_loot_refresh',
}

for k, v in ipairs(nets_loot) do
    util.AddNetworkString(v)
end

function FO.CreateLooting()
    for k, v in pairs(FO.LT.Lootable) do
        local LTEntity = ents.Create('base_lootable')
        LTEntity:SetPos(v.pos)
        LTEntity:SetAngles(v.ang)
        LTEntity:Spawn()
        LTEntity:SetInt(v.classname)
    end
end
--hook.Add("InitPostEntity", "FO.CreateLooting", FO.CreateLooting) 

concommand.Add('CreateLOOT', function()
    FO.CreateLooting()
end)

net.Receive( 'inv_loot_give', function(len, ply)
    local ent = net.ReadEntity()
    local item = net.ReadTable()

    if not item then return end

	local entLOOT = ent.FO.LOOT

    if !entLOOT[1] then
        table.insert(entLOOT, {
            classname = item.classname, 
            amount = item.amount or 1,
            condition = item.condition,
            price = item.price
        })
    else
        for k, v in pairs(entLOOT) do 
            if v.classname == item.classname and v.condition == item.condition and v.price == item.price then
                v.amount = v.amount + item.amount
                
                break
            elseif not ent:FOHasLoot(item.classname, item.amount, item.condition, item.price) then
                table.insert(entLOOT, {
                    classname = item.classname, 
                    amount = item.amount or 1,
                    condition = item.condition,
                    price = item.price
                })

                break
            end
        end
    end

    ply:INVremoveitem(item)

    net.Start('inv_loot_give_cl')
        net.WriteTable(entLOOT)
        net.WriteEntity(ent)
    net.Send(ply)

    net.Start('inv_loot_panel')
        net.WriteEntity(ent)
    net.Send(ply)
end )

net.Receive( 'inv_loot_all', function(len, ply)
    local ent = net.ReadEntity()
    local ITEMtable = net.ReadTable()
    local ITEMdata
    local weight 

    if not ITEMtable then return end

	local entLOOT = ent.FO.LOOT
    local plyINV = ply.FO.INV

    for key, item in pairs(ITEMtable) do 

        ITEMdata = FO.INV.Items[item.classname]

        if !plyINV[1] then
            table.insert(plyINV, {
                classname = item.classname, 
                amount = item.amount  or 1,
                condition = item.condition,
                price = item.price
            })
        else
            for k, v in pairs(plyINV) do 
                if v.classname == item.classname and v.condition == item.condition and v.price == item.price then
                    v.amount = v.amount + (item.amount or 1)
                    
                    break
                elseif not ply:FOHasItem(item.classname, item.amount, item.condition, item.price) then
                    table.insert(plyINV, {
                        classname = item.classname, 
                        amount = item.amount or 1,
                        condition = item.condition,
                        price = item.price
                    })
            
                    break
                end
            end
        end

        weight = ITEMdata.weight * (item.amount or 1)

        ply:AddWeight(weight)
        CheckWeight(ply)
    end

    net.Start('inv_loot_panel')
        net.WriteEntity(ent)
    net.Send(ply)

    net.Start('inv_give')
        net.WriteTable(plyINV)
    net.Send(ply)
end )

net.Receive( 'inv_loot_remove', function(len, ply)
    local ent = net.ReadEntity()
    local item = net.ReadTable()

    local entLOOT = ent.FO.LOOT

    for k, v in pairs(entLOOT) do
        if v.classname == item.classname and v.condition == item.condition and v.price == item.price then
            if entLOOT[k] != nil and tonumber(v.amount) >= 1 then
                v.amount = v.amount - item.amount
            end

            if entLOOT[k] != nil and tonumber(v.amount) <= 0 then
                table.remove( entLOOT, k )
            end
        end
    end

    ply:INVpickup(item.classname, item.amount, item.condition, item.price)

    net.Start('inv_loot_remove_cl')
        net.WriteTable(item)
        net.WriteEntity(ent)
    net.Send(ply)

    net.Start('inv_loot_panel')
        net.WriteEntity(ent)
    net.Send(ply)
end )

net.Receive('inv_loot_refresh', function(len, ply)
    local ent = net.ReadEntity()
    
    net.Start('inv_loot_refresh')
        net.WriteEntity(ent)
    net.Send(ply)

    net.Start('inv_loot_panel')
        net.WriteEntity(ent)
    net.Send(ply)

    ent.FO = {LOOT = {}}
end)

--[[timer.Create( 'SpawnLOOT', FO.LT.Timer, 0, function() 
    for k, v in pairs( ents.GetAll() ) do
        if IsValid(v) and v.Loot and #v.FO.LOOT < 3 then
            v:CreateLOOT() 
        end
    end
end )]]