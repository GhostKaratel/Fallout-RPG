net.Receive('inv_loot_refresh', function(len, ply)
    ent = net.ReadEntity()

    ent.FO = {LOOT = {}}
end)

net.Receive('inv_loot_give_cl', function(len, ply)
    local ITEMdata = net.ReadTable()
    local ent = net.ReadEntity()
    if not ITEMdata then return end
    if not ent.FO.LOOT then return end
    local entLOOT = ent.FO.LOOT

    table.Merge(entLOOT, ITEMdata)
end)

net.Receive('inv_loot_remove_cl', function(len, ply)
    local ITEMdata = net.ReadTable()
    local ent = net.ReadEntity()
    if not ITEMdata then return end
    local entLOOT = ent.FO.LOOT

    for k, v in pairs(entLOOT) do
        if v.classname == ITEMdata.classname and v.condition == ITEMdata.condition and v.price == ITEMdata.price then
            if entLOOT[k] != nil and tonumber(v.amount) >= 1 then
                v.amount = v.amount - ITEMdata.amount
            end

            if entLOOT[k] != nil and tonumber(v.amount) <= 0 then
                table.remove( entLOOT, k )
            end
        end
    end
end)

function FO.GetTabs(num)
    return FO.LT.CategoryTabs[num]
end

local function LootDerma(ent)
    local ENTdata = FO.LT.Lootable[ent.classname]
    local entLOOT = ent.FO.LOOT
    local ply = LocalPlayer()
    local plyINV = ply.FO.INV
    local ItemChosen
    local PARENT
    local KeyINV = 1
    local KeyENT = 1
    local Nw,Nh
    local Ew,Eh
    local ITab = FO.GetTabs(KeyINV)
    local ETab = FO.GetTabs(KeyENT)
    local INVName
    local ENTName
         
	if IsValid(FO.LT.LootDerma) then
		FO.LT.LootDerma:Remove()
	end

    FO.LT.LootDerma = vgui.Create('DFrame')
    local LOOT = FO.LT.LootDerma
    LOOT:SetTitle('')
    LOOT:SetSize(1024, 768)
    LOOT:Center()
    LOOT:MakePopup()
    LOOT:ShowCloseButton(false)
    LOOT:SetVisible(true)
    LOOT:SetDraggable(false)   
    LOOT.Paint = function(self,w,h) 
        draw.RoundedBox(0, 0, 0, w, h, Color(40,25,15,200))
        FO.BackgroundBlur(self, 8)

        FO.Image( 15, 22, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
        FO.Image( w-17, 22, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
        FO.Image( 15, h-148, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
        FO.Image( w-17, h-148, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
        FO.Image( w/2-31, 22, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
        FO.Image( w/2+5, 22, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
        FO.Image( 15, h/1.5-32, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
        FO.Image( w/2-31, h/1.5-32, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
        FO.Image( w/2+5, h/1.5-32, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
        FO.Image( w-17, h/1.5-32, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_top.png') 

        draw.RoundedBox(0, 15, 22, 30, 2, Color(240,170,80))
        draw.RoundedBox(0, 15, h-20, w-30, 2, Color(240,170,80))
        draw.RoundedBox(0, Nw + 115, 22, w/4 - Nw + 110, 2, Color(240,170,80))
        draw.RoundedBox(0, w/2+5, 22, 22, 2, Color(240,170,80))
        draw.RoundedBox(0, Ew + w/1.5 - 75, 22, w/3.5 - Ew + 110, 2, Color(240,170,80))
        draw.RoundedBox(0, 15, h/1.5+15, w/2.185, 2, Color(240,170,80))
        draw.RoundedBox(0, w/2+5, h/1.5+15, w/2.1+5, 2, Color(240,170,80))

        draw.SimpleText( LocalPlayer():GetWeight()..'/'..LocalPlayer():GetMaxWeight(), 'INFO_F4', w/2 - 40, 40, Color(240,170,80), 2, 1)   
    end   

    function LOOT:OnKeyCodePressed() 
        if input.IsKeyDown( KEY_E ) then
            LOOT:Remove()
        end
    end                      

    function RefreshTabs()

        if KeyINV == 1 then INVName = ply:GetRPName() else INVName = ITab.name end
        if KeyENT == 1 then ENTName = ent.Name else ENTName = ETab.name end

        if PARENT then
            PARENT:Remove()
            PARENT = nil
        end

        PARENT = vgui.Create('DPanel', LOOT)
        PARENT:SetPos(0,0)
        PARENT:SetSize(LOOT:GetWide(),LOOT:GetTall())
        PARENT.Paint = function(self, w, h) end

        surface.SetFont( 'CATEGORY_F4' )
        local pW, pH = surface.GetTextSize( INVName )
        local eW, eH = surface.GetTextSize( ENTName)

        local PLAYER = vgui.Create('DLabel', PARENT)
        PLAYER:SetPos(80,0)
        PLAYER:SetSize(pW,pH)
        PLAYER:SetText( INVName )
        PLAYER:SetFont('CATEGORY_F4')
        PLAYER:SetTextColor(Color(240,170,80))
        PLAYER:IsVisible()

        local ENTITY = vgui.Create('DLabel', PARENT)
        ENTITY:SetPos(PARENT:GetWide()/2 + 60,0)
        ENTITY:SetSize(eW,eH)
        ENTITY:SetText( ENTName )
        ENTITY:SetFont('CATEGORY_F4')
        ENTITY:SetTextColor(Color(240,170,80))
        ENTITY:IsVisible()

        Nw,Nh = PLAYER:GetWide(), PLAYER:GetTall()
        Ew,Eh = ENTITY:GetWide(), ENTITY:GetTall()

        local Scroll = PARENT:Add('DScrollPanel')
        Scroll:Dock(LEFT)
        Scroll:DockMargin(25,65,0,PARENT:GetTall()/3)
        Scroll:SetWide(PARENT:GetWide()/2.3)
        Scroll.panels = {}
        Scroll.VBar:SetSize(0,0)
        function Scroll:Paint( w, h ) end

        local Scroll2 = PARENT:Add('DScrollPanel')
        Scroll2:Dock(RIGHT)
        Scroll2:DockMargin(0,65,25,PARENT:GetTall()/3)
        Scroll2:SetWide(PARENT:GetWide()/2.3 + 25)
        Scroll2.panels = {}
        Scroll2.VBar:SetSize(0,0)
        function Scroll2:Paint( w, h ) end

        for k, v in pairs(entLOOT) do 
    
            local ITEMdata = FO.INV.Items[v.classname]
            
            if ETab.type == 'all' then 
            elseif ITEMdata.type ~= ETab.type then 
                continue 
            end
    
            local Item2 = vgui.Create('DButton', Scroll2)
            Item2:Dock(TOP)
            Item2:SetSize(0,40)
            Item2:DockMargin(0,0,0,5)
            Item2:SetText('')
            Item2.Paint = function(self, w, h)	
                if self:IsHovered() then 
                    draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))
    
                    surface.SetDrawColor(240,170,80)
                    surface.DrawOutlinedRect(0, 0, w, h)
                end
    
                if tonumber(v.amount) > 1 then
                    draw.SimpleText(ITEMdata.name..' ('..v.amount..')', 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
                else
                    draw.SimpleText(ITEMdata.name, 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
                end
            end
    
            Item2.DoClick = function()
                if tonumber(v.amount) >= 5 then
					local type = 'loot_remove'

					ItemSelect(ITEMdata, k, v, type, ent)
				elseif tonumber(v.amount) < 5 then
					local ITEMtabl = {
						classname = v.classname, 
						amount = 1,
						condition = v.condition,
						price = v.price
					}

                    net.Start('inv_loot_remove')
                        net.WriteEntity(ent)
                        net.WriteTable(ITEMtabl)
                    net.SendToServer()
				end
            end 
    
            Item2.OnCursorEntered = function() 
                ItemChosen(ITEMdata, k, v)
            end

            Scroll2.panels[Item2] = true
        end
    
        for k, v in pairs(plyINV) do 
    
            local ITEMdata = FO.INV.Items[v.classname]

            if ITab.type == 'all' then 
            elseif ITEMdata.type ~= ITab.type then 
                continue 
            end
    
            local Item = vgui.Create('DButton', Scroll)
            Item:Dock(TOP)
            Item:SetSize(0,40)
            Item:DockMargin(0,0,0,5)
            Item:SetText('')
            Item.Paint = function(self, w, h)	
                if self:IsHovered() then 
                    draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))
    
                    surface.SetDrawColor(240,170,80)
                    surface.DrawOutlinedRect(0, 0, w, h)
                end
    
                if tonumber(v.amount) > 1 then
                    draw.SimpleText(ITEMdata.name..' ('..v.amount..')', 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
                else
                    draw.SimpleText(ITEMdata.name, 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
                end
            end
    
            Item.DoClick = function() 
                if tonumber(v.amount) >= 5 then
					local type = 'loot_give'

					ItemSelect(ITEMdata, k, v, type, ent)
				elseif tonumber(v.amount) < 5 then
					local ITEMtabl = {
						classname = v.classname, 
						amount = 1,
						condition = v.condition,
						price = v.price
					}

                    net.Start('inv_loot_give')
                        net.WriteEntity(ent)
                        net.WriteTable(ITEMtabl)
                    net.SendToServer()
				end
            end 
    
            Item.OnCursorEntered = function() 
                ItemChosen(ITEMdata, k, v)
            end

            Scroll.panels[Item] = true
        end

        function ItemChosen(ITEMdata, k, v)

            if ChosenPanel then
                ChosenPanel:Remove()
                ChosenPanel = nil
            end

            ChosenPanel = vgui.Create('DPanel', LOOT)
            ChosenPanel:Dock(BOTTOM)
            ChosenPanel:SetTall(200)
            ChosenPanel:DockMargin(20, 25, 125, 25)
            ChosenPanel:SetAlpha(0)
            ChosenPanel:AlphaTo(255, 0.3, 0) 
            ChosenPanel:InvalidateParent(true)
            function ChosenPanel:Paint(w, h)
                FO.Image( 0, -20, 256, 256, Color(240,170,80), ITEMdata.material )

                if v.condition and ITEMdata.type ~= 'aid' and ITEMdata.type ~= 'misc' and ITEMdata.type ~= 'ammo' then
                    local CND = v.condition
                    CND = CND * (58/100)

                    draw.RoundedBox(0, w/4, 25, 110, 2, Color(240,170,80))
                    FO.Image( w/2.7+5, 25, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

                    draw.SimpleText('CND', 'INV_DESC', w/3.95, 28, Color(240,170,80), 0, 0)
                    draw.RoundedBox(0, w/3.3, 35, 58, 15, Color(240,170,80,25))
                    draw.RoundedBox(0, w/3.3, 35, CND, 15, Color(240,170,80))
                end

                if ITEMdata.damage then
                    draw.RoundedBox(0, w/4, h/3, 110, 2, Color(240,170,80))
                    FO.Image( w/2.7+5, h/3, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

                    draw.SimpleText('DAM', 'INV_DESC', w/3.95, h/3+2, Color(240,170,80), 0, 0)
                    draw.SimpleText(ITEMdata.damage, 'INV_DESC', w/2.8+10, h/3+2, Color(240,170,80), 2, 0)
                end

                if ITEMdata.dthreshold then
                    draw.RoundedBox(0, w/4, h/3, 110, 2, Color(240,170,80))
                    FO.Image( w/2.7+5, h/3, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

                    draw.SimpleText('DT', 'INV_DESC', w/3.95, h/3+2, Color(240,170,80), 0, 0)
                    draw.SimpleText(ITEMdata.dthreshold, 'INV_DESC', w/2.8+10, h/3+2, Color(240,170,80), 2, 0)
                end

                if ITEMdata.weight then
                    draw.RoundedBox(0, w/2.6, 25, 110, 2, Color(240,170,80))
                    FO.Image( w/2+10, 25, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

                    draw.SimpleText('WG', 'INV_DESC', w/2.6+5, 28, Color(240,170,80), 0, 0)
                    draw.SimpleText(ITEMdata.weight, 'INV_DESC', w/2+2, 28, Color(240,170,80), 2, 0)
                end

                if ITEMdata.class then
                    draw.RoundedBox(0, w/2.6, h/3, w/2.4+5, 2, Color(240,170,80))
                    FO.Image( w/1.24, h/3, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

                    draw.SimpleText(ITEMdata.class, 'INV_DESC', w/2.6+5, h/3+2, Color(240,170,80), 0, 0)
                end

                if v.price then
                    draw.RoundedBox(0, w/1.925, 25, 250, 2, Color(240,170,80))
                    FO.Image( w/1.24, 25, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
                    
                    draw.SimpleText('WAL', 'INV_DESC', w/1.9, 28, Color(240,170,80), 0, 0)
                    draw.SimpleText(v.price, 'INV_DESC', w/1.255, 28, Color(240,170,80), 2, 0)
                end
            end 
        end

        local InvSwitchNextButton = vgui.Create( 'DButton', PARENT )
        InvSwitchNextButton:SetText( '' )
        InvSwitchNextButton:SetPos( PLAYER:GetWide() + 85, 9 )
        InvSwitchNextButton:SetSize( 25, 25 )
        InvSwitchNextButton.Paint = function(self, w, h)
            if self:IsHovered() then 
                draw.SimpleText('►', 'TITLE_F4', w/2, h/2, Color(255,255,255), 1, 1)	
            else
                draw.SimpleText('►', 'TITLE_F4', w/2, h/2, Color(240,170,80), 1, 1)	
            end
        end
        
        InvSwitchNextButton.DoClick = function()
            KeyINV = KeyINV + 1

            if KeyINV > #FO.LT.CategoryTabs then
                KeyINV = 1
            end

            ITab = FO.GetTabs(KeyINV)

            RefreshTabs()
        end

        local InvSwitchEarlyButton = vgui.Create( 'DButton', PARENT )
        InvSwitchEarlyButton:SetText( '' )
        InvSwitchEarlyButton:SetPos( 50, 9 )
        InvSwitchEarlyButton:SetSize( 25, 25 )
        InvSwitchEarlyButton.Paint = function(self, w, h)
            if self:IsHovered() then 
                draw.SimpleText('◄', 'TITLE_F4', w/2, h/2, Color(255,255,255), 1, 1)	
            else
                draw.SimpleText('◄', 'TITLE_F4', w/2, h/2, Color(240,170,80), 1, 1)	
            end
        end
        
        InvSwitchEarlyButton.DoClick = function()
            KeyINV = KeyINV - 1

            if KeyINV < 1 then
                KeyINV = #FO.LT.CategoryTabs
            end

            ITab = FO.GetTabs(KeyINV)

            RefreshTabs()
        end

        local LootSwitchNextButton = vgui.Create( 'DButton', PARENT )
        LootSwitchNextButton:SetText( '' )
        LootSwitchNextButton:SetPos( PARENT:GetWide()/2 + ENTITY:GetWide() + 65, 9 )
        LootSwitchNextButton:SetSize( 25, 25 )
        LootSwitchNextButton.Paint = function(self, w, h)
            if self:IsHovered() then 
                draw.SimpleText('►', 'TITLE_F4', w/2, h/2, Color(255,255,255), 1, 1)	
            else
                draw.SimpleText('►', 'TITLE_F4', w/2, h/2, Color(240,170,80), 1, 1)	
            end
        end
        
        LootSwitchNextButton.DoClick = function()
            KeyENT = KeyENT + 1

            if KeyENT > #FO.LT.CategoryTabs then
                KeyENT = 1
            end

            ETab = FO.GetTabs(KeyENT)

            RefreshTabs()        
        end

        local LootSwitchEarlyButton = vgui.Create( 'DButton', PARENT )
        LootSwitchEarlyButton:SetText( '' )
        LootSwitchEarlyButton:SetPos( PARENT:GetWide()/2 + 30, 9 )
        LootSwitchEarlyButton:SetSize( 25, 25 )
        LootSwitchEarlyButton.Paint = function(self, w, h)
            if self:IsHovered() then 
                draw.SimpleText('◄', 'TITLE_F4', w/2, h/2, Color(255,255,255), 1, 1)	
            else
                draw.SimpleText('◄', 'TITLE_F4', w/2, h/2, Color(240,170,80), 1, 1)	
            end
        end
        
        LootSwitchEarlyButton.DoClick = function()
            KeyENT = KeyENT - 1

            if KeyENT < 1 then
                KeyENT = #FO.LT.CategoryTabs
            end

            ETab = FO.GetTabs(KeyENT)

            RefreshTabs()
        end

        
    local TakeAllButton = vgui.Create( 'DButton', PARENT )
	TakeAllButton:SetText( '' )
	TakeAllButton:SetPos( PARENT:GetWide()-140, PARENT:GetTall()-220 )
	TakeAllButton:SetSize( 135, 30 )
	TakeAllButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))

			surface.SetDrawColor(240,170,80)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		
		draw.SimpleText('Take everything A)', 'INV_NAME', w-5, h/2, Color(240,170,80), 2, 1)	
	end
	
	TakeAllButton.DoClick = function()
		net.Start('inv_loot_all')
            net.WriteEntity(ent)
			net.WriteTable(entLOOT)
		net.SendToServer()

        net.Start('inv_loot_refresh')
            net.WriteEntity(ent)
		net.SendToServer()
	end

    local CloseButton = vgui.Create( 'DButton', PARENT )
	CloseButton:SetText( '' )
	CloseButton:SetPos( PARENT:GetWide()-70, PARENT:GetTall()-185 )
	CloseButton:SetSize( 65, 30 )
	CloseButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))

			surface.SetDrawColor(240,170,80)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		
		draw.SimpleText('Close E)', 'INV_NAME', w-5, h/2, Color(240,170,80), 2, 1)	
	end
	
	CloseButton.DoClick = function()
		LOOT:Remove()
	end

    end
end

net.Receive( 'inv_loot_panel', function()
    local ent = net.ReadEntity()

	LootDerma(ent)
    RefreshTabs()
end )