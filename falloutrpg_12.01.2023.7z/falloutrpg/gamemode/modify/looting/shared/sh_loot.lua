FO.LT = FO.LT or {}
FO.LT.Lootable  = {}

FO.LT.Timer = 10

FO.LT.CategoryTabs = {
    [1] = {name = 'All', type = 'all'}, 
    [2] = {name = 'Weapons', type = 'weapon'}, 
    [3] = {name = 'Apparel', type = 'apparel'}, 
    [4] = {name = 'Aid', type = 'aid'}, 
    [5] = {name = 'Misc', type = 'misc'}, 
    [6] = {name = 'Ammo', type = 'ammo'}, 
}

FO.LT.Spawn = {
    'weapon_pistol',
    'weapon_smg1',
    'apparel_rab',
    'aid_stimpak',
    'ammo_10mm_pistol'
}

function FO.LT.AddEntity(data)
    local classname = data.classname
    FO.LT.Lootable[classname] = data
end

FO.LT.AddEntity({
    name = 'Fridge',
    classname = 'lt_fridge',
    model = 'models/props_c17/FurnitureFridge001a.mdl',
    pos = Vector(-245, 1058, -12750),
    ang = Angle(0, 0, 0),
})

FO.LT.AddEntity({
    name = 'Box',
    classname = 'lt_box',
    model = 'models/props_junk/wood_crate001a.mdl',
    pos = Vector(-705, 350, -86),
    ang = Angle(0, 0, 0),
})

FO.LT.AddEntity({
    name = 'File cabinet',
    classname = 'lt_file_cabinet',
    model = 'models/props_wasteland/controlroom_filecabinet001a.mdl',
    pos = Vector(-800, 350, -86),
    ang = Angle(0, 0, 0),
})