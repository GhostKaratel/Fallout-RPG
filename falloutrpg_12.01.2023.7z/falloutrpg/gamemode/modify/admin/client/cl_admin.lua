net.Receive('adminpanel', function()
    local SELF = vgui.Create('DFrame')
    SELF:SetTitle('')
    SELF:SetSize(1024, 768)
    SELF:Center()
    SELF:MakePopup()
    SELF:ShowCloseButton(true)
    SELF:SetVisible(true)
    SELF:SetDraggable(false)   
    SELF.Paint = function(self,w,h) 
        --DrawBlurBG(self, 8)
        draw.RoundedBox(0, 0, 0, w, h, Color(40,25,15,200))
    end   

    local LIST = vgui.Create('DListView')
    LIST:SetParent(SELF)
    LIST:Dock(FILL)
    LIST:DockMargin(15,15,15,15)
    LIST:SetMultiSelect(false)
    LIST:AddColumn('Name') -- Add column
    LIST:AddColumn('Level')
    LIST:AddColumn('Karma')
    LIST:AddColumn('MaxWeight')
     
    for k,v in pairs(player.GetAll()) do
        LIST:AddLine(v:Nick(),v:GetLevel(),v:GetKarma(),v:GetMaxWeight()) -- Add lines
    end

end)