util.AddNetworkString('adminpanel')

function AdminPanel(ply)
	net.Start('adminpanel')
		net.WriteBit(open)
	net.Send(ply)
end
hook.Add ('ShowTeam', 'AdminPanel', AdminPanel)