--[[local Meta = FindMetaTable('Player')

function Meta:GetWeaponSave()
	return self:GetNWString('PlayerWeapon')
end]]