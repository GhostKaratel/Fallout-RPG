--[[local Meta = FindMetaTable('Player')

function Meta:SetWeaponSave(class)
	self:SetNWString('PlayerWeapon', class)
end

function Meta:SetSaveWeapon()
	local Weapon = self:GetWeaponSave()

	self:SetPData('PlayerWeapon', Weapon)
end

function Meta:GetSaveWeapon()
	return self:GetPData('PlayerWeapon')
end]]