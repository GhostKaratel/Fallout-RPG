FO.Teams = {}
FO.Teams.JobTable = {}
FO.Teams.JobCategories = {}

function FO.Teams:CreateCategies(name)
	local c = {}
	c.name = name
	c.jobs = {}
	self.JobCategories[name] = c
end

function FO.Teams:Create( name, jobTable)
    if not jobTable then return nil end

	local job = jobTable
	job.name = name
    job.canJoin = jobTable.canJoin or function(ply) return true end

    job.color = job.color or Color(0,0,0)

    if job.category and table.HasValue(self.JobCategories, job.category) then
        table.insert(self.JobCategories[job.category].jobs, job_id)
    end

	local job_id = table.insert( FO.Teams.JobTable, job)
    self.JobTable[job_id].id = job_id

	table.insert(self.JobCategories[job.category].jobs, job.id)

    team.SetUp(job_id, name, job.color, job.isDefaultJob)

	if job.isDefaultJob == true then
		self.DefaultJob = job_id
	end

	for k,v in pairs(job.models or {}) do
		util.PrecacheModel(v)
	end

	return job_id
end

local Meta = FindMetaTable('Player')

function Meta:GetJob( job )
    return FO.Teams.JobTable[job]
end

function Meta:GetCategory( category )
    return FO.Teams.JobCategories[ category ]
end

function Meta:GetJobCategory( job )
    return self:GetCategory( self:GetJob(job).category )
end