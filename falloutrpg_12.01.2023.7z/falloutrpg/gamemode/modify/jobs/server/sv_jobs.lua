local Meta = FindMetaTable('Player')

function Meta:SetDefaultTeam()
    self:SetTeam(0)
    self:Spawn()
end

function Meta:SetModelTeam()
	local jobsTable = self:GetJob(self:Team())
	local models = jobsTable.models
	
	self:SetModel(models[1])
end

function PlayerSpawmJob(ply)
	ply:SetTeam(TEAM_CITIZEN)

	local jobsTable = ply:GetJob(ply:Team())
	local weapons = jobsTable.weapons
	
    for _, v in pairs(weapons or {}) do
        ply:Give(v)
    end

	for k, v in pairs( FO.DefaultWeapon ) do
		ply:Give( v )
	end 

	--if ( ply:GetWeaponSave() != nil ) then
		--ply:Give(ply:GetWeaponSave())
	--end
end
hook.Add ('PlayerLoadout', 'PlayerSpawmJob', PlayerSpawmJob)

function PlayerSpawmJobModel(ply)
	local jobsTable = ply:GetJob(ply:Team())
	local models = jobsTable.models
	
	ply:SetModel(models[1])
end
hook.Add ('PlayerSetModel', 'PlayerSpawmJobModel', PlayerSpawmJobModel)