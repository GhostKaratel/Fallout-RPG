FO.TabsITEMS = {}
FO.TabsSTATS = {}
FO.TabsDATA = {}
FO.TabsStatus = {}

FO.TabsStatus[ 0 ] = 
{
    name = FO.Language.f4titlecnd,
    func = function() CND() end,
}

FO.TabsStatus[ 1 ] = 
{
    name = FO.Language.f4titlerad,
    func = function() RAD() end,
}

FO.TabsStatus[ 2 ] = 
{
    name = FO.Language.f4titleeff,
    func = function() EFF() end,
}

FO.TabsSTATS[ 0 ] = 
{
    name = FO.Language.f4titlestatus,
    func = function() Status() end,
}

FO.TabsSTATS[ 1 ] = 
{
    name = FO.Language.f4titlespecial,
    func = function() SPECIAL() end,
}

FO.TabsSTATS[ 2 ] = 
{
    name = FO.Language.f4titleskills,
    func = function() Skills() end,
}

FO.TabsSTATS[ 3 ] = 
{
    name = FO.Language.f4titleperks,
    func = function() Perks() end,
}

FO.TabsSTATS[ 4 ] = 
{
    name = FO.Language.f4titlegeneral,
    func = function() General() end,
}

FO.TabsITEMS[ 0 ] = 
{
    name = FO.Language.f4titleweapons,
    func = function() Weapons() end,
}

FO.TabsITEMS[ 1 ] = 
{
    name = FO.Language.f4titleapparel,
    func = function() Apparel() end,
}

FO.TabsITEMS[ 2 ] = 
{
    name = FO.Language.f4titleaid,
    func = function() Aid() end,
}

FO.TabsITEMS[ 3 ] = 
{
    name = FO.Language.f4titlemisc,
    func = function() Misc() end,
}

FO.TabsITEMS[ 4 ] = 
{
    name = FO.Language.f4titleammo,
    func = function() Ammo() end,
}

FO.TabsDATA[ 0 ] = 
{
    name = FO.Language.f4titlelocalmap,
    func = function() LocalMap() end,
}

FO.TabsDATA[ 1 ] = 
{
    name = FO.Language.f4titleworldmap,
    func = function() WorldMap() end,
}

FO.TabsDATA[ 2 ] = 
{
    name = FO.Language.f4titlequests,
    func = function() Quests() end,
}

FO.TabsDATA[ 3 ] = 
{
    name = FO.Language.f4titlemiscs,
    func = function() Miscs() end,
}

FO.TabsDATA[ 4 ] = 
{
    name = FO.Language.f4titleradio,
    func = function() Radio() end,
}

--[[FO.TabsITEMS[ 5 ] = 
{
    name = FO.Language.f4titlespawnmenu,
    func = function() SpawnMenu() end,
}]]