function General()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.General) then
		FO.INV.General:Remove()
	end

	FO.INV.General = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local GnPanel = FO.INV.General
    GnPanel:Dock(FILL)
    GnPanel:DockMargin(10,10,10,10)
    function GnPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titlestats, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

    local Scroll = GnPanel:Add('DScrollPanel')
    Scroll:Dock(LEFT)
    Scroll:DockMargin(15,65,0,65)
	Scroll:SetWide(FO.DParentPipBoy:GetWide()/2.15)
    Scroll.panels = {}
	Scroll.VBar:SetSize(0,0)
    function Scroll:Paint( w, h ) end

    local pcol = Vector(LocalPlayer():GetInfo("cl_playercolor"))
	local wcol = Vector(LocalPlayer():GetInfo("cl_weaponcolor"))

	local r = vgui.Create( "DNumSlider", Scroll)
	r:Dock( TOP )
	r:DockMargin(5,2,5,4)
	r:SetText( "" )
	r:SetTall(25)
	r:SetMinMax( 1, 254 )
	r:SetDecimals( 0 )
	r:SetValue( pcol.x*255 )
    r.PerformLayout = function()
		r:GetTextArea():SetWide(0)
		r.Label:SetWide(0)
		r.Slider:SetPos(0,0)
		r.Slider.Knob:SetSize(5,25)
		r.Slider.Knob:SetPos(4,25)
		r.Slider.Paint = function( self, w, h ) end
		r.Slider.Knob.Paint = function( self, w, h ) end     
	end

	local g = vgui.Create( "DNumSlider", Scroll)
	g:Dock( TOP )
	g:DockMargin(5,2,5,4)
	g:SetText( "" )
	g:SetTall(25)
	g:SetMinMax( 1, 254 )
	g:SetDecimals( 0 )
	g:SetValue( pcol.y*255 )
    g.PerformLayout = function()
		g:GetTextArea():SetWide(0)
		g.Label:SetWide(0)
		g.Slider:SetPos(0,0)
		g.Slider.Knob:SetSize(5,25)
		g.Slider.Knob:SetPos(4,25)
		g.Slider.Paint = function( self, w, h ) end
		g.Slider.Knob.Paint = function( self, w, h ) end     
	end

	local b = vgui.Create( "DNumSlider", Scroll)
	b:Dock( TOP )
	b:DockMargin(5,2,5,4)
	b:SetText( "" )
	b:SetTall(25)
	b:SetMinMax( 1, 254 )
	b:SetDecimals( 0 )
	b:SetValue( pcol.z*255 )
    b.PerformLayout = function()
		b:GetTextArea():SetWide(0)
		b.Label:SetWide(0)
		b.Slider:SetPos(0,0)
		b.Slider.Knob:SetSize(5,25)
		b.Slider.Knob:SetPos(4,25)
		b.Slider.Paint = function( self, w, h ) end
		b.Slider.Knob.Paint = function( self, w, h ) end     
	end

	function r:Paint(w,h) 
		if r:GetValue() then
			local value = r:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(r:GetValue(),g:GetValue(),b:GetValue()))
		end
	end	

	function g:Paint(w,h) 
		if g:GetValue() then
			local value = g:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(r:GetValue(),g:GetValue(),b:GetValue()))
		end
	end	

	function b:Paint(w,h) 
		if b:GetValue() then
			local value = b:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(r:GetValue(),g:GetValue(),b:GetValue()))
		end
	end	

	r.ValueChanged = function(pSelf, fValue)
		local r, g, b = tostring(r:GetValue()/255), tostring(g:GetValue()/255), tostring(b:GetValue()/255)

		RunConsoleCommand("cl_playercolor", r..g..b)
	end

	g.ValueChanged = function(pSelf, fValue)
		local r, g, b = tostring(r:GetValue()/255), tostring(g:GetValue()/255), tostring(b:GetValue()/255)

		RunConsoleCommand("cl_playercolor", r..g..b)
	end

	b.ValueChanged = function(pSelf, fValue)
		local r, g, b = tostring(r:GetValue()/255), tostring(g:GetValue()/255), tostring(b:GetValue()/255)

		RunConsoleCommand("cl_playercolor", r..g..b)
	end

    local rW = vgui.Create( "DNumSlider", Scroll)
	rW:Dock( TOP )
	rW:DockMargin(5,2,5,4)
	rW:SetText( "" )
	rW:SetTall(25)
	rW:SetMinMax( 1, 254 )
	rW:SetDecimals( 0 )
	rW:SetValue( wcol.x*255 )
    rW.PerformLayout = function()
		rW:GetTextArea():SetWide(0)
		rW.Label:SetWide(0)
		rW.Slider:SetPos(0,0)
		rW.Slider.Knob:SetSize(5,25)
		rW.Slider.Knob:SetPos(4,25)
		rW.Slider.Paint = function( self, w, h ) end
		rW.Slider.Knob.Paint = function( self, w, h ) end     
	end

	local gW = vgui.Create( "DNumSlider", Scroll)
	gW:Dock( TOP )
	gW:DockMargin(5,2,5,4)
	gW:SetText( "" )
	gW:SetTall(25)
	gW:SetMinMax( 1, 254 )
	gW:SetDecimals( 0 )
	gW:SetValue( wcol.y*255 )
    gW.PerformLayout = function()
		gW:GetTextArea():SetWide(0)
		gW.Label:SetWide(0)
		gW.Slider:SetPos(0,0)
		gW.Slider.Knob:SetSize(5,25)
		gW.Slider.Knob:SetPos(4,25)
		gW.Slider.Paint = function( self, w, h ) end
		gW.Slider.Knob.Paint = function( self, w, h ) end     
	end

	local bW = vgui.Create( "DNumSlider", Scroll)
	bW:Dock( TOP )
	bW:DockMargin(5,2,5,4)
	bW:SetText( "" )
	bW:SetTall(25)
	bW:SetMinMax( 1, 254 )
	bW:SetDecimals( 0 )
	bW:SetValue( wcol.z*255 )
    bW.PerformLayout = function()
		bW:GetTextArea():SetWide(0)
		bW.Label:SetWide(0)
		bW.Slider:SetPos(0,0)
		bW.Slider.Knob:SetSize(5,25)
		bW.Slider.Knob:SetPos(4,25)
		bW.Slider.Paint = function( self, w, h ) end
		bW.Slider.Knob.Paint = function( self, w, h ) end     
	end

	function rW:Paint(w,h) 
		if rW:GetValue() then
			local value = rW:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(rW:GetValue(),gW:GetValue(),bW:GetValue()))

		end
	end	

	function gW:Paint(w,h) 
		if gW:GetValue() then
			local value = gW:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(rW:GetValue(),gW:GetValue(),bW:GetValue()))

		end
	end	

	function bW:Paint(w,h) 
		if bW:GetValue() then
			local value = bW:GetValue() * (w/254)

			draw.RoundedBox(2, 0, 0, w, h, FO.BLACK)
			draw.RoundedBox(2, 0, 0, value, h, Color(rW:GetValue(),gW:GetValue(),bW:GetValue()))

		end
	end	

	rW.ValueChanged = function(pSelf, fValue)
		local rW, gW, bW = tostring(rW:GetValue()/255), tostring(gW:GetValue()/255), tostring(bW:GetValue()/255)

		RunConsoleCommand("cl_weaponcolor", rW..gW..bW)
	end

	gW.ValueChanged = function(pSelf, fValue)
		local rW, gW, bW = tostring(rW:GetValue()/255), tostring(gW:GetValue()/255), tostring(bW:GetValue()/255)

		RunConsoleCommand("cl_weaponcolor", rW..gW..bW)
	end

	bW.ValueChanged = function(pSelf, fValue)
		local rW, gW, bW = tostring(rW:GetValue()/255), tostring(gW:GetValue()/255), tostring(bW:GetValue()/255)

		RunConsoleCommand("cl_weaponcolor", rW..gW..bW)
	end

end