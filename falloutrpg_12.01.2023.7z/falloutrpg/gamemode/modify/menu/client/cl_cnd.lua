function CND()
	local ply = LocalPlayer()
	local PC = PrimaryСolor()
	local SC = SecondaryСolor()

	if IsValid(FO.INV.CNDStatus) then
		FO.INV.CNDStatus:Remove()
	end

	FO.INV.CNDStatus = vgui.Create( 'DLabel', StParent )
	local CNDPanel = FO.INV.CNDStatus
	CNDPanel:SetSize(StParent:GetWide()/1.5,StParent:GetTall()/1.5)
	CNDPanel:Center()
	CNDPanel:SetText('')
	function CNDPanel:Paint(w,h)
		draw.SimpleText(ply:GetRPName()..' - Level '..ply:GetLevel(), 'TEXT_F4', w/2, h-55, PC, 1, 0)

		if GetBrokenLimbs(ply) then
			FO.Image( w/2 - 20, 97, 64, 64, PC, FO.Materials.face_03 )
		elseif GetDamagedLimbs(ply) then
			FO.Image( w/2 - 20, 97, 64, 64, PC, FO.Materials.face_01 )
		else
			FO.Image( w/2 - 20, 97, 64, 64, PC, FO.Materials.face_00 )
		end

		if ply.Head and ply.Head <= 0 then
			FO.Image( w/2 - 32, 64, 128, 128, PC, FO.Materials.head_broken )

			draw.SimpleText('CRIPPLED', 'TITLE_F4', w/2 + 5, 20, SC, 1, 0)
		else
			FO.Image( w/2 - 32, 64, 128, 128, PC, FO.Materials.head )

			draw.RoundedBox(0, w/2 - 35, 20, 81, 3, PC)
			draw.RoundedBox(0, w/2 - 35, 20, 2, 20, PC)
			draw.RoundedBox(0, w/2 + 45, 20, 2, 20, PC)

			local HEAD = ply.Head
			HEAD = HEAD * (74/FO.Head)

			draw.RoundedBox(0, w/2 - 31, 25, 74, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/2 - 31, 25, HEAD, 12, SC)
		end

		if ply.Torso and ply.Torso <= 0 then
			FO.Image( w/2 - 45, 150, 128, 128, PC, FO.Materials.torso_broken )

			draw.SimpleText('CRIPPLED', 'INFO_F4', w/2 + 8, h/3, SC, 1, 0)
		else
			FO.Image( w/2 - 45, 150, 128, 128, PC, FO.Materials.torso )

			draw.RoundedBox(0, w/2 - 33, h/3, 66, 3, PC)
			draw.RoundedBox(0, w/2 - 33, h/3, 2, 20, PC)
			draw.RoundedBox(0, w/2 + 33, h/3, 2, 20, PC)

			local TORSO = ply.Torso
			TORSO = TORSO * (60/FO.Torso)

			draw.RoundedBox(0, w/2 - 29, h/3 + 5, 60, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/2 - 29, h/3 + 5, TORSO, 12, SC)
		end

		if ply.LeftArm and ply.LeftArm <= 0 then
			FO.Image( w/2 + 45, 151, 128, 64, PC, FO.Materials.left_arm_broken )

			draw.SimpleText('CRIPPLED', 'TITLE_F4', w/1.45, h/4.5, SC, 1, 0)
		else
			FO.Image( w/2 + 45, 151, 128, 64, PC, FO.Materials.left_arm )
			FO.Image( w/1.48, h/4, 32, 2, PC, FO.Materials.fade_right )

			draw.RoundedBox(0, w/1.3 - 33, h/4, 66, 3, PC)
			draw.RoundedBox(0, w/1.3 - 33, h/4, 2, 20, PC)
			draw.RoundedBox(0, w/1.3 + 33, h/4, 2, 20, PC)

			local LARM = ply.LeftArm
			LARM = LARM * (60/FO.LeftArm)

			draw.RoundedBox(0, w/1.3 - 29, h/4 + 5, 60, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/1.3 - 29, h/4 + 5, LARM, 12, SC)
		end

		if ply.RightArm and ply.RightArm <= 0 then
			FO.Image( w/2 - 137, 146, 128, 64, PC, FO.Materials.right_arm_broken )

			draw.SimpleText('CRIPPLED', 'TITLE_F4', w/3, h/4.5, SC, 1, 0)
		else
			FO.Image( w/2 - 137, 146, 128, 64, PC, FO.Materials.right_arm )
			FO.Image( w/3.39, h/4, 32, 2, PC, FO.Materials.fade_left )

			draw.RoundedBox(0, w/4.1 - 33, h/4, 66, 3, PC)
			draw.RoundedBox(0, w/4.1 - 33, h/4, 2, 20, PC)
			draw.RoundedBox(0, w/4.1 + 33, h/4, 2, 20, PC)

			local RARM = ply.RightArm
			RARM = RARM * (60/FO.RightArm)

			draw.RoundedBox(0, w/4.1 - 29, h/4 + 5, 60, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/4.1 - 29, h/4 + 5, RARM, 12, SC)
		end

		if ply.LeftLeg and ply.LeftLeg <= 0 then
			FO.Image( w/2 + 3, h/2 - 10, 128, 128, PC, FO.Materials.left_leg_broken )

			draw.SimpleText('CRIPPLED', 'TITLE_F4', w/1.46, h/1.8, SC, 1, 0)
		else
			FO.Image( w/2 + 3, h/2 - 10, 128, 128, PC, FO.Materials.left_leg )
			FO.Image( w/1.55, h/1.8, 32, 2, PC, FO.Materials.fade_right )

			draw.RoundedBox(0, w/1.35 - 33, h/1.8, 66, 3, PC)
			draw.RoundedBox(0, w/1.35 - 33, h/1.8, 2, 20, PC)
			draw.RoundedBox(0, w/1.35 + 33, h/1.8, 2, 20, PC)

			local LLEG = ply.LeftLeg
			LLEG = LLEG * (60/FO.LeftLeg)

			draw.RoundedBox(0, w/1.35 - 29, h/1.8 + 5, 60, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/1.35 - 29, h/1.8 + 5, LLEG, 12, SC)
		end

		if ply.RightLeg and ply.RightLeg <= 0 then
			FO.Image( w/2 - 82, h/2 - 13, 128, 128, PC, FO.Materials.right_leg_broken )

			draw.SimpleText('CRIPPLED', 'TITLE_F4', w/3, h/1.8, SC, 1, 0)
		else
			FO.Image( w/2 - 82, h/2 - 13, 128, 128, PC, FO.Materials.right_leg )
			FO.Image( w/3.11, h/1.8, 32, 2, PC, FO.Materials.fade_left )

			draw.RoundedBox(0, w/3.7 - 33, h/1.8, 66, 3, PC)
			draw.RoundedBox(0, w/3.7 - 33, h/1.8, 2, 20, PC)
			draw.RoundedBox(0, w/3.7 + 33, h/1.8, 2, 20, PC)

			local RLEG = ply.RightLeg
			RLEG = RLEG * (60/FO.RightLeg)

			draw.RoundedBox(0, w/3.7 - 29, h/1.8 + 5, 60, 12, ColorAlpha(SC,25))
			draw.RoundedBox(0, w/3.7 - 29, h/1.8 + 5, RLEG, 12, SC)
		end
	end 
end