function Status()
    local ply = LocalPlayer()
    local plyINV = ply.FO.INV
    local Stimpak = false
    local RadAway = false
    local AmountRadAway = 0
    local AmountStimpak = 0
    local PC = PrimaryСolor()
	local SC = SecondaryСolor()
	    
	if IsValid(FO.INV.Status) then
		FO.INV.Status:Remove()
	end

	FO.INV.Status = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local StPanel = FO.INV.Status
    StPanel:SetPos(10,10)
    StPanel:SetSize(FO.DParentPipBoy:GetWide()-20,FO.DParentPipBoy:GetTall()-20)
    function StPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titlestats, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

    StParent = vgui.Create('DPanel', StPanel)
    StParent:SetPos(0, 0)
    StParent:SetSize(StPanel:GetWide(), StPanel:GetTall())
    StParent.Paint = function(self, w, h) end

    for k, v in pairs(plyINV) do 
        local ITEMdata = FO.INV.Items[v.classname]
        if ITEMdata.type ~= 'aid' then continue end

        if v.classname == 'aid_stimpak' and tonumber(v.amount) > 0 then
            AmountStimpak = v.amount
            Stimpak = true
        end
    end

    local STbtn = {}

    for k, v in pairs(FO.TabsStatus) do
        local name = v.name or 'none'

        local STButton = vgui.Create('DButton', StPanel)
        STButton:SetPos(40, 125 + 35 * k)
        STButton:SetSize(50, 30)
        STButton:SetText('')
        STButton.Hover = 30
        STButton.Paint = function(self, w, h)
            if self:IsHovered() then  
                surface.SetDrawColor(SC)
                surface.DrawOutlinedRect(0, 0, w, h)  
                
                FO.Text( name, FO.fonts('18:New_Channel_Font-Medium'), w/2, h/2, PC, 1, 1 )     
            elseif self.active then 
                surface.SetDrawColor(SC)
                surface.DrawOutlinedRect(0, 0, w, h)

                FO.Text( name, FO.fonts('18:New_Channel_Font-Medium'), w/2, h/2, SC, 1, 1 )     
            else
                FO.Text( name, FO.fonts('18:New_Channel_Font-Medium'), w/2, h/2, SC, 1, 1 )     
            end   
        end

        if k == 0 then
            STButton.active = true
        end

        STButton.DoClick = function(self)
            for _, button in pairs(STbtn) do
                button.active = false
            end
            
            self.active = true

            StParent:Clear()

            v.func()
        end
        table.insert(STbtn, STButton)
    end 

    local HealthButton = vgui.Create( 'DButton', StPanel )
    HealthButton:SetText( '' )
    HealthButton:SetPos( StPanel:GetWide()-135, 150)
    HealthButton:SetSize( 130, 30 )
    HealthButton.Paint = function(self, w, h)
        if Stimpak then
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(SC,10))
    
                surface.SetDrawColor(SC)
                surface.DrawOutlinedRect(0, 0, w, h)

                draw.SimpleText('( '..AmountStimpak..' )'..' Stimpak S )', 'INV_NAME', w/2, h/2, PC, 1, 1)	
            else
                draw.SimpleText('( '..AmountStimpak..' )'..' Stimpak S )', 'INV_NAME', w/2, h/2, PC, 1, 1)	
            end
        else
            draw.SimpleText('Stimpak S )', 'INV_NAME', w/1.1, h/2, PC, 2, 1)	
        end
    end
    
    HealthButton.DoClick = function()
        if Stimpak then
            local ITEMdata = FO.INV.Items['aid_stimpak']

            local ITEMtabl = {
                classname = 'aid_stimpak', 
                amount = 1,
                condition = ITEMdata.condition,
                price = ITEMdata.price
            }

            net.Start('inv_use')
                net.WriteTable(ITEMtabl)
            net.SendToServer()
        end
    end

    CND()
end