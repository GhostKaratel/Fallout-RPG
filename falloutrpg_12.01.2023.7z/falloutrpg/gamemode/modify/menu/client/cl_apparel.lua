function Apparel()

    local ply = LocalPlayer()
	local plyINV = ply.FO.INV
	if not plyINV then return end
	    
	if IsValid(FO.INV.Apparel) then
		FO.INV.Apparel:Remove()
	end

	FO.INV.Apparel = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local ApPanel = FO.INV.Apparel
    ApPanel:Dock(FILL)
    ApPanel:DockMargin(10,10,10,10)
    function ApPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titleitems, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
	end

    local Scroll = ApPanel:Add('DScrollPanel')
    Scroll:Dock(LEFT)
    Scroll:DockMargin(15,65,0,65)
	Scroll:SetWide(FO.DParentPipBoy:GetWide()/2.15)
    Scroll.panels = {}
	Scroll.VBar:SetSize(0,0)
    function Scroll:Paint( w, h ) end

    local ItemChosen
	for k, v in pairs(plyINV) do 
        local ITEMdata = FO.INV.Items[v.classname]
        
        if ITEMdata.type ~= 'apparel' then continue end

        local Item = vgui.Create('DButton', Scroll)
        Item:Dock(TOP)
        Item:SetSize(0,40)
        Item:DockMargin(0,0,0,5)
        Item:SetText('')
		Item.Paint = function(self, w, h)	
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))

				surface.SetDrawColor(240,170,80)
				surface.DrawOutlinedRect(0, 0, w, h)

                if ply:GetModel() == ITEMdata.modelpm then
                    draw.RoundedBox(0, 10, h/2-8, 16, 16, Color(240,170,80))
                else
                    surface.SetDrawColor(240,170,80)
                    surface.DrawOutlinedRect(10, h/2-8, 16, 16)
                end
			
            end

			if tonumber(v.amount) > 1 then
				draw.SimpleText(ITEMdata.name..' ('..v.amount..')', 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			else
				draw.SimpleText(ITEMdata.name, 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			end
		end

		Item.DoClick = function() 
			local ITEMtabl = {
				classname = v.classname, 
				amount = 1,
				condition = v.condition,
				price = v.price
			}

            net.Start('inv_use')
                net.WriteTable(ITEMtabl)
            net.SendToServer()
		end 
		
		Item.DoRightClick = function() 
            if ply:GetModel() != ITEMdata.modelpm then
				if tonumber(v.amount) >= 5 then
					local type = 'drop'
	
					ItemSelect(ITEMdata, k, v, type)
					RunConsoleCommand('remove_f4_panel')
				elseif tonumber(v.amount) < 5 then
					local ITEMtabl = {
						classname = v.classname, 
						amount = 1,
						condition = v.condition,
						price = v.price
					}
	
					net.Start('inv_drop')
						net.WriteTable(ITEMtabl)
					net.SendToServer()
				end
            end
		end

		Item.OnCursorEntered = function() 
			ItemChosen(ITEMdata, k, v)
		end
		
		function ItemChosen(ITEMdata, k, v)

			if ChosenPanel then
				ChosenPanel:Remove()
				ChosenPanel = nil
			end
	
			ChosenPanel = vgui.Create('DPanel', ApPanel)
			ChosenPanel:Dock(RIGHT)
			ChosenPanel:SetWide(FO.DParentPipBoy:GetWide()/2-15)
			ChosenPanel:DockMargin(0, 65, 5, 65)
			ChosenPanel:SetAlpha(0)
			ChosenPanel:AlphaTo(255, 0.3, 0) 
			ChosenPanel:InvalidateParent(true)
			function ChosenPanel:Paint(w, h)
				FO.Image( w/2 - 128, 50, 256, 256, Color(240,170,80), ITEMdata.material )
				
				if v.condition then
					local CND = v.condition
					CND = CND * (58/100)

					draw.RoundedBox(0, 0, h-200, w/4.5, 2, Color(240,170,80))
					FO.Image( w/4.5, h-200, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

					draw.SimpleText('CND', 'INV_DESC', 5, h-185, Color(240,170,80), 0, 1)
					draw.RoundedBox(0, 45, h-191, 58, 15, Color(240,170,80,25))
					draw.RoundedBox(0, 45, h-191, CND, 15, Color(240,170,80))
				end

				if ITEMdata.dthreshold then
					draw.RoundedBox(0, 0, h-245, w/4.5, 2, Color(240,170,80))
					FO.Image( w/4.5, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

					draw.SimpleText('DT', 'INV_DESC', 5, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.dthreshold, 'INV_DESC', w/4.8, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.weight then
					draw.RoundedBox(0, w/4, h-245, w/4.5, 2, Color(240,170,80))
					FO.Image( w/2.125, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

					draw.SimpleText('WG', 'INV_DESC', w/3.8, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.weight, 'INV_DESC', w/2.2, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.price then
					draw.RoundedBox(0, w/2, h-245, w/2, 2, Color(240,170,80))
					FO.Image( w-2, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
					
					draw.SimpleText('WAL', 'INV_DESC', w/1.95, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.price, 'INV_DESC', w-10, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.class then
					draw.RoundedBox(0, 125, h-200, w, 2, Color(240,170,80))
					FO.Image( w-2, h-200, 2, 64, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
					
					draw.SimpleText(ITEMdata.class, 'INV_DESC', w/3.8, h-185, Color(240,170,80), 0, 1)
				end
			end  
	
		end

		Scroll.panels[Item] = true
	end

end