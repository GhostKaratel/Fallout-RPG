function EFF()
	local ply = LocalPlayer()

	if IsValid(FO.INV.EFFStatus) then
		FO.INV.EFFStatus:Remove()
	end

	FO.INV.EFFStatus = vgui.Create( 'DLabel', StParent )
	local EFFPanel = FO.INV.EFFStatus
	EFFPanel:SetSize(StParent:GetWide()/1.5,StParent:GetTall()/1.55)
	EFFPanel:Center()
	EFFPanel:SetText('')
	function EFFPanel:Paint(w,h)
	end 
end