local Category
local STabs
local ITabs
local DTabs

local Title = FO.Language.f4titleitems

local ply_font = FO.fonts('25:Akrobat-Bold')
local cat_font = FO.fonts('40:MonofontoRUSBYMelman-Regular')
local tabs_font =  FO.fonts('22:New_Channel_Font-Medium')

local function PipBoy()
    local PC = PrimaryСolor()
    local BackgroundColor = ColorAlpha(color_black,200)
    local ply = LocalPlayer()
    local WG = ply:GetWeight()
    local WGMax = ply:GetMaxWeight()
    local AP = ply:GetAP()
    local APMax = ply:GetMaxAP()
    local MN = ply:GetMoney()
    local HP = ply:Health()
    local HPMax = ply:GetMaxHealth()
    local sing = '/'
    local LVL = ply:GetLevel()
    local EXP = ply:GetExp()
    local MaxEXP = ply:GetMaxExp()

    if not Category then Category = FO.TabsSTATS end
    if not STabs then STabs = 0 end
    if not ITabs then ITabs = 0 end
    if not DTabs then DTabs = 0 end

    FO.Sound(FO.Sounds.up)

    FO.DFramePipBoy = vgui.Create('DFrame')
    FO.DFramePipBoy:SetTitle('')
    FO.DFramePipBoy:SetSize(1024, 768)
    FO.DFramePipBoy:Center()
    FO.DFramePipBoy:MakePopup()
    FO.DFramePipBoy:ShowCloseButton(false)
    FO.DFramePipBoy:SetVisible(true)
    FO.DFramePipBoy:SetDraggable(false)   
    FO.DFramePipBoy.Paint = function(self,w,h)
        -- Background
        draw.RoundedBox(0, 0, 0, w, h, BackgroundColor)
        FO.BackgroundBlur(self, 8)
        -- Material line
        FO.Image( 15, 22, 2, 128, PC, FO.Materials.fade_top ) -- Up left corner
        FO.Image( w-17, 22, 2, 128, PC, FO.Materials.fade_top ) -- Up right corner 
        FO.Image( 15, h-148, 2, 128, PC, FO.Materials.fade_bottom ) -- Down left corner 
        FO.Image( w-17, h-148, 2, 128, PC, FO.Materials.fade_bottom ) -- Down right corner 
        -- Box line
        draw.RoundedBox(0, 15, 22, 50, 2, PC) -- Tab title
        draw.RoundedBox(0, 205, 22, 150, 2, PC) -- Weight
        draw.RoundedBox(0, 15, h-20, w-30, 2, PC) -- Down line
        draw.RoundedBox(0, 15, h-67, w-30, 2, PC) -- Button line  
    end   

    function FO.DFramePipBoy:OnKeyCodePressed() 
        if input.IsKeyDown( KEY_F4 ) then
            FO.DFramePipBoy:Remove()
        end

        if input.IsKeyDown( KEY_F1 ) and Category != FO.TabsSTATS then
            FO.Sound(FO.Sounds.mode)

            Category = FO.TabsSTATS

            if FO.DParentPipBoy then
                FO.DParentPipBoy:Clear()
                Title = FO.Language.f4titlestats
            end

            TabsRefresh()
        end

        if input.IsKeyDown( KEY_F2 ) and Category != FO.TabsITEMS then
            FO.Sound(FO.Sounds.mode)

            Category = FO.TabsITEMS

            if FO.DParentPipBoy then
                FO.DParentPipBoy:Clear()
                Title = FO.Language.f4titleitems
            end

            TabsRefresh()
        end

        if input.IsKeyDown( KEY_F3 ) and Category != FO.TabsDATA then
            FO.Sound(FO.Sounds.mode)
            
            Category = FO.TabsDATA

            if FO.DParentPipBoy then
                FO.DParentPipBoy:Clear()
                Title = FO.Language.f4titledata
            end

            TabsRefresh()
        end
	end

	FO.DPanelPipBoy = vgui.Create( 'DPanel', FO.DFramePipBoy )
    FO.DPanelPipBoy:SetPos(0,0)
    FO.DPanelPipBoy:SetSize(FO.DFramePipBoy:GetWide(), FO.DFramePipBoy:GetTall())
    FO.DPanelPipBoy.Paint = function( self, w, h ) end	                       

	FO.DParentPipBoy = vgui.Create('DPanel', FO.DPanelPipBoy)
    FO.DParentPipBoy:SetPos(0, 0)
    FO.DParentPipBoy:SetSize(FO.DPanelPipBoy:GetWide(), FO.DPanelPipBoy:GetTall())
    FO.DParentPipBoy.Paint = function(self, w, h) 
        if Category == FO.TabsSTATS then
            FO.Image( 355, 22, 2, 48, PC, FO.Materials.fade_top ) -- Lvl
            FO.Image( w/2, 22, 2, 48, PC, FO.Materials.fade_top ) -- Health
            FO.Image( w/2 + 158, 22, 2, 48, PC, FO.Materials.fade_top ) -- Action Point

            draw.RoundedBox(0, w/2-150, 22, 150, 2, PC) -- Health
            draw.RoundedBox(0, w/2 + 8, 22, 150, 2, PC) -- Action Point
            draw.RoundedBox(0, w/1.5 - 5, 22, 330, 2, PC) -- Exp

            -- Lvl
            FO.Text( FO.Language.infof4lvl, ply_font, 210, 40, PC, 0, 1)     
            FO.Text( LVL, ply_font, w/2 - 161, 40, PC, 2, 1)   
            -- Action Point
            FO.Text( FO.Language.infof4ap, ply_font, w/2 + 15, 40, PC, 0, 1)     
            FO.Text( AP..sing..APMax, ply_font, w/2 + 154, 40, PC, 2, 1)   
            -- Exp
            FO.Text( FO.Language.infof4exp, ply_font, w/2 + 170, 40, PC, 0, 1)     
            FO.Text( EXP..sing..MaxEXP, ply_font, w - 24, 40, PC, 2, 1) 
            -- Health
            FO.Text( FO.Language.infof4health, ply_font, w/2 - 145, 40, PC, 0, 1)     
            FO.Text( HP..sing..HPMax, ply_font, w/2 - 5, 40, PC, 2, 1) 
        elseif Category == FO.TabsITEMS then  
            FO.Image( 355, 22, 2, 48, PC, FO.Materials.fade_top ) -- Weight
            FO.Image( w/2, 22, 2, 48, PC, FO.Materials.fade_top ) -- Health
            FO.Image( w/2 + 158, 22, 2, 48, PC, FO.Materials.fade_top ) -- DT Point

            draw.RoundedBox(0, w/2-150, 22, 150, 2, PC) -- Health
            draw.RoundedBox(0, w/2 + 8, 22, 150, 2, PC) -- DT Point
            draw.RoundedBox(0, w/1.5 - 5, 22, 330, 2, PC) -- Caps

            -- Weight
            FO.Text( FO.Language.infof4weight, ply_font, 210, 40, PC, 0, 1)     
            FO.Text( WG..sing..WGMax, ply_font, w/2 - 161, 40, PC, 2, 1)   
            -- DT Point
            FO.Text( FO.Language.infof4dt, ply_font, w/2 + 15, 40, PC, 0, 1)     
            FO.Text( '0', ply_font, w/2 + 154, 40, PC, 2, 1)   
            -- Caps
            FO.Text( FO.Language.infof4caps, ply_font, w/2 + 170, 40, PC, 0, 1)     
            FO.Text( MN, ply_font, w - 24, 40, PC, 2, 1) 
            -- Health
            FO.Text( FO.Language.infof4health, ply_font, w/2 - 145, 40, PC, 0, 1)     
            FO.Text( HP..sing..HPMax, ply_font, w/2 - 5, 40, PC, 2, 1) 
        elseif Category == FO.TabsDATA then
            local time = os.time()
			local timedata = os.date( '%H:%M:%S / %d.%m.%Y' , time )

            draw.RoundedBox(0, w-215, 22, 200, 2, PC) -- Data
            draw.RoundedBox(0, w/2-210, 22, w/2-12, 2, PC) -- Location

            FO.Image( w-222, 22, 2, 48, PC, FO.Materials.fade_top ) -- Location

            FO.Text( 'Название локации', ply_font, w-232, 40, PC, 2, 1) 
            FO.Text( timedata, ply_font, w - 24, 40, PC, 2, 1) 
        end

        draw.SimpleText(Title, cat_font, 135, 22, PC, 1, 1)
    end

    function TabsRefresh()
        if FO.TParentPipBoy then
            FO.TParentPipBoy:Remove()
            FO.TParentPipBoy = nil
        end

        local TabButton = {}

        FO.TParentPipBoy = vgui.Create('DPanel', FO.DPanelPipBoy)
        FO.TParentPipBoy:SetPos(15, FO.DPanelPipBoy:GetTall()-70)
        FO.TParentPipBoy:SetSize(FO.DPanelPipBoy:GetWide()-30, 55)
        FO.TParentPipBoy.Paint = function(self, w, h) end

        for k, v in pairs(Category) do
            FO.DButtonPipBoy = vgui.Create('DButton', FO.TParentPipBoy)
            FO.DButtonPipBoy:SetPos(6.5 + 214 * k, 10)
            FO.DButtonPipBoy:SetSize(125, 35)
            FO.DButtonPipBoy:SetText('')
            FO.DButtonPipBoy.Hover = 30
            FO.DButtonPipBoy.Paint = function(self, w, h)
                if self:IsHovered() then  
                    draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))

                    surface.SetDrawColor(PC)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)   
                elseif self.active then 
                    draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))

                    surface.SetDrawColor(PC)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                end  

                FO.Text( v.name, tabs_font, w/2, h/2, PC, 1, 1 )     
            end

            if Category == FO.TabsSTATS and STabs == k then
                FO.DButtonPipBoy.active = true
            elseif Category == FO.TabsITEMS and ITabs == k then
                FO.DButtonPipBoy.active = true
            elseif Category == FO.TabsDATA and DTabs == k then
                FO.DButtonPipBoy.active = true
            end 

            FO.DButtonPipBoy.OnCursorEntered = function()
                FO.Sound(FO.Sounds.focus)
            end

            FO.DButtonPipBoy.DoClick = function(self)
                FO.Sound(FO.Sounds.ok)

                for _, button in pairs(TabButton) do
                    button.active = false
                end
                
                self.active = true

                FO.DParentPipBoy:Clear()

                v.func()

                if Category == FO.TabsSTATS then
                    STabs = k
                elseif Category == FO.TabsITEMS then
                    ITabs = k
                elseif Category == FO.TabsDATA then
                    DTabs = k
                end  
            end
            table.insert(TabButton, FO.DButtonPipBoy)
        end 
    
        if Category == FO.TabsSTATS then
            FO.TabsSTATS[STabs].func()
        elseif Category == FO.TabsITEMS then
            FO.TabsITEMS[ITabs].func()
        elseif Category == FO.TabsDATA then
            FO.TabsDATA[DTabs].func()
        end    
    end
end

net.Receive('f4menu', function()
    PipBoy()
    TabsRefresh()
end)