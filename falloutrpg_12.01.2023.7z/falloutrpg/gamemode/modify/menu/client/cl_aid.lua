function Aid()
    local ply = LocalPlayer()
	local plyINV = ply.FO.INV
	if not plyINV then return end
	    
	if IsValid(FO.INV.Aid) then
		FO.INV.Aid:Remove()
	end

	FO.INV.Aid = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local AdpPanel = FO.INV.Aid
    AdpPanel:Dock(FILL)
    AdpPanel:DockMargin(10,10,10,10)
    function AdpPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titleitems, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

    local Scroll = AdpPanel:Add('DScrollPanel')
    Scroll:Dock(LEFT)
    Scroll:DockMargin(15,65,0,65)
	Scroll:SetWide(FO.DParentPipBoy:GetWide()/2.15)
    Scroll.panels = {}
	Scroll.VBar:SetSize(0,0)
    function Scroll:Paint( w, h ) end

    local ItemChosen
	for k, v in pairs(plyINV) do 
        local ITEMdata = FO.INV.Items[v.classname]
        
        if ITEMdata.type ~= 'aid' then continue end

        local Item = vgui.Create('DButton', Scroll)
        Item:Dock(TOP)
        Item:SetSize(0,40)
        Item:DockMargin(0,0,0,5)
        Item:SetText('')
		Item.Paint = function(self, w, h)	
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))

				surface.SetDrawColor(240,170,80)
				surface.DrawOutlinedRect(0, 0, w, h)

				surface.SetDrawColor(240,170,80)
				surface.DrawOutlinedRect(10, h/2-8, 16, 16)
            end

			if tonumber(v.amount) > 1 then
				draw.SimpleText(ITEMdata.name..' ('..v.amount..')', 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			else
				draw.SimpleText(ITEMdata.name, 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			end
		end

		Item.DoClick = function() 
			local ITEMtabl = {
				classname = v.classname, 
				amount = 1,
				condition = v.condition,
				price = v.price
			}

            net.Start('inv_use')
                net.WriteTable(ITEMtabl)
            net.SendToServer()
		end 
		
		Item.DoRightClick = function() 
			if tonumber(v.amount) >= 5 then
				local type = 'drop'

				ItemSelect(ITEMdata, k, v, type)
				RunConsoleCommand('remove_f4_panel')
			elseif tonumber(v.amount) < 5 then
				local ITEMtabl = {
					classname = v.classname, 
					amount = 1,
					condition = v.condition,
					price = v.price
				}

				net.Start('inv_drop')
					net.WriteTable(ITEMtabl)
				net.SendToServer()
			end
		end

		Item.OnCursorEntered = function() 
			ItemChosen(ITEMdata, k, v)
		end
		
		function ItemChosen(ITEMdata, k, v)

			if ChosenPanel then
				ChosenPanel:Remove()
				ChosenPanel = nil
			end
	
			ChosenPanel = vgui.Create('DPanel', AdpPanel)
			ChosenPanel:Dock(RIGHT)
			ChosenPanel:SetWide(FO.DParentPipBoy:GetWide()/2-15)
			ChosenPanel:DockMargin(0, 65, 5, 65)
			ChosenPanel:SetAlpha(0)
			ChosenPanel:AlphaTo(255, 0.3, 0) 
			ChosenPanel:InvalidateParent(true)
			function ChosenPanel:Paint(w, h)
				FO.Image( w/2 - 128, 50, 256, 256, Color(240,170,80), ITEMdata.material )
		
				if ITEMdata.weight then
					draw.RoundedBox(0, w/4, h-245, w/4.5, 2, Color(240,170,80))
					FO.Image( w/2.125, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

					draw.SimpleText('WG', 'INV_DESC', w/3.8, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.weight, 'INV_DESC', w/2.2, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.price then
					draw.RoundedBox(0, w/2, h-245, w/2, 2, Color(240,170,80))
					FO.Image( w-2, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
					
					draw.SimpleText('WAL', 'INV_DESC', w/1.95, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.price, 'INV_DESC', w-10, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.effect then
					draw.RoundedBox(0, 0, h-200, w, 2, Color(240,170,80))
					FO.Image( w-2, h-200, 2, 64, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
					
					draw.SimpleText('EFFECTS    '..ITEMdata.effect, 'INV_DESC', 5, h-185, Color(240,170,80), 0, 1)
				end
			end  
	
		end

		Scroll.panels[Item] = true
	end

end


--[[local entsArr = {}
entsArr[1] = scripted_ents.Get('ammo_dispenser')

for k,v in pairs(entsArr) do
    local EItem = vgui.Create('DButton',AdpPanle)
    EItem:SetText('')
    EItem:SetPos(25, 65)
    EItem:SetSize(FO.DParentPipBoy:GetWide()-50, 75)
    EItem.Hover = 0
    EItem.Paint = function( self, w, h )
        if self:IsHovered() then
            EItem.Hover = Lerp(FrameTime() * 5, EItem.Hover, 200)                       
        else
            EItem.Hover = Lerp(FrameTime() * 10, EItem.Hover, 100)
        end	
        draw.RoundedBox(14, 0, 0, w, h, Color(40,40,40))  
        --draw.RoundedBox(16, w-22, h/2-9, 16, 16, Color(225,0,0,EItem.Hover)) 
        draw.InterfaceText( v['PrintName']..' ( '..v['Cost']..' )', 'TABS_F4', 'TABS_F4_SHADOW', w/2, h/2, Color(225,225,225), 1, 1, Color(0, 0, 0) )

    end

    EItem.DoClick = function()
        LocalPlayer():ConCommand('buy_ent '..v['ClassName'])
    end  
end  ]]