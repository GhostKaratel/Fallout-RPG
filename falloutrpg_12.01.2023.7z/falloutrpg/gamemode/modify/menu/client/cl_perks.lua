function Perks()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.Perks) then
		FO.INV.Perks:Remove()
	end

	local PerksPnl = vgui.Create( 'DPanel', FO.DParentPipBoy )
	PERKS = PerksPnl
    PERKS:Dock(FILL)
    PERKS:DockMargin(10,10,10,10)
    function PERKS:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titlestats, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end