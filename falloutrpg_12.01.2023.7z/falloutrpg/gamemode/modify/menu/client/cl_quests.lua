function Quests()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.Quests) then
		FO.INV.Quests:Remove()
	end

	FO.INV.Quests = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local QstPanel = FO.INV.Quests
    QstPanel:Dock(FILL)
    QstPanel:DockMargin(10,10,10,10)
    function QstPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titledata, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end