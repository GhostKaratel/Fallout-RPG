function Miscs()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.Miscs) then
		FO.INV.Miscs:Remove()
	end

	FO.INV.Miscs = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local MscPanel = FO.INV.Miscs
    MscPanel:Dock(FILL)
    MscPanel:DockMargin(10,10,10,10)
    function MscPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titledata, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end