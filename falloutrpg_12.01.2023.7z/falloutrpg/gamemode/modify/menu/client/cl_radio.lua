function Radio()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.Radio) then
		FO.INV.Radio:Remove()
	end

	FO.INV.Radio = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local RdPanel = FO.INV.Radio
    RdPanel:Dock(FILL)
    RdPanel:DockMargin(10,10,10,10)
    function RdPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titledata, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end