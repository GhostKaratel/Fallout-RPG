function WorldMap()
    local ply = LocalPlayer()
	    
	if IsValid(WORLD_MAP) then
		FO.INV.WorldMap:Remove()
	end

	local WorldMapPnl = vgui.Create( 'DPanel', FO.DParentPipBoy )
	WORLD_MAP = WorldMapPnl
    WORLD_MAP:Dock(FILL)
    WORLD_MAP:DockMargin(10,10,10,10)
    function WORLD_MAP:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titledata, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end