local SaveTabs

local add = '▶'
local take = '◀'

local point_font = FO.fonts('100:Monofonto')
local point2_font = FO.fonts('50:Monofonto')
local tabs_font = FO.fonts('25:Akrobat-Bold')
local desc_font = FO.fonts('22:CQ Mono [RUS by Daymarius]')

local Points 
local OldPoints 

local GetStrength
local GetPerception
local GetEndurance
local GetCharisma
local GetIntellect
local GetAgility
local GetLuck
local PlyPointRefresh

local function GetOldPoints(v)
    if v.name == FO.Language.TabStrength then
        OldPoints = GetStrength
    elseif v.name == FO.Language.TabPerception then
        OldPoints = GetPerception
    elseif v.name == FO.Language.TabEndurance then
        OldPoints = GetEndurance
    elseif v.name == FO.Language.TabCharisma then
        OldPoints = GetCharisma
    elseif v.name == FO.Language.TabIntellect then
        OldPoints = GetIntellect
    elseif v.name == FO.Language.TabAgility then
        OldPoints = GetAgility
    elseif v.name == FO.Language.TabLuck then
        OldPoints = GetLuck
    end

    return OldPoints
end

local function TakePoints(v)
    if v.name == FO.Language.TabStrength then
        GetStrength = GetStrength - 1
    elseif v.name == FO.Language.TabPerception then
        GetPerception = GetPerception - 1
    elseif v.name == FO.Language.TabEndurance then
        GetEndurance = GetEndurance - 1
    elseif v.name == FO.Language.TabCharisma then
        GetCharisma = GetCharisma - 1
    elseif v.name == FO.Language.TabIntellect then
        GetIntellect = GetIntellect - 1
    elseif v.name == FO.Language.TabAgility then
        GetAgility = GetAgility - 1
    elseif v.name == FO.Language.TabLuck then
        GetLuck = GetLuck - 1
    end

    PlyPointRefresh = PlyPointRefresh + 1
end

local function AddPoints(v)
    if v.name == FO.Language.TabStrength then
        GetStrength = GetStrength + 1
    elseif v.name == FO.Language.TabPerception then
        GetPerception = GetPerception + 1
    elseif v.name == FO.Language.TabEndurance then
        GetEndurance = GetEndurance + 1
    elseif v.name == FO.Language.TabCharisma then
        GetCharisma = GetCharisma + 1
    elseif v.name == FO.Language.TabIntellect then
        GetIntellect = GetIntellect + 1
    elseif v.name == FO.Language.TabAgility then
        GetAgility = GetAgility + 1
    elseif v.name == FO.Language.TabLuck then
        GetLuck = GetLuck + 1
    end

    PlyPointRefresh = PlyPointRefresh - 1
end

local function GetPoints(v, ply)
    if v.name == FO.Language.TabStrength then
        Points = ply:GetStrength()
    elseif v.name == FO.Language.TabPerception then
        Points = ply:GetPerception()
    elseif v.name == FO.Language.TabEndurance then
        Points = ply:GetEndurance()
    elseif v.name == FO.Language.TabCharisma then
        Points = ply:GetCharisma()
    elseif v.name == FO.Language.TabIntellect then
        Points = ply:GetIntellect()
    elseif v.name == FO.Language.TabAgility then
        Points = ply:GetAgility()
    elseif v.name == FO.Language.TabLuck then
        Points = ply:GetLuck()
    end

    return Points
end

function SPECIAL()
	if IsValid(SPECIAL_PNL) then
		SPECIAL_PNL:Remove()
	end

    local ply = LocalPlayer()
    local PC = PrimaryСolor()
    
    PlyPointRefresh = ply:GetSpecialPoints()

    GetStrength = ply:GetStrength()
    GetPerception = ply:GetPerception()
    GetEndurance = ply:GetEndurance()
    GetCharisma = ply:GetCharisma()
    GetIntellect = ply:GetIntellect()
    GetAgility = ply:GetAgility()
    GetLuck = ply:GetLuck()

	local SpecialPnl = vgui.Create( 'DPanel', FO.DParentPipBoy )
	SPECIAL_PNL = SpecialPnl
    SPECIAL_PNL:SetPos(10,60)
    SPECIAL_PNL:SetSize(FO.DParentPipBoy:GetWide()-10, FO.DParentPipBoy:GetTall()-120)
    function SPECIAL_PNL:Paint(w,h)
        FO.Text(PlyPointRefresh, point_font, w/4.5, h/1.3, PC, 1, 1)
    end

    local SpecialChosen
    for k, v in pairs(FO.Special) do
        local SpecialBtn = vgui.Create('DButton', SPECIAL_PNL)
        SPECIAL_BTN = SpecialBtn
        SPECIAL_BTN:SetPos(25, 25 + k * 45)
        SPECIAL_BTN:SetSize(SPECIAL_PNL:GetWide()/2.5,40)
        SPECIAL_BTN:SetText('')
        SPECIAL_BTN.Paint = function(self, w, h)  
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
                surface.SetDrawColor(PC)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            GetOldPoints(v)

            FO.Text(v.name, tabs_font, 15, h/2, PC, 0, 1)
            FO.Text(OldPoints, tabs_font, w - 15, h/2, PC, 2, 1)
        end

        SPECIAL_BTN.OnCursorEntered = function() 
            SpecialChosen(v)
        end

        function SpecialChosen(v)

            SaveTabs = v

            if CHOSEN_PNL then
                CHOSEN_PNL:Remove()
                CHOSEN_PNL = nil
            end

            local ChosenPnl = vgui.Create('DPanel', SPECIAL_PNL)
            CHOSEN_PNL = ChosenPnl
            CHOSEN_PNL:SetPos(SPECIAL_PNL:GetWide()/2-15, 85 )
            CHOSEN_PNL:SetSize(SPECIAL_PNL:GetWide()/2, SPECIAL_PNL:GetTall() - 100)
            CHOSEN_PNL:SetAlpha(0)
            CHOSEN_PNL:AlphaTo(255, 0.3, 0) 
            CHOSEN_PNL:InvalidateParent(true)
            function CHOSEN_PNL:Paint(w, h)
                GetPoints(v, ply)
                GetOldPoints(v)

                draw.RoundedBox(0, 0, h/2 - 25, w, 2, PC)
                FO.Image( w-2, h/2 - 25, 2, h/5, PC, FO.Materials.fade_top) 
                FO.Image( w/2 - 128, -32, 256, 256, PC, v.material )

                if (OldPoints-Points) > 0 then
                    FO.Text(Points..'(+'..(OldPoints-Points)..')', point2_font, w/2, h/1.17, PC, 1, 1)
                else
                    FO.Text(OldPoints, point2_font, w/2, h/1.17, PC, 1, 1)
                end
            end  

            local SpecialDesc = CHOSEN_PNL:Add('DLabel')
            SPECIAL_DESC = SpecialDesc
            SPECIAL_DESC:SetPos(10,CHOSEN_PNL:GetTall()/2 - 15)
            SPECIAL_DESC:SetWide(CHOSEN_PNL:GetWide()-20)
            SPECIAL_DESC:SetText(v.description)
            SPECIAL_DESC:SetFont(desc_font)
            SPECIAL_DESC:SetContentAlignment(1)
            SPECIAL_DESC:SetTextColor(PC)
            SPECIAL_DESC:SetWrap(true)
            SPECIAL_DESC:SetAutoStretchVertical(true)

            local AddSpecial = vgui.Create('DButton', CHOSEN_PNL)
            ADD_SPECIAL = AddSpecial
            ADD_SPECIAL:SetText('')
            ADD_SPECIAL:SetSize(32,32)
            ADD_SPECIAL:SetPos(CHOSEN_PNL:GetWide()/2 + 64, CHOSEN_PNL:GetTall()/1.17 - 15)
            ADD_SPECIAL:IsVisible() 
            ADD_SPECIAL.Paint = function(self,w,h)
                if PlyPointRefresh <= 0 or OldPoints >= 10 then self:Remove() end 

                if self:IsHovered() then 
                    FO.Text(add, point2_font, w/2, h/2, FO.WHITE, 1, 1) 
                else
                    FO.Text(add, point2_font, w/2, h/2, PC, 1, 1) 
                end		
            end     

            ADD_SPECIAL.DoClick = function()
                AddPoints(v)
            end

            local ReduceSpecial = vgui.Create('DButton', CHOSEN_PNL)
            REDUCE_SPECIAL = ReduceSpecial
            REDUCE_SPECIAL:SetText('')
            REDUCE_SPECIAL:SetSize(32,32)
            REDUCE_SPECIAL:SetPos(CHOSEN_PNL:GetWide()/2 - 96, CHOSEN_PNL:GetTall()/1.17 - 15)
            REDUCE_SPECIAL:IsVisible() 
            REDUCE_SPECIAL.Paint = function(self,w,h)
                if OldPoints <= Points or OldPoints <= 0 then self:Remove() end 

                if self:IsHovered() then 
                    FO.Text(take, point2_font, w/2, h/2, FO.WHITE, 1, 1)	
                else
                    FO.Text(take, point2_font, w/2, h/2, PC, 1, 1)	
                end
            end  

            REDUCE_SPECIAL.DoClick = function() 
                TakePoints(v)
            end	
        end

        if SaveTabs then
            SpecialChosen(SaveTabs)
        end
    end  

    local EnterBtn = vgui.Create('DButton', SPECIAL_PNL)
    ENTER_BTN = EnterBtn
    ENTER_BTN:SetText('')
    ENTER_BTN:SetSize(100,30)
    ENTER_BTN:SetPos(SPECIAL_PNL:GetWide() - 125, 25)
    ENTER_BTN:IsVisible() 
    ENTER_BTN.Paint = function(self,w,h)
        if PlyPointRefresh >= ply:GetSpecialPoints() then
            FO.Text(FO.Language.f4enter, tabs_font, w/2, h/2, ColorAlpha(PC, 75), 1, 1)    	
        else
            if self:IsHovered() then  
                draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
                surface.SetDrawColor(PC)
                surface.DrawOutlinedRect(0, 0, w, h)
            end	

            FO.Text(FO.Language.f4enter, tabs_font, w/2, h/2, PC, 1, 1)    	
        end	
    end     

    ENTER_BTN.DoClick = function()  
        if PlyPointRefresh >= ply:GetSpecialPoints() then return end
        
        local TableSpecial = {
            ['S'] = GetStrength,
            ['P'] = GetPerception,
            ['E'] = GetEndurance,
            ['C'] = GetCharisma,
            ['I'] = GetIntellect,
            ['A'] = GetAgility,
            ['L'] = GetLuck,
            ['POINT'] = PlyPointRefresh,
        }

        net.Start('ChangeSpecial')
            net.WriteTable(TableSpecial)
        net.SendToServer()

        net.Start('ChangeSkills')
        net.SendToServer()
    end	
end