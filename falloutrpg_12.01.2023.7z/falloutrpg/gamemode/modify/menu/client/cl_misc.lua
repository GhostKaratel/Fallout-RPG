function Misc()

    local ply = LocalPlayer()
	local plyINV = ply.FO.INV
	if not plyINV then return end
	    
	if IsValid(FO.INV.Misc) then
		FO.INV.Misc:Remove()
	end

	FO.INV.Misc = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local McPanel = FO.INV.Misc
    McPanel:Dock(FILL)
    McPanel:DockMargin(10,10,10,10)
    function McPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titleitems, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
	end

    local Scroll = McPanel:Add('DScrollPanel')
    Scroll:Dock(LEFT)
    Scroll:DockMargin(15,65,0,65)
	Scroll:SetWide(FO.DParentPipBoy:GetWide()/2.15)
    Scroll.panels = {}
	Scroll.VBar:SetSize(0,0)
    function Scroll:Paint( w, h ) end

    local ItemChosen
	for k, v in pairs(plyINV) do 
        local ITEMdata = FO.INV.Items[v.classname]
        
        if ITEMdata.type ~= 'misc' then continue end

        local Item = vgui.Create('DButton', Scroll)
        Item:Dock(TOP)
        Item:SetSize(0,40)
        Item:DockMargin(0,0,0,5)
        Item:SetText('')
		Item.Paint = function(self, w, h)	
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, Color(240,170,80,10))

				surface.SetDrawColor(240,170,80)
				surface.DrawOutlinedRect(0, 0, w, h)

				surface.SetDrawColor(240,170,80)
				surface.DrawOutlinedRect(10, h/2-8, 16, 16)
            end

			if tonumber(v.amount) > 1 then
				draw.SimpleText(ITEMdata.name..' ('..v.amount..')', 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			else
				draw.SimpleText(ITEMdata.name, 'INV_NAME', 40, h/2, Color(240,170,80), 0, 1)	
			end
		end

		Item.DoClick = function() 
			local ITEMtabl = {
				classname = v.classname, 
				amount = 1,
				condition = v.condition,
				price = v.price
			}

            net.Start('inv_use')
                net.WriteTable(ITEMtabl)
            net.SendToServer()
		end 
		
		Item.DoRightClick = function() 
            if ply:GetModel() != ITEMdata.modelpm then
				if tonumber(v.amount) >= 5 then
					local type = 'drop'
	
					ItemSelect(ITEMdata, k, v, type)
					RunConsoleCommand('remove_f4_panel')
				elseif tonumber(v.amount) < 5 then
					local ITEMtabl = {
						classname = v.classname, 
						amount = 1,
						condition = v.condition,
						price = v.price
					}
	
					net.Start('inv_drop')
						net.WriteTable(ITEMtabl)
					net.SendToServer()
				end
            end
		end

		Item.OnCursorEntered = function() 
			ItemChosen(ITEMdata, k, v)
		end
		
		function ItemChosen(ITEMdata, k, v)

			if ChosenPanel then
				ChosenPanel:Remove()
				ChosenPanel = nil
			end
	
			ChosenPanel = vgui.Create('DPanel', McPanel)
			ChosenPanel:Dock(RIGHT)
			ChosenPanel:SetWide(FO.DParentPipBoy:GetWide()/2-15)
			ChosenPanel:DockMargin(0, 65, 5, 65)
			ChosenPanel:SetAlpha(0)
			ChosenPanel:AlphaTo(255, 0.3, 0) 
			ChosenPanel:InvalidateParent(true)
			function ChosenPanel:Paint(w, h)
				FO.Image( w/2 - 128, 50, 256, 256, Color(240,170,80), ITEMdata.material )
		
				if ITEMdata.weight then
					draw.RoundedBox(0, w/4, h-245, w/4.5, 2, Color(240,170,80))
					FO.Image( w/2.125, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 

					draw.SimpleText('WG', 'INV_DESC', w/3.8, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.weight, 'INV_DESC', w/2.2, h-230, Color(240,170,80), 2, 1)
				end

				if ITEMdata.price then
					draw.RoundedBox(0, w/2, h-245, w/2, 2, Color(240,170,80))
					FO.Image( w-2, h-245, 2, 36, Color(240,170,80), 'shared/line/fade_to_bottom.png') 
					
					draw.SimpleText('WAL', 'INV_DESC', w/1.95, h-230, Color(240,170,80), 0, 1)
					draw.SimpleText(ITEMdata.price, 'INV_DESC', w-10, h-230, Color(240,170,80), 2, 1)
				end
			end  
	
		end

		Scroll.panels[Item] = true
	end

end

--[[local wepArr = {}
wepArr[1] = {'models/props_borealis/door_wheel001a.mdl', 'weapon_smg1', 'SMG', '100','8'}

for k,v in pairs(wepArr) do
    local WItem = vgui.Create('DButton',McPanel)
    WItem:SetText('')
    WItem:SetPos(25, 65)
    WItem:SetSize(FO.DParentPipBoy:GetWide()-50, 75)
    WItem.Hover = 0
    WItem.Paint = function( self, w, h )
        if self:IsHovered() then
            WItem.Hover = Lerp(FrameTime() * 5, WItem.Hover, 200)                       
        else
            WItem.Hover = Lerp(FrameTime() * 10, WItem.Hover, 100)
        end	
        draw.RoundedBox(14, 0, 0, w, h, Color(40,40,40))  
        --draw.RoundedBox(16, w-22, h/2-9, 16, 16, Color(225,0,0,EItem.Hover)) 
        draw.InterfaceText( v[3]..' ( '..v[4]..' )'..' ( '..v[5]..' )', 'TABS_F4', 'TABS_F4_SHADOW', w/2, h/2, Color(225,225,225), 1, 1, Color(0, 0, 0) )

    end

    WItem.DoClick = function()
        LocalPlayer():ConCommand('buy_wep '..v[2])
    end  
end]]