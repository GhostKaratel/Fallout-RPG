function SpawnMenu()

	local SpawnPnl = vgui.Create('DPanel', FO.DParentPipBoy)
    SPAWN = SpawnPnl
    SPAWN:Dock(FILL)
    SPAWN:DockMargin(10,10,10,10)
    function SPAWN:Paint(w,h)
        
        draw.RoundedBox( 14, 0, 0, w, h, Color(50,50,50) )
        draw.RoundedBox( 0, 0, 0, w, h/2, Color(50,50,50) )

       --draw.SimpleText(FO.Language.f4titlemain, 'TITLE_F4', 25, 25, PrimaryСolor(),0,1)
    
    end
    
    local wrh = ScreenScale(65)
    local wrw = ScreenScale(65)

    local PSCROLL = vgui.Create('DScrollPanel', SPAWN)
    PSCROLL:Dock(FILL)
    PSCROLL:DockMargin(5,5,ScreenScale(135),5)
    PSCROLL.Paint = function( self, w, h ) 
        draw.RoundedBox( 16, 0, 0, w, h, Color(40,40,40) )
        draw.RoundedBox( 0, 0, 0, w, h/2, Color(40,40,40) )
    end
        local sbar = PSCROLL:GetVBar()
	    function sbar:Paint( w, h ) 
	    	--draw.RoundedBox( 0, 0, 0, w-4, h, Color(40,40,40) )
	    end
	    function sbar.btnUp:Paint( w, h )
		    draw.RoundedBox( 0, 0, 4, w-4, h, Color(65,65,65) )
	    end
	    function sbar.btnDown:Paint( w, h )
		    --draw.RoundedBox( 0, 0, 0, w-4, h, Color(65,65,65) )
	    end
	    function sbar.btnGrip:Paint( w, h )
		    draw.RoundedBox( 0, 0, 0, w-4, h, Color(65,65,65) )
	    end

        local DGRID = vgui.Create( 'DGrid', PSCROLL )
        DGRID:SetPos(10, 10)
        DGRID:SetSize(PSCROLL:GetWide()-10, PSCROLL:GetTall() - 40)
        DGRID:SetCols( 5 )
        DGRID:SetColWide( wrw )
        DGRID:SetRowHeight( wrh )
        DGRID.Paint = function( self,w,h ) end   

    for k,v in pairs(FO.AllowedProps) do
      
        local PItem = vgui.Create('DButton',DGRID)
        PItem:SetText('')
        PItem:SetSize(ScreenScale(60), ScreenScale(60))
        PItem.Hover = 25
        PItem.Paint = function( self, w, h )
            if self:IsHovered() then
                PItem.Hover = Lerp(FrameTime() * 5, PItem.Hover, 70)                       
            else
                PItem.Hover = Lerp(FrameTime() * 10, PItem.Hover, 50)
            end	
            draw.RoundedBox(14, 0, 0, w, h, Color(PItem.Hover,PItem.Hover,PItem.Hover))  
            --draw.RoundedBox(16, w-22, h/2-9, 16, 16, Color(225,0,0,EItem.Hover)) 
        end
        
        PItem.DoClick = function()
            RunConsoleCommand( 'gm_spawn', v )
        end      
      
        DGRID:AddItem( PItem )

        local PModel = vgui.Create( 'ModelImage', PItem )
        PModel:SetModel( v )
        PModel:SetSize(ScreenScale(22), ScreenScale(22))
        PModel:Center()

    end 

end