function LocalMap()
    local ply = LocalPlayer()
	    
	if IsValid(FO.INV.LocalMap) then
		FO.INV.LocalMap:Remove()
	end

	FO.INV.LocalMap = vgui.Create( 'DPanel', FO.DParentPipBoy )
	local LMPanel = FO.INV.LocalMap
    LMPanel:Dock(FILL)
    LMPanel:DockMargin(10,10,10,10)
    function LMPanel:Paint(w,h)
        --draw.SimpleText(FO.Language.f4titledata, 'CATEGORY_F4', 125, 12, PrimaryСolor(),1,1)
    end

end