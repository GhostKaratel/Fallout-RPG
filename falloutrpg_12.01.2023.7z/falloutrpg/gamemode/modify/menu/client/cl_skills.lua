local SaveTabs

local add = '▶'
local take = '◀'

local point_font = FO.fonts('35:Monofonto')
local point2_font = FO.fonts('50:Monofonto')
local tabs_font = FO.fonts('25:Akrobat-Bold')
local desc_font = FO.fonts('22:CQ Mono [RUS by Daymarius]')

local Points 
local OldPoints 

local GetBarter
local GetUnarmed
local GetBreaking
local GetExplosive
local GetSurvival
local GetEloquence
local GetMedicine
local GetScience
local GetGun
local GetRepair
local GetStealth
local GetColdWeapons
local GetEnergyWeapons

local function GetPoints(v, ply)
    if v.name == FO.Language.TabBarter then
        Points = ply:GetBarter()
    elseif v.name == FO.Language.TabUnarmed then
        Points = ply:GetUnarmed()
    elseif v.name == FO.Language.TabBreaking then
        Points = ply:GetBreaking()
    elseif v.name == FO.Language.TabExplosive then
        Points = ply:GetExplosive()
    elseif v.name == FO.Language.TabSurvival then
        Points = ply:GetSurvival()
    elseif v.name == FO.Language.TabEloquence then
        Points = ply:GetEloquence()
    elseif v.name == FO.Language.TabMedicine then
        Points = ply:GetMedicine()
    elseif v.name == FO.Language.TabScience then
        Points = ply:GetScience()
    elseif v.name == FO.Language.TabGun then
        Points = ply:GetGun()
    elseif v.name == FO.Language.TabRepair then
        Points = ply:GetRepair()
    elseif v.name == FO.Language.TabStealth then
        Points = ply:GetStealth()
    elseif v.name == FO.Language.TabColdWeapons then
        Points = ply:GetColdWeapons()
    elseif v.name == FO.Language.TabEnergyWeapons then
        Points = ply:GetEnergyWeapons()
    end

    return Points
end

local function GetOldPoints(v)
    if v.name == FO.Language.TabBarter then
        OldPoints = GetBarter
    elseif v.name == FO.Language.TabUnarmed then
        OldPoints = GetUnarmed
    elseif v.name == FO.Language.TabBreaking then
        OldPoints = GetBreaking
    elseif v.name == FO.Language.TabExplosive then
        OldPoints = GetExplosive
    elseif v.name == FO.Language.TabSurvival then
        OldPoints = GetSurvival
    elseif v.name == FO.Language.TabEloquence then
        OldPoints = GetEloquence
    elseif v.name == FO.Language.TabMedicine then
        OldPoints = GetMedicine
    elseif v.name == FO.Language.TabScience then
        OldPoints = GetScience
    elseif v.name == FO.Language.TabGun then
        OldPoints = GetGun
    elseif v.name == FO.Language.TabRepair then
        OldPoints = GetRepair
    elseif v.name == FO.Language.TabStealth then
        OldPoints = GetStealth
    elseif v.name == FO.Language.TabColdWeapons then
        OldPoints = GetColdWeapons
    elseif v.name == FO.Language.TabEnergyWeapons then
        OldPoints = GetEnergyWeapons
    end

    return OldPoints
end

local function TakePoints(v)
    if v.name == FO.Language.TabBarter then
        GetBarter = GetBarter - 1
    elseif v.name == FO.Language.TabUnarmed then
        GetUnarmed = GetUnarmed - 1
    elseif v.name == FO.Language.TabBreaking then
        GetBreaking = GetBreaking - 1
    elseif v.name == FO.Language.TabExplosive then
        GetExplosive = GetExplosive - 1
    elseif v.name == FO.Language.TabSurvival then
        GetSurvival = GetSurvival - 1
    elseif v.name == FO.Language.TabEloquence then
        GetEloquence = GetEloquence - 1
    elseif v.name == FO.Language.TabMedicine then
        GetMedicine = GetMedicine - 1
    elseif v.name == FO.Language.TabScience then
        GetScience = GetScience - 1
    elseif v.name == FO.Language.TabGun then
        GetGun = GetGun - 1
    elseif v.name == FO.Language.TabRepair then
        GetRepair = GetRepair - 1
    elseif v.name == FO.Language.TabStealth then
        GetStealth = GetStealth - 1
    elseif v.name == FO.Language.TabColdWeapons then
        GetColdWeapons = GetColdWeapons - 1
    elseif v.name == FO.Language.TabEnergyWeapons then
        GetEnergyWeapons = GetEnergyWeapons - 1
    end

    PlyPointRefresh = PlyPointRefresh + 1
end

local function AddPoints(v)
    if v.name == FO.Language.TabBarter then
        GetBarter = GetBarter + 1
    elseif v.name == FO.Language.TabUnarmed then
        GetUnarmed = GetUnarmed + 1
    elseif v.name == FO.Language.TabBreaking then
        GetBreaking = GetBreaking + 1
    elseif v.name == FO.Language.TabExplosive then
        GetExplosive = GetExplosive + 1
    elseif v.name == FO.Language.TabSurvival then
        GetSurvival = GetSurvival + 1
    elseif v.name == FO.Language.TabEloquence then
        GetEloquence = GetEloquence + 1
    elseif v.name == FO.Language.TabMedicine then
        GetMedicine = GetMedicine + 1
    elseif v.name == FO.Language.TabScience then
        GetScience = GetScience + 1
    elseif v.name == FO.Language.TabGun then
        GetGun = GetGun + 1
    elseif v.name == FO.Language.TabRepair then
        GetRepair = GetRepair + 1
    elseif v.name == FO.Language.TabStealth then
        GetStealth = GetStealth + 1
    elseif v.name == FO.Language.TabColdWeapons then
        GetColdWeapons = GetColdWeapons + 1
    elseif v.name == FO.Language.TabEnergyWeapons then
        GetEnergyWeapons = GetEnergyWeapons + 1
    end

    PlyPointRefresh = PlyPointRefresh - 1
end

function Skills()
	if IsValid(SKILL_PNG) then
		SKILL_PNG:Remove()
	end

    local ply = LocalPlayer()
    local PC = PrimaryСolor()

    PlyPointRefresh = ply:GetSkillPoints()

    GetBarter = ply:GetBarter()
    GetUnarmed = ply:GetUnarmed()
    GetBreaking = ply:GetBreaking()
    GetExplosive = ply:GetExplosive()
    GetSurvival = ply:GetSurvival()
    GetEloquence = ply:GetEloquence()
    GetMedicine = ply:GetMedicine()
    GetScience = ply:GetScience()
    GetGun = ply:GetGun()
    GetRepair = ply:GetRepair()
    GetStealth = ply:GetStealth()
    GetColdWeapons = ply:GetColdWeapons()
    GetEnergyWeapons = ply:GetEnergyWeapons()    

    local SkillPnl = vgui.Create('DPanel', FO.DParentPipBoy )
    SKILL_PNG = SkillPnl
    SKILL_PNG:SetPos(10,60)
    SKILL_PNG:SetSize(FO.DParentPipBoy:GetWide()-10, FO.DParentPipBoy:GetTall()-120)
    function SKILL_PNG:Paint(w,h)	
        FO.Text(FO.Language.TabTitlePoint..PlyPointRefresh, point_font, w/4.5, h-50, PC, 1, 1)
    end

    local SkillChosen
    for k, v in pairs(FO.Skills) do
        local SkillBtn = vgui.Create('DButton', SKILL_PNG)
        SKILL_BTN = SkillBtn
        SKILL_BTN:SetPos(25, 25 + k * 40)
        SKILL_BTN:SetSize(SKILL_PNG:GetWide()/2.5,40)
        SKILL_BTN:SetText('')
        SKILL_BTN.Paint = function(self, w, h)  
            if self:IsHovered() then 
                draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
                surface.SetDrawColor(PC)
                surface.DrawOutlinedRect(0, 0, w, h)
            end
            
            GetOldPoints(v)

            FO.Text(v.name, tabs_font, 15, h/2, PC, 0, 1)
            FO.Text(OldPoints, tabs_font, w - 15, h/2, PC, 2, 1)
        end

        SKILL_BTN.OnCursorEntered = function() 
            SkillChosen(v)
        end

        function SkillChosen(v)
            SaveTabs = v

            if CHOSEN_PNL then
                CHOSEN_PNL:Remove()
                CHOSEN_PNL = nil
            end

            local ChosenPnl = vgui.Create('DPanel', SKILL_PNG)
            CHOSEN_PNL = ChosenPnl
            CHOSEN_PNL:SetPos(SKILL_PNG:GetWide()/2 - 15, 85 )
            CHOSEN_PNL:SetSize(SKILL_PNG:GetWide()/2, SKILL_PNG:GetTall() - 100)
            CHOSEN_PNL:SetAlpha(0)
            CHOSEN_PNL:AlphaTo(255, 0.3, 0) 
            CHOSEN_PNL:InvalidateParent(true)
            function CHOSEN_PNL:Paint(w, h)
                GetPoints(v, ply)
                GetOldPoints(v)

                draw.RoundedBox(0, 0, h/2 - 25, w, 2, PC)
                FO.Image( w-2, h/2 - 25, 2, h/5, PC, FO.Materials.fade_top) 
                FO.Image( w/2 - 128, -32, 256, 256, PC, v.material )

                if (OldPoints-Points) > 0 then
                    FO.Text(Points..'(+'..(OldPoints-Points)..')', point2_font, w/2, h/1.17, PC, 1, 1)
                else
                    FO.Text(OldPoints, point2_font, w/2, h/1.17, PC, 1, 1)
                end
            end  

            local SkillDesc = CHOSEN_PNL:Add('DLabel')
            SKILL_DESC = SkillDesc
            SKILL_DESC:SetPos(10,CHOSEN_PNL:GetTall()/2 - 15)
            SKILL_DESC:SetWide(CHOSEN_PNL:GetWide()-20)
            SKILL_DESC:SetText(v.description)
            SKILL_DESC:SetFont(desc_font)
            SKILL_DESC:SetContentAlignment(1)
            SKILL_DESC:SetTextColor(PC)
            SKILL_DESC:SetWrap(true)
            SKILL_DESC:SetAutoStretchVertical(true)

            local AddSkill = vgui.Create('DButton', CHOSEN_PNL)
            ADD_SKILL = AddSkill
            ADD_SKILL:SetText('')
            ADD_SKILL:SetSize(32,32)
            ADD_SKILL:SetPos(CHOSEN_PNL:GetWide()/2 + 64, CHOSEN_PNL:GetTall()/1.17 - 15)
            ADD_SKILL:IsVisible() 
            ADD_SKILL.Paint = function(self,w,h)
                if PlyPointRefresh <= 0 or OldPoints >= 100 then self:Remove() end 

                if self:IsHovered() then 
                    FO.Text(add, point2_font, w/2, h/2, FO.WHITE, 1, 1) 
                else
                    FO.Text(add, point2_font, w/2, h/2, PC, 1, 1) 
                end	    		
            end     

            ADD_SKILL.DoClick = function()
                AddPoints(v) 
            end	
            
            local ReduceSkill = vgui.Create('DButton', CHOSEN_PNL)
            REDUCE_SKILL = ReduceSkill
            REDUCE_SKILL:SetText('')
            REDUCE_SKILL:SetSize(32,32)
            REDUCE_SKILL:SetPos(CHOSEN_PNL:GetWide()/2 - 96, CHOSEN_PNL:GetTall()/1.17 - 15)
            REDUCE_SKILL:IsVisible() 
            REDUCE_SKILL.Paint = function(self,w,h)
                if OldPoints <= Points or OldPoints <= 0 then self:Remove() end 

                if self:IsHovered() then 
                    FO.Text(take, point2_font, w/2, h/2, FO.WHITE, 1, 1)	
                else
                    FO.Text(take, point2_font, w/2, h/2, PC, 1, 1)	
                end   		
            end     

            REDUCE_SKILL.DoClick = function() 
                TakePoints(v)
            end	
        end

        if SaveTabs then
            SkillChosen(SaveTabs)
        end
    end

    local EnterBtn = vgui.Create('DButton', SKILL_PNG)
    ENTER_BTN = EnterBtn
    ENTER_BTN:SetText('')
    ENTER_BTN:SetSize(100,30)
    ENTER_BTN:SetPos(SKILL_PNG:GetWide() - 125, 25)
    ENTER_BTN:IsVisible() 
    ENTER_BTN.Paint = function(self,w,h)
        if PlyPointRefresh >= ply:GetSkillPoints() then
            FO.Text(FO.Language.f4enter, tabs_font, w/2, h/2, ColorAlpha(PC, 75), 1, 1)    	
        else
            if self:IsHovered() then  
                draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
                surface.SetDrawColor(PC)
                surface.DrawOutlinedRect(0, 0, w, h)
            end	

            FO.Text(FO.Language.f4enter, tabs_font, w/2, h/2, PC, 1, 1)    	
        end	
    end     

    ENTER_BTN.DoClick = function()  
        if PlyPointRefresh >= ply:GetSkillPoints() then return end
        
        local TableSkills = {
            ['BR'] = GetBarter,
            ['U'] = GetUnarmed,
            ['B'] = GetBreaking,
            ['ES'] = GetExplosive,
            ['SL'] = GetSurvival,
            ['E'] = GetEloquence,
            ['M'] = GetMedicine,
            ['S'] = GetScience,
            ['W'] = GetGun,
            ['R'] = GetRepair,
            ['SH'] = GetStealth,
            ['CW'] = GetColdWeapons,
            ['EW'] = GetEnergyWeapons,
            ['POINT'] = PlyPointRefresh,
        }

        net.Start('ChangePointSkills')
            net.WriteTable(TableSkills)
        net.SendToServer()
    end	
end