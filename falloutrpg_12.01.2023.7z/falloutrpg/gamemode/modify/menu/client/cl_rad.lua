function RAD()
	local ply = LocalPlayer()

	if IsValid(FO.INV.RADStatus) then
		FO.INV.RADStatus:Remove()
	end

	FO.INV.RADStatus = vgui.Create( 'DLabel', StParent )
	local RADPanel = FO.INV.RADStatus
	RADPanel:SetSize(StParent:GetWide()/1.5,StParent:GetTall()/1.55)
	RADPanel:Center()
	RADPanel:SetText('')
	function RADPanel:Paint(w,h)
	end 
end