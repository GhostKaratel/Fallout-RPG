util.AddNetworkString('f4menu')

function MenuF4(ply)
	net.Start('f4menu')
		net.WriteBit(open)
	net.Send(ply)
end
hook.Add ('ShowSpare2', 'F4Menu', MenuF4)

concommand.Add('Spee', function(ply)
	ply:AddSpecialPoints(1)
end)