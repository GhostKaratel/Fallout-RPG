local Meta = FindMetaTable('Player')

function Meta:SetWeight(wg)
	self:SetNWInt('Weight', wg )
end

function Meta:AddWeight(wg)
	local Weight = self:GetWeight()

	self:SetWeight(Weight + wg)
end

function Meta:TakeWeight(wg)
	local Weight = self:GetWeight()

	self:SetWeight(Weight - wg)
end

function Meta:SetMaxWeight(wg)
	self:SetNWInt('MaxWeight', wg )
end

function Meta:SaveWeight()
	local Weight = self:GetWeight()

	self:SetPData('Weight', Weight)
end

function Meta:GetSaveWeight()
	return tonumber(self:GetPData('Weight'))
end

function Meta:SaveMaxWeight()
	local MaxWeight = self:GetMaxWeight()

	self:SetPData('MaxWeight', MaxWeight)
end

function Meta:GetSaveMaxWeight()
	return tonumber(self:GetPData('MaxWeight'))
end

function CheckWeight(ply)
	local Weight = ply:GetWeight()
	local MaxWeight = ply:GetMaxWeight()	

	if Weight > MaxWeight then
		ply:SetJumpPower(0)
		ply:SetRunSpeed(140)
		ply:SetWalkSpeed(140)
	else
		ply:SetJumpPower(FO.JumpPower)
		ply:SetRunSpeed(FO.RunSpeed)
		ply:SetWalkSpeed(FO.WalkSpeed)
	end

	if Weight < 0 then 
		ply:SetWeight(0)
	elseif ply.FO.INV == nil then
		ply:SetWeight(0)
	end
end