local nets = {
    'inv_give',
    'inv_pickup',
    'inv_init',
    'inv_use',
    'inv_drop',
    'inv_remove',
    'inv_refresh',
    'inv_strip',
}

for k, v in ipairs(nets) do
    util.AddNetworkString(v)
end

local Meta = FindMetaTable('Player')

function PlayerInitialINV(ply)
	timer.Create( 'IntINV', 1, 1, function() 
		ply:INVinit()
    end)
end
hook.Add ('PlayerInitialSpawn', 'PlayerInitialINV', PlayerInitialINV)

function Meta:INVinit()
    self.FO = {INV = {}}
    
    net.Start('inv_init')
    net.Send(self)
end

concommand.Add('inv_reoload', function(ply, cmd, args)
    ply:INVinit()
    ply:SetWeight(0)
end)

function Meta:FOHasItem(classname, amount, condition, price)
	local amount = amount or 0
	local has = false
	local hasAmount = false
	local found = 0
    
	for k,v in pairs(self.FO.INV) do
		if v.classname == classname and v.condition == condition and v.price == price then
			has =  true
			found = found + v.amount

            break
		end
	end

	if found >= tonumber(amount) then
		hasAmount = true
	end

	return has, hasAmount
end

function Meta:INVgive(item, amt)
    local ITEMdata = FO.INV.Items[item]
    if not ITEMdata then return end

	local plyINV = self.FO.INV

    if !plyINV[1] then
        table.insert(plyINV, {
            classname = item, 
            amount = amt or 1,
            condition = ITEMdata.condition,
            price = ITEMdata.price
        })
    else
        for k, v in pairs(plyINV) do 
            if v.classname == item and v.condition == ITEMdata.condition and v.price == ITEMdata.price then
                v.amount = v.amount + (amt or 1)
                
                break
            elseif not self:FOHasItem(item, amt, ITEMdata.condition, ITEMdata.price) then
                table.insert(plyINV, {
                    classname = item, 
                    amount = amt or 1,
                    condition = ITEMdata.condition,
                    price = ITEMdata.price
                })
        
                break
            end
        end
    end

    net.Start('inv_give')
        net.WriteTable(plyINV)
    net.Send(self)

    local weight = ITEMdata.weight * (amt or 1)

    self:AddWeight(weight)

    CheckWeight(self)
    self:INVrefresh()
end

function Meta:INVremoveitem(item)
    local plyINV = self.FO.INV
    local ITEMdata = FO.INV.Items[item.classname]

    for k, v in pairs(plyINV) do
        if v.classname == item.classname and v.condition == item.condition and v.price == item.price then
            if plyINV[k] != nil and tonumber(v.amount) >= 1 then
                v.amount = v.amount - item.amount
            end

            if plyINV[k] != nil and tonumber(v.amount) <= 0 then
                table.remove( plyINV, k )
            end
        end
    end

    net.Start('inv_remove')
        net.WriteTable(item)
    net.Send(self)

    local weight = ITEMdata.weight * item.amount

    self:TakeWeight(weight)

    CheckWeight(self)
    self:INVrefresh()
end

function Meta:INVrefresh()
    net.Start('inv_refresh')
    net.Send(self)
end

function Meta:INVpickup(classname, amount, condition, price)
    if not classname then return end
	
    local plyINV = self.FO.INV
    local ITEMdata = FO.INV.Items[classname]

    if !plyINV[1] then
        table.insert(plyINV, {
            classname = classname, 
            amount = amount or 1,
            condition = condition,
            price = price
        })
    else
        for k, v in pairs(plyINV) do 
            if v.classname == classname and v.condition == condition and v.price == price then
                v.amount = v.amount + amount

                break
            elseif not self:FOHasItem(classname, amount, condition, price) then
                table.insert(plyINV, {
                    classname = classname, 
                    amount = amount or 1,
                    condition = condition,
                    price = price
                })
        
                break
            end
        end
    end  

    net.Start('inv_pickup')
        net.WriteTable(plyINV)
    net.Send(self)

    local weight = ITEMdata.weight * amount

    self:AddWeight(weight)

    CheckWeight(self)
    self:INVrefresh()
end

net.Receive('inv_use', function(len, ply)
    local item = net.ReadTable()
    local ITEMdata = FO.INV.Items[item.classname]
    local shouldRemove = FO.INV.UseTypes[ITEMdata.type](ITEMdata, ply)

    if ITEMdata.type == 'aid' and shouldRemove then
        ply:INVremoveitem(item)
    elseif ITEMdata.type == 'ammo' then
        ply:GiveAmmo(item.amount, ITEMdata.typeammo)
        ply:INVremoveitem(item)
    end
end)

net.Receive('inv_strip', function(len, ply)
    local wep  = net.ReadString()

    ply:StripWeapon( wep )

    hook.Remove( 'PlayerSwitchWeapon', 'WeaponSwitchExample' )
end)

net.Receive('inv_drop', function(len, ply)
    local item = net.ReadTable()

    if ply:FOHasItem(item.classname, item.amount, item.condition, item.price) then        
        local ITEMent = ents.Create('base_item')
        local tr = util.TraceLine({
            start = ply:EyePos(),
            endpos = ply:EyePos() + ply:EyeAngles():Forward() * 50,
            filter = ply,
        })
        ITEMent:SetPos(tr.HitPos)
        ITEMent:SetAngles(Angle(0,0,0))
        ITEMent:Spawn()
        ITEMent:SetItem(item)
        
        ply:INVremoveitem(item)
    end
end)

concommand.Add('inv_give', function(ply, cmd, args)
	local classname = args[1]
    local amount = args[2]

    ply:INVgive(classname, amount)
end)