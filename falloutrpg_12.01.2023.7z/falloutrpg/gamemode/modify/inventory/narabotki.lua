	--[[local item = net.ReadTable()
	local plyINV = LocalPlayer().FO.INV
    
    for k, v in pairs(plyINV) do
        if LocalPlayer():FOHasItem(item.classname, item.amount, item.condition, item.price) then
            if plyINV[k] != nil and tonumber(v.amount) >= 1 then
                v.amount = v.amount - item.amount
            end

            if plyINV[k] != nil and tonumber(v.amount) <= 0 then
                plyINV[k] = nil
            end
        end
    end]]

    --local amt = tonumber(plyINV[classname].amt)
	
	--[[if (amt != nil and amt >= 1) then
		plyINV[classname].amt = plyINV[classname].amt - amount
	end
	
	if (amt != nil and plyINV[classname].amt <= 0) then
		plyINV[classname] = nil
	end]]

        --local ITEMdata = FO.INV.Items[classname]

    --[[if !plyINV[1] then
        table.insert(plyINV, {
            classname = classname, 
            amount = amount,
            condition = condition,
            price = price
        })

        print('nil')
    else
        for k, v in pairs(plyINV) do 
            if LocalPlayer():FOHasItem(classname, amount, condition, price) then
                v.amount = v.amount + amount

                print('Идентификатор: '..k..' Количество: '..v.amount)
                break
            elseif not LocalPlayer():FOHasItem(classname, amount, condition, price) then
                table.insert(plyINV, {
                    classname = classname, 
                    amount = amount,
                    condition = condition,
                    price = price
                })
        
                print('new')

                break
            end

        end
    end   ]]

    --[[if ITEMdata2.condition == condition then
        ITEMdata.condition = ITEMdata2.condition
        ITEMdata.price = ITEMdata2.price

        print('IF качество: '..ITEMdata.condition)
    else
        ITEMdata.condition = condition
        ITEMdata.price = price

        print('ELSE качество: '..ITEMdata.condition)
    end]]

    --ITEMdata.condition = condition
    --ITEMdata.price = price

    
        --[[if item.classname == k.classname and item.condition == k.condition then
            if plyINV[k] != nil and plyINV[k] >= 1 then
                plyINV[k] = plyINV[k] - item.amount
            end

            if plyINV[k] != nil and plyINV[k] <= 0 then
                plyINV[k] = nil
            end
        end]]

        --[[print(condition)

        if !plyINV[ITEMdata] then
            ITEMdata.condition = ITEMdata2.condition
            ITEMdata.price = ITEMdata2.price

            plyINV[ITEMdata] = 0
            plyINV[ITEMdata] = plyINV[ITEMdata] + amount

            print('Новый элемент')
        --elseif cnd == condition then
           -- plyINV[ITEMdata] = plyINV[ITEMdata] + amount

           -- print('Суммирует элементы')
        else

            for k, v in pairs(plyINV) do
                if classname == k.classname and condition == k.condition then
                    if plyINV[k] != nil and plyINV[k] >= 1 then
                        plyINV[k] = plyINV[k] + amount

                        print('Увеличивает элемент')

                        break
                    end
                else
                    ITEMdata.condition = condition
                    ITEMdata.price = price
                    
                    plyINV[ITEMdata] = plyINV[ITEMdata] + amount

                    print('Перезаписывает элемент')

                    break
                end

                break
            end

            --ITEMdata.condition = condition
            --ITEMdata.price = price

            --plyINV[ITEMdata] = plyINV[ITEMdata] + amount

            print('Перезаписывает элемент')
            --[[for k, v in pairs(plyINV) do
                if LocalPlayer():INVhasitem(ITEMdata) then
                    if k.condition != condition and plyINV[ITEMdata] != plyINV[k] then                        
                        plyINV[ITEMdata] = plyINV[ITEMdata] + amount
    
                        print('Другое качество')
                    elseif k.condition != condition and plyINV[ITEMdata] == plyINV[k] then
                        plyINV[ITEMdata] = 0
                        plyINV[ITEMdata] = plyINV[ITEMdata] + amount

                        print('Другое качество, новая таблица')

                        break
                    end
                    
                    if k.condition == condition then
                        plyINV[k] = plyINV[k] + amount
                        
                        print('Начисляется сумма')
    
                        break
                    end
                end
            end]]
        --end]]

	--[[if (!plyINV[ITEMdata]) then
		plyINV[ITEMdata] = 0
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	else
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	end]]

    
    --[[if !plyINV[1] then
        table.insert(plyINV, {
            classname = classname, 
            amount = amount,
            condition = ITEMdata.condition,
            price = ITEMdata.price
        })
    else
        for k, v in pairs(plyINV) do 
            if LocalPlayer():FOHasItem(classname, amount, ITEMdata.condition, ITEMdata.price) then
                v.amount = v.amount + amount

                break
            elseif not LocalPlayer():FOHasItem(classname, amount, ITEMdata.condition, ITEMdata.price) then
                table.insert(plyINV, {
                    classname = classname, 
                    amount = amount,
                    condition = ITEMdata.condition,
                    price = ITEMdata.price
                })

                break
            end
        end
    end]]

	--[[if (!plyINV[ITEMdata]) then
		plyINV[ITEMdata] = 0
	    plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	else
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	end]]

    
	--[[if (!plyINV[classname]) then
        --table.Merge(plyINV, add)
        plyINV[classname] = {
            amt = amount,
            cnd = ITEMdata.condition,
            dmg = ITEMdata.damage,
            prc = ITEMdata.price
        }
    else
        plyINV[classname].amt = plyINV[classname].amt + amount
	end]]

    --[[for k, v in pairs(plyINV) do
        print(v.amount)
    end]]

    	--[[if (!plyINV[ITEMdata]) then
		plyINV[ITEMdata] = 0
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	else
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	end]]

    --------------------------------------------------------------------------
--[[if (!plyINV[classname]) then
    plyINV[classname] = {
        amt = amount,
        cnd = ITEMdata.condition,
        dmg = ITEMdata.damage,
        prc = ITEMdata.price
    }
else
    plyINV[classname].amt = plyINV[classname].amt + amount
end]]
--------------------------------------------------------------------------
--[[if (!plyINV[ITEMdata]) then
    return false
end]]
--------------------------------------------------------------------------
--[[local amt = tonumber(plyINV[classname].amt)

if (amt != nil and amt >= 1) then
    plyINV[classname].amt = plyINV[classname].amt - amount
end

if (amt != nil and plyINV[classname].amt <= 0) then
    plyINV[classname] = nil
end]]
--------------------------------------------------------------------------


    --[[if ITEMdata2.condition == condition then
        ITEMdata.condition = ITEMdata2.condition
        ITEMdata.price = ITEMdata2.price

        print('IF качество: '..ITEMdata.condition)
    else
        ITEMdata.condition = condition
        ITEMdata.price = price

        print('ELSE качество: '..ITEMdata.condition)
    end]]

    --ITEMdata.condition = condition
    --ITEMdata.price = price

    
        --[[if item.classname == k.classname and item.condition == k.condition then
            if plyINV[k] != nil and plyINV[k] >= 1 then
                plyINV[k] = plyINV[k] - item.amount
            end

            if plyINV[k] != nil and plyINV[k] <= 0 then
                plyINV[k] = nil
            end
        end]]

        --[[if !plyINV[ITEMdata] then
            ITEMdata.condition = ITEMdata2.condition
            ITEMdata.price = ITEMdata2.price

            plyINV[ITEMdata] = 0
            plyINV[ITEMdata] = plyINV[ITEMdata] + amount

            print('Новый элемент')
        --elseif ITEMdata2.condition == condition then
            --plyINV[ITEMdata] = plyINV[ITEMdata] + amount

           -- print('Суммирует элементы')
        else
            --ITEMdata.condition = condition
            --ITEMdata.price = price

            for k, v in pairs(plyINV) do
                if classname == k.classname and condition == k.condition then
                    if plyINV[k] != nil and plyINV[k] >= 1 then
                        plyINV[k] = plyINV[k] + amount

                        print('Увеличивает элемент')
                        
                        break
                    end
                else
                    ITEMdata.condition = condition
                    ITEMdata.price = price
                    
                    plyINV[ITEMdata] = plyINV[ITEMdata] + amount

                    print('Перезаписывает элемент')

                    break
                end

                break
            end

           -- plyINV[ITEMdata] = plyINV[ITEMdata] + amount

            --[[for k, v in pairs(plyINV) do
                if self:INVhasitem(ITEMdata) then
                    if k.condition != condition and plyINV[ITEMdata] != plyINV[k] then                        
                        plyINV[ITEMdata] = plyINV[ITEMdata] + amount
    
                        print('Другое качество')
                    elseif k.condition != condition and plyINV[ITEMdata] == plyINV[k] then
                        plyINV[ITEMdata] = 0
                        plyINV[ITEMdata] = plyINV[ITEMdata] + amount

                        print('Другое качество, новая таблица')

                        break
                    end
                    
                    if k.condition == condition then
                        plyINV[k] = plyINV[k] + amount
                        
                        print('Начисляется сумма')
    
                        break
                    end
                end
            end]]
        --end

	--[[if (!plyINV[ITEMdata]) then
		plyINV[ITEMdata] = 0
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	else
		plyINV[ITEMdata] = plyINV[ITEMdata] + amount
	end]]

    