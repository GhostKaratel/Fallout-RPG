net.Receive('inv_init', function()
	LocalPlayer().FO = {INV = {}}
    LocalPlayer().ActiveWeapon = {}
end)

net.Receive('inv_give', function()
    local ITEMdata = net.ReadTable()
    if not ITEMdata then return end
    local plyINV = LocalPlayer().FO.INV

    table.Merge(plyINV, ITEMdata)
end)

net.Receive('inv_pickup', function()
    local ITEMdata = net.ReadTable()
    if not ITEMdata then return end
    local plyINV = LocalPlayer().FO.INV

    table.Merge(plyINV, ITEMdata)
end)

net.Receive('inv_remove', function()
    local ITEMdata = net.ReadTable()
    if not ITEMdata then return end
    local plyINV = LocalPlayer().FO.INV

    for k, v in pairs(plyINV) do
        if v.classname == ITEMdata.classname and v.condition == ITEMdata.condition and v.price == ITEMdata.price then
            if plyINV[k] != nil and tonumber(v.amount) >= 1 then
                v.amount = v.amount - ITEMdata.amount
            end

            if plyINV[k] != nil and tonumber(v.amount) <= 0 then
                table.remove( plyINV, k )
            end
        end
    end
end)

net.Receive('inv_refresh', function()
	if IsValid(FO.INV.Weapon) then
		Weapons()
    elseif IsValid(FO.INV.Apparel) then
        Apparel()
    elseif IsValid(FO.INV.Aid) then
        Aid()
    elseif IsValid(FO.INV.Misc) then
        Misc()
    elseif IsValid(FO.INV.Ammo) then
        Ammo()
    elseif IsValid(FO.INV.Status) then
        Status()
	end
end)