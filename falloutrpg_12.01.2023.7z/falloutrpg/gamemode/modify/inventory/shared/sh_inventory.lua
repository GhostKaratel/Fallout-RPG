FO.INV = FO.INV or {}
FO.INV.Items = {}
FO.INV.UseTypes = {
    weapon = function(ITEMdata, ply)
        if ply:HasWeapon(ITEMdata.classname) then return false end
            ply:Give(ITEMdata.classname, true)
            ply:SelectWeapon( ITEMdata.classname )

            hook.Add( 'PlayerSwitchWeapon', 'WeaponSwitchExample', function( ply, oldWeapon, newWeapon )
                return true
            end )

        return false
    end,

    apparel = function(ITEMdata, ply)
            if ply:GetModel() != ITEMdata.modelpm then
                ply:SetModel(ITEMdata.modelpm)
            else
                ply:SetModel('models/player/mossman_arctic.mdl')
            end
        return false
    end,

    ammo = function(ITEMdata, ply)
        return true
    end,

    aid = function(ITEMdata, ply)
        if ITEMdata.funct(ply, ITEMdata.sound, ITEMdata.effect) then
            ITEMdata.funct(ply, ITEMdata.sound, ITEMdata.effect)

            return true
        else
            return false
        end
    end,

    misc = function(ITEMdata, ply)
        return false
    end,
}

function FO.INV.AddItem(data)
    local classname = data.classname
    FO.INV.Items[classname] = data
end

FO.INV.AddItem({
    name = 'Pistol 10mm',
    classname = 'weapon_pistol',
    model = 'models/weapons/w_pistol.mdl',
    material = FO.Materials.mm10_pistol,
    weight = 3,
    price = 750,
    damage = 22,
    condition = 100,
    ammo = 'pistol',
    type = 'weapon',
})

FO.INV.AddItem({
    name = 'Laser Rifle',
    classname = 'weapon_smg1',
    model = 'models/weapons/w_rif_ak47.mdl',
    material = FO.Materials.assault_rifle,
    weight = 8,
    price = 800,
    damage = 22,
    condition = 100,
    ammo = 'smg1',
    type = 'weapon',
})

FO.INV.AddItem({
    name = 'Wasteland outfit',
    classname = 'apparel_rab',
    model = 'models/Items/item_item_crate.mdl',
    modelpm = 'models/player/arctic.mdl',
    material = FO.Materials.ncr_ranger_combat_armor,
    dthreshold = 2,
    weight = 4,
    price = 100,
    condition = 100,
    class = 'Easy',
    effect = 0,
    type = 'apparel',
})

FO.INV.AddItem({
    name = 'Stimpak',
    classname = 'aid_stimpak',
    model = 'models/Items/HealthKit.mdl',
    material = FO.Materials.stimpack,
    sound = 'items/smallmedkit1.wav',
    weight = 0,
    price = 75,
    effect = 30,
    condition = 100,
    funct = function(ply, sound, effect) 
        if ply.Head < FO.Head or ply.Torso < FO.Torso or ply.LeftArm < FO.LeftArm or ply.RightArm < FO.RightArm or ply.LeftLeg < FO.LeftLeg or ply.RightLeg < FO.RightLeg then 
            ply.Head = math.Clamp(ply.Head + math.random(5,10),0,FO.Head)
            ply.Torso = math.Clamp(ply.Torso + math.random(5,15),0,FO.Torso)
            ply.LeftArm = math.Clamp(ply.LeftArm + math.random(4,8),0,FO.LeftArm)
            ply.RightArm = math.Clamp(ply.RightArm + math.random(4,8),0,FO.RightArm)
            ply.LeftLeg = math.Clamp(ply.LeftLeg + math.random(3,9),0,FO.LeftLeg)
            ply.RightLeg = math.Clamp(ply.RightLeg + math.random(3,9),0,FO.RightLeg)
            
            ply:HPUpdate()

            return true
        end

        if ply:Health() < ply:GetMaxHealth() then
            ply:SetHealth(math.Clamp(ply:Health() + effect,0,ply:GetMaxHealth()))
            
            return true
        else 
            return false
        end
        
        ply:EmitSound(sound,0,100,0.4)
    end,
    type = 'aid',
})

FO.INV.AddItem({
    name = '$5 NCR',
    classname = 'misc_5ncr',
    model = 'models/Items/combine_rifle_ammo01.mdl',
    material = FO.Materials.money_ncr_5,
    price = 2,
    weight = 0,
    condition = 100,
    type = 'misc',
})

FO.INV.AddItem({
    name = '10mm pistol',
    classname = 'ammo_10mm_pistol',
    model = 'models/Items/BoxSRounds.mdl',
    material = FO.Materials.mm10_rounds,
    ammo = 1,
    price = 1,
    weight = 0,
    condition = 100,
    typeammo = 'smg1',
    type = 'ammo',
})