local Meta = FindMetaTable('Player')

function Meta:GetWeight()
	return tonumber(self:GetNWInt('Weight', 0))
end

function Meta:GetMaxWeight()
	return tonumber(self:GetNWInt('MaxWeight', 0))
end