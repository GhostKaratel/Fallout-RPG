local Meta = FindMetaTable('Player')

function Meta:GetMoney()
	return tonumber(self:GetNWInt('PlayerMoney'))
end

function Meta:CanBuy(cost)
    if (self:GetMoney() >= cost) then
        return true
    end

    return false
end