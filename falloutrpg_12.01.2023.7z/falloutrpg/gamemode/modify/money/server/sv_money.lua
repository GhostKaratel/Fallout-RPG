local Meta = FindMetaTable('Player')

function Meta:AddMoney(amount)
	local Money = self:GetMoney()

	self:SetMoney(Money + amount)
end

function Meta:RemoveMoney(amount)
	local Money = self:GetMoney()

	self:SetMoney(Money - amount)
end

function Meta:SetMoney(wallet)
	self:SetNWInt('PlayerMoney', wallet)
end

function Meta:SaveMoney()
	local Money = self:GetMoney()

	self:SetPData('PlayerMoney', Money)
end

function Meta:GetSaveMoney()
	return tonumber(self:GetPData('PlayerMoney'))
end