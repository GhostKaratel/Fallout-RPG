util.AddNetworkString('RPNameChange')
util.AddNetworkString('RPNameSet')

local Meta = FindMetaTable('Player')

function Meta:SetRPName(name)
	self:SetNWString('RPName', name)
end

function Meta:SaveRPName()
	local Name = self:GetRPName()

	self:SetPData('RPName', Name)
end

function Meta:GetSaveRPName()
	return self:GetPData('RPName', 0)
end

net.Receive('RPNameSet', function(len, ply)
	local name = net.ReadString()
	
	ply:SetRPName(name)
end)

concommand.Add('CreateName', function(ply)
	net.Start('RPNameChange')
	net.Send(ply)
end)