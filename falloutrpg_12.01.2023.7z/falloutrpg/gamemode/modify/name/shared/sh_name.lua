local Meta = FindMetaTable('Player')

function Meta:GetRPName()
	return self:GetNWString('RPName')
end