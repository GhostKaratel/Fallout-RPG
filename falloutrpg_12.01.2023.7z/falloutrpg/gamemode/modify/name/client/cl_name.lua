local btn_font = FO.fonts('25:Akrobat-Bold')
local desc_font = FO.fonts('22:CQ Mono [RUS by Daymarius]')

net.Receive('RPNameChange', function(ply)
    if IsValid(NAME_MENU) then
		NAME_MENU:Remove()
	end

	local ply = net.ReadEntity()
    local PC = PrimaryСolor()

    local NameMenu = vgui.Create('DFrame')
    NAME_MENU = NameMenu
    NAME_MENU:SetSize(500, 200)
    NAME_MENU:Center()
    NAME_MENU:SetTitle('')
    NAME_MENU:SetDraggable(false)
    NAME_MENU:ShowCloseButton(true)
    NAME_MENU:MakePopup()
    NAME_MENU:SetAlpha(0)
    NAME_MENU:AlphaTo(255, 1, 0) 
    NAME_MENU.Paint = function(self, w, h)
        draw.RoundedBox(16, w/2-250, h/2-100, 500, 200, ColorAlpha(color_black,200))
        FO.BackgroundBlur(self, 8)

        FO.Image( 10, 10, 2, 64, PC, FO.Materials.fade_top) 
        FO.Image( w-12, 10, 2, 64, PC, FO.Materials.fade_top) 
        FO.Image( 10, h-74, 2, 64, PC, FO.Materials.fade_bottom) 
        FO.Image( w-12, h-74, 2, 64, PC, FO.Materials.fade_bottom) 
        draw.RoundedBox(0, 10, 10, w-20, 2, PC)
        draw.RoundedBox(0, 10, h-12, w-20, 2, PC)
        draw.RoundedBox(0,50,50,w-100,45,ColorAlpha(color_black,200))
    end

    local NameChange = vgui.Create('DTextEntry', NAME_MENU)
    NAME_CHANGE = NameChange
    NAME_CHANGE:SetSize(NAME_MENU:GetWide()-105, 45)
    NAME_CHANGE:SetPos(55,50)
    NAME_CHANGE:SetPaintBorderEnabled( true )
    NAME_CHANGE:SetFont(desc_font)
    NAME_CHANGE:SetAllowNonAsciiCharacters( true )
    NAME_CHANGE:SetText(FO.Language.ChangeName)
    NAME_CHANGE.Paint = function( self, w, h )
        self:DrawTextEntryText(PC, PC, PC)
    end

    local NameEnter = vgui.Create('DButton',NAME_MENU)
    NAME_ENTER = NameEnter
    NAME_ENTER:SetText('')
    NAME_ENTER:SetPos(NAME_MENU:GetWide()/2 - 150, NAME_MENU:GetTall() - 75) 
    NAME_ENTER:SetSize(150, 35)
    NAME_ENTER.Paint = function( self, w, h )
        if self:IsHovered() then 
            draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
            surface.SetDrawColor(PC)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        FO.Text(FO.Language.SelectName, btn_font, w/2, h/2, PC, 1, 1)
    end

    NAME_ENTER.DoClick = function() 
        local name = NAME_CHANGE:GetValue()

        net.Start('RPNameSet')
            net.WriteString( name )
        net.SendToServer()

        NAME_MENU:AlphaTo(0, 0.2, 0, function()
            NAME_MENU:Remove()
        end)
    end

    local ExitGame = vgui.Create('DButton',NAME_MENU)
    EXIT_GAME = ExitGame
    EXIT_GAME:SetText('')
    EXIT_GAME:SetPos(NAME_MENU:GetWide()/2, NAME_MENU:GetTall() - 75) 
    EXIT_GAME:SetSize(150, 35)
    EXIT_GAME.Paint = function( self, w, h )
        if self:IsHovered() then 
            draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(PC, 5))
            surface.SetDrawColor(PC)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        FO.Text(FO.Language.ExtitGame, btn_font, w/2, h/2, PC, 1, 1)
    end

    EXIT_GAME.DoClick = function() 
        RunConsoleCommand('killserver')
    end
end)