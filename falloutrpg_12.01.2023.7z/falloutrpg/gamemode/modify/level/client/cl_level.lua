net.Receive('NotifyLevelUP', function(ply)

    local ply = net.ReadEntity()

    local NTFLevel = vgui.Create('DNotify')
    NTFLevel:SetPos(15, ScrH()/2.5)
    NTFLevel:SetSize(400, 40)
    NTFLevel:SetLife( 5 )

    if IsValid(PanelLevelUP) then PanelLevelUP:Remove() end

    local DLabelVL = vgui.Create('DLabel', NTFLevel)
    PanelLevelUP = DLabelVL
    DLabelVL:Dock(FILL)
    DLabelVL:SetColor(Color(240, 170, 80))
    DLabelVL:SetText('НОВЫЙ УРОВЕНЬ ' .. ply:GetLevel())
    DLabelVL:SetFont('SP_POINT')
    DLabelVL:SetDark(true)
    
    surface.PlaySound('UI/achievement_earned.wav')
    
    NTFLevel:AddItem(DLabelVL)

end)