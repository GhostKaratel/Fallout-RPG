net.Receive('SpecialMenu', function(ply)

local ply = net.ReadEntity()

local SpecialMenu = vgui.Create('DFrame')
SpecialMenu:SetSize(ScrW(), ScrH())
SpecialMenu:Center()
SpecialMenu:SetTitle('')
SpecialMenu:SetDraggable(false)
SpecialMenu:ShowCloseButton(false)
SpecialMenu:MakePopup()
SpecialMenu.Paint = function(self, w, h)
    draw.RoundedBox(16, w/4-5, h/10, w/2+10, h/1.25, Color(40,25,15,200))
    FO.BackgroundBlur(self, 8)
end

SpecialPanel = vgui.Create('DPanel', SpecialMenu)
SpecialPanel:SetSize(SpecialMenu:GetWide()/2, SpecialMenu:GetTall()/1.25)
SpecialPanel:Center()
function SpecialPanel:Paint(w,h)	
    FO.Image( 15, 15, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
    FO.Image( w-18, 15, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
    FO.Image( 15, h-157, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
    FO.Image( w-18, h-157, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
    draw.RoundedBox(0, 15, 15, w/4, 3, Color(240,170,80))
    draw.RoundedBox(0, w/1.4, 15, w/4 + 20, 3, Color(240,170,80))
    draw.RoundedBox(0, 15, h-30, w-30, 3, Color(240,170,80))

    draw.SimpleText( 'S.P.E.C.I.A.L.', 'SP_TITLE', w/2, 15, Color(240,170,80,255), 1, 1)
    draw.SimpleText(ply:GetSpecialPoints(), 'SP_SPECIALPOINT', w/4, h/1.2, Color(240,170,80), 1, 1)
end

local SpecialChosen
for k, v in pairs(FO.Special) do
    local SpecialButton = vgui.Create('DButton', SpecialPanel)
    SpecialButton:SetPos(50, 85 + k * 50)
    SpecialButton:SetSize(SpecialPanel:GetWide()/2.5,40)
    SpecialButton:SetText('')
    SpecialButton.Paint = function(self, w, h)  
        if self:IsHovered() then 
            draw.RoundedBox(0, 0, 0, w, h, Color(55,30,20,200))
            surface.SetDrawColor(240,170,80)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        local Points

        if v.name == 'Сила' then
            Points = ply:GetStrength()
        elseif v.name == 'Восприятие' then
            Points = ply:GetPerception()
        elseif v.name == 'Выносливость' then
            Points = ply:GetEndurance()
        elseif v.name == 'Харизма' then
            Points = ply:GetCharisma()
        elseif v.name == 'Интеллект' then
            Points = ply:GetIntellect()
        elseif v.name == 'Ловкость' then
            Points = ply:GetAgility()
        elseif v.name == 'Удача' then
            Points = ply:GetLuck()
        else
            Points = ''
        end
        
        draw.SimpleText(v.name, 'SP_NAME', 15, h/2, Color(240,170,80), 0, 1)
        draw.SimpleText(Points, 'SP_NAME', w - 15, h/2, Color(240,170,80), 2, 1)
    end

    SpecialButton.OnCursorEntered = function() 
        SpecialChosen(v)
    end

    SpecialButton.DoClick = function(self)
    end

    function SpecialChosen(v)

        if ChosenPanel then
            ChosenPanel:Remove()
			ChosenPanel = nil
        end

        ChosenPanel = vgui.Create('DPanel', SpecialPanel)
        ChosenPanel:SetPos(SpecialPanel:GetWide()/2.25 + 15, 85 )
        ChosenPanel:SetSize(SpecialPanel:GetWide()/2, SpecialPanel:GetTall() - 100)
		ChosenPanel:SetAlpha(0)
		ChosenPanel:AlphaTo(255, 0.3, 0) 
		ChosenPanel:InvalidateParent(true)
        function ChosenPanel:Paint(w, h)
            local Points

            if v.name == 'Сила' then
                Points = ply:GetStrength()
            elseif v.name == 'Восприятие' then
                Points = ply:GetPerception()
            elseif v.name == 'Выносливость' then
                Points = ply:GetEndurance()
            elseif v.name == 'Харизма' then
                Points = ply:GetCharisma()
            elseif v.name == 'Интеллект' then
                Points = ply:GetIntellect()
            elseif v.name == 'Ловкость' then
                Points = ply:GetAgility()
            elseif v.name == 'Удача' then
                Points = ply:GetLuck()
            else
                Points = ''
            end

            draw.RoundedBox(0, 0, h/2 - 25, w, 3, Color(240,170,80))
            FO.Image( w-3, h/2 - 25, 3, h/10, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
            FO.Image( w/2 - 128, -32, 256, 256, Color(240,170,80), v.material )
            draw.SimpleText(Points, 'SP_POINT', w/2, h/1.17, Color(240,170,80), 1, 1)
        end  

        SpecialDesc = ChosenPanel:Add('DLabel')
        SpecialDesc:SetPos(15,ChosenPanel:GetTall()/2 - 20)
        SpecialDesc:SetWide(ChosenPanel:GetWide()-30)
        SpecialDesc:SetText(v.description)
        SpecialDesc:SetFont('SP_DESC')
        SpecialDesc:SetContentAlignment(1)
        SpecialDesc:SetTextColor(Color(240, 170, 80))
        SpecialDesc:SetWrap(true)
        SpecialDesc:SetAutoStretchVertical(true)

    	local AddSpecial = vgui.Create('DButton', ChosenPanel)
        AddSpecial:SetText('')
    	AddSpecial:SetSize(32,32)
    	AddSpecial:SetPos(ChosenPanel:GetWide()/2 + 64, ChosenPanel:GetTall()/1.17 - 15)
		AddSpecial:IsVisible() 
		AddSpecial.Paint = function(self,w,h)
            if self:IsHovered() then  
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_increase_over.png')
            else
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_increase.png')
            end	    		
        end     

        AddSpecial.DoClick = function()
            v.add(ply)  
        end	
        
    	local ReduceSpecial = vgui.Create('DButton', ChosenPanel)
        ReduceSpecial:SetText('')
    	ReduceSpecial:SetSize(32,32)
    	ReduceSpecial:SetPos(ChosenPanel:GetWide()/2 - 96, ChosenPanel:GetTall()/1.17 - 15)
		ReduceSpecial:IsVisible() 
		ReduceSpecial.Paint = function(self,w,h)
            if self:IsHovered() then  
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_decrease_over.png') 
            else
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_decrease.png') 
            end	    		
        end    

        ReduceSpecial.DoClick = function() 
            v.reduce(ply) 
		end	

    end

    local RemovePanel = vgui.Create('DButton', SpecialPanel)
    RemovePanel:SetText('')
    RemovePanel:SetSize(100,30)
    RemovePanel:SetPos(SpecialPanel:GetWide() - 125, 25)
    RemovePanel:IsVisible() 
    RemovePanel.Paint = function(self,w,h)
        if self:IsHovered() then  
            draw.RoundedBox(0, 0, 0, w, h, Color(55,30,20,200))
            surface.SetDrawColor(240,170,80)
            surface.DrawOutlinedRect(0, 0, w, h)
        end	

        draw.SimpleText('Готово', 'SP_BTN', w/2, h/2, Color(240,170,80), 1, 1)    		
    end     

    RemovePanel.DoClick = function()   

        net.Start('ChangeSkills')
            net.WriteEntity(ply)
        net.SendToServer()

        SpecialMenu:Remove()
    end	

end  

end)