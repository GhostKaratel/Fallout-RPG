net.Receive('SkillMenu', function(ply)

local ply = net.ReadEntity()

local SkillMenu = vgui.Create('DFrame')
SkillMenu:SetSize(ScrW(), ScrH())
SkillMenu:Center()
SkillMenu:SetTitle('')
SkillMenu:SetDraggable(false)
SkillMenu:ShowCloseButton(false)
SkillMenu:MakePopup()
SkillMenu.Paint = function(self, w, h)
    draw.RoundedBox(16, w/4-5, h/21, w/2+10, h/1.1, Color(40,25,15,200))
    FO.BackgroundBlur(self, 8)
end

SkillPanel = vgui.Create('DPanel', SkillMenu)
SkillPanel:SetSize(SkillMenu:GetWide()/2, SkillMenu:GetTall()/1.1)
SkillPanel:Center()
function SkillPanel:Paint(w,h)	
    FO.Image( 15, 15, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
    FO.Image( w-18, 15, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
    FO.Image( 15, h-157, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
    FO.Image( w-18, h-157, 3, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png') 
    draw.RoundedBox(0, 15, 15, w/4, 3, Color(240,170,80))
    draw.RoundedBox(0, w/1.4, 15, w/4 + 20, 3, Color(240,170,80))
    draw.RoundedBox(0, 15, h-30, w-30, 3, Color(240,170,80))

    draw.SimpleText( 'Осталось очков: '..ply:GetSkillPoints(), 'SP_TITLE', w/2, 15, Color(240,170,80,255), 1, 1)
end

local SkillChosen
for k, v in pairs(FO.Skills) do
    local SkillButton = vgui.Create('DButton', SkillPanel)
    SkillButton:SetPos(50, 85 + k * 50)
    SkillButton:SetSize(SkillPanel:GetWide()/2.5,40)
    SkillButton:SetText('')
    SkillButton.Paint = function(self, w, h)  
        if self:IsHovered() then 
            draw.RoundedBox(0, 0, 0, w, h, Color(55,30,20,200))
            surface.SetDrawColor(240,170,80)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        local Points

        if v.name == 'Бартер' then
            Points = ply:GetBarter()
        elseif v.name == 'Без оружия' then
            Points = ply:GetUnarmed()
        elseif v.name == 'Взлом' then
            Points = ply:GetBreaking()
        elseif v.name == 'Взрывчатка' then
            Points = ply:GetExplosive()
        elseif v.name == 'Выживание' then
            Points = ply:GetSurvival()
        elseif v.name == 'Красноречие' then
            Points = ply:GetEloquence()
        elseif v.name == 'Медицина' then
            Points = ply:GetMedicine()
        elseif v.name == 'Наука' then
            Points = ply:GetScience()
        elseif v.name == 'Оружие' then
            Points = ply:GetGun()
        elseif v.name == 'Ремонт' then
            Points = ply:GetRepair()
        elseif v.name == 'Скрытность' then
            Points = ply:GetStealth()
        elseif v.name == 'Холодное оружие' then
            Points = ply:GetColdWeapons()
        elseif v.name == 'Энергооружие' then
            Points = ply:GetEnergyWeapons()
        else
            Points = ''
        end
        
        draw.SimpleText(v.name, 'SP_NAME', 15, h/2, Color(240,170,80), 0, 1)
        draw.SimpleText(Points, 'SP_NAME', w - 15, h/2, Color(240,170,80), 2, 1)
    end

    SkillButton.OnCursorEntered = function() 
        SkillChosen(v)
    end

    SkillButton.DoClick = function(self)
    end

    function SkillChosen(v)

        if ChosenPanel then
            ChosenPanel:Remove()
			ChosenPanel = nil
        end

        ChosenPanel = vgui.Create('DPanel', SkillPanel)
        ChosenPanel:SetPos(SkillPanel:GetWide()/2.25 + 15, 85 )
        ChosenPanel:SetSize(SkillPanel:GetWide()/2, SkillPanel:GetTall() - 100)
		ChosenPanel:SetAlpha(0)
		ChosenPanel:AlphaTo(255, 0.3, 0) 
		ChosenPanel:InvalidateParent(true)
        function ChosenPanel:Paint(w, h)
            local Points

            if v.name == 'Бартер' then
                Points = ply:GetBarter()
            elseif v.name == 'Без оружия' then
                Points = ply:GetUnarmed()
            elseif v.name == 'Взлом' then
                Points = ply:GetBreaking()
            elseif v.name == 'Взрывчатка' then
                Points = ply:GetExplosive()
            elseif v.name == 'Выживание' then
                Points = ply:GetSurvival()
            elseif v.name == 'Красноречие' then
                Points = ply:GetEloquence()
            elseif v.name == 'Медицина' then
                Points = ply:GetMedicine()
            elseif v.name == 'Наука' then
                Points = ply:GetScience()
            elseif v.name == 'Оружие' then
                Points = ply:GetGun()
            elseif v.name == 'Ремонт' then
                Points = ply:GetRepair()
            elseif v.name == 'Скрытность' then
                Points = ply:GetStealth()
            elseif v.name == 'Холодное оружие' then
                Points = ply:GetColdWeapons()
            elseif v.name == 'Энергооружие' then
                Points = ply:GetEnergyWeapons()
            else
                Points = ''
            end

            draw.RoundedBox(0, 0, h/2 - 25, w, 3, Color(240,170,80))
            FO.Image( w-3, h/2 - 25, 3, h/10, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') 
            FO.Image( w/2 - 128, -16, 256, 256, Color(240,170,80), v.material )
            draw.SimpleText(Points, 'SP_POINT', w/2, h/1.17, Color(240,170,80), 1, 1)
        end  

        SkillDesc = ChosenPanel:Add('DLabel')
        SkillDesc:SetPos(15,ChosenPanel:GetTall()/2 - 20)
        SkillDesc:SetWide(ChosenPanel:GetWide()-30)
        SkillDesc:SetText(v.description)
        SkillDesc:SetFont('SP_DESC')
        SkillDesc:SetContentAlignment(1)
        SkillDesc:SetTextColor(Color(240, 170, 80))
        SkillDesc:SetWrap(true)
        SkillDesc:SetAutoStretchVertical(true)

    	local AddSkill = vgui.Create('DButton', ChosenPanel)
        AddSkill:SetText('')
    	AddSkill:SetSize(32,32)
    	AddSkill:SetPos(ChosenPanel:GetWide()/2 + 64, ChosenPanel:GetTall()/1.17 - 15)
		AddSkill:IsVisible() 
		AddSkill.Paint = function(self,w,h)
            if self:IsHovered() then  
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_increase_over.png') 
            else
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_increase.png') 
            end	    		
        end     

        AddSkill.DoClick = function()
            v.add(ply)  
        end	
        
    	local ReduceSkill = vgui.Create('DButton', ChosenPanel)
        ReduceSkill:SetText('')
    	ReduceSkill:SetSize(32,32)
    	ReduceSkill:SetPos(ChosenPanel:GetWide()/2 - 96, ChosenPanel:GetTall()/1.17 - 15)
		ReduceSkill:IsVisible() 
		ReduceSkill.Paint = function(self,w,h)
            if self:IsHovered() then  
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_decrease_over.png') 
            else
                FO.Image( -16, -16, w*2, h*2, Color(240,170,80), 'shared/arrow/adjust_decrease.png') 
            end	    		
        end     

        ReduceSkill.DoClick = function() 
            v.reduce(ply) 
		end	

    end

    local RemovePanel = vgui.Create('DButton', SkillPanel)
    RemovePanel:SetText('')
    RemovePanel:SetSize(100,30)
    RemovePanel:SetPos(SkillPanel:GetWide() - 125, 25)
    RemovePanel:IsVisible() 
    RemovePanel.Paint = function(self,w,h)
        if self:IsHovered() then  
            draw.RoundedBox(0, 0, 0, w, h, Color(55,30,20,200))
            surface.SetDrawColor(240,170,80)
            surface.DrawOutlinedRect(0, 0, w, h)
        end	

        draw.SimpleText('Готово', 'SP_BTN', w/2, h/2, Color(240,170,80), 1, 1)    		
    end     

    RemovePanel.DoClick = function() 
        SkillMenu:Remove()
    end	

end  

end)