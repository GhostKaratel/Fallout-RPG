local Meta = FindMetaTable('Player')

function Meta:GetStrength()
	return tonumber(self:GetNWInt('Strength', 0))
end

function Meta:GetPerception()
	return tonumber(self:GetNWInt('Perception', 0))
end

function Meta:GetEndurance()
	return tonumber(self:GetNWInt('Endurance', 0))
end

function Meta:GetCharisma()
	return tonumber(self:GetNWInt('Charisma', 0))
end

function Meta:GetIntellect()
	return tonumber(self:GetNWInt('Intellect', 0))
end

function Meta:GetAgility()
	return tonumber(self:GetNWInt('Agility', 0))
end

function Meta:GetLuck()
	return tonumber(self:GetNWInt('Luck', 0))
end

function Meta:GetSpecialPoints()
	return tonumber(self:GetNWInt('SpecialPoints', 0))
end

function Meta:GetAllSpecial()
	return tonumber(self:GetStrength()+self:GetPerception()+self:GetEndurance()+self:GetCharisma()+self:GetIntellect()+self:GetAgility())
end