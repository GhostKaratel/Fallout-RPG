/* 

FO.Perks = {
    FastShot = {
        name = 'Стрельба навскидку',
        level = 1,
        desc = [[Скорость стрельбы огнестрельного и энергетического оружия увеличивается на 20%, но снижается меткость на те же 20%.]],
        effect = 20,
        material = Material('fallout/perks/perk_fast_shot.png'),
        func = function() 
        
        end,
    },

    FourEyes = {
        name = 'Четыре глаза',
        level = 1,
        desc = [[При ношении очков вы получаете +1 к восприятию, без очков -1.]],
        effect = 1,
        material = Material('fallout/perks/perk_four_eyes.png'),
        func = function() 
        
        end,
    },

    GoodNatured = {
        name = 'Добрая душа',
        level = 1,
        desc = [[+5 к мирным умениям и -5 к боевым.]],
        effect = 5,
        material = Material('fallout/perks/perk_good_natured.png'),
        func = function() 
        
        end,
    },

    HeavyHanded = {
        name = 'Тяжелая рука',
        level = 1,
        desc = [[Обычные удары оружием ближнего боя и кулаками наносят больше повреждений, но критические удары бьют слабее.]],
        effect = 5,
        material = Material('fallout/perks/perk_heavy_handed.png'),
        func = function() 
        
        end,
    },

    SmallFrame = {
        name = 'Шустрик',
        level = 1,
        desc = [[+1 к ловкости (AGI), но шанс получить увечье конечностей выше.]],
        effect = 1,
        material = Material('fallout/perks/perk_small_frame.png'),
        func = function() 
        
        end,
    },

    TriggerDiscipline = {
        name = 'Техника спуска',
        level = 1,
        desc = [[Скорость стрельбы огнестрельного и энергетического оружия снижается на 20%, но увеличивается меткость на те же 20%.]],
        effect = 20,
        material = Material('fallout/perks/perk_trigger_discipline.png'),
        func = function() 
        
        end,
    },

    IntenseTraining = {
        name = 'Интенсивная тренировка',
        level = 2,
        desc = [[+1 к любой основной характеристике.]],
        effect = 1,
        material = Material('fallout/perks/perk_intense training.png'),
        func = function() 
        
        end,
    },

    SwiftLearner = {
        name = 'Прилежный ученик',
        level = 2,
        desc = [[+10% к получаемому опыту.]],
        effect = 10,
        material = Material('fallout/perks/perk_swift learner.png'),
        func = function() 
        
        end,
    },
    
    RapidReload = {
        name = 'Быстрая перезарядка',
        level = 2,
        desc = [[+25% к скорости перезарядки огнестрельного оружия.]],
        effect = 25,
        material = Material('fallout/perks/perk_rapid_reload.png'),
        func = function() 
        
        end,
    },

    Hunter = {
        name = 'Охотник',
        level = 2,
        desc = [[Животные получают на 75% больше урона от критических ударов.]],
        effect = 75,
        material = Material('fallout/perks/perk_hunter.png'),
        func = function() 
        
        end,
    },

    Educated = {
        name = 'Образованный',
        level = 4,
        desc = [[+2 очка навыка при каждом новом уровне.]],
        effect = 2,
        material = Material('fallout/perks/perk_educated.png'),
        func = function() 
        
        end,
    },

    Entomologist = {
        name = 'Энтомолог',
        level = 4,
        desc = [[+50% повреждений по мутировавшим насекомым.]],
        effect = ,
        material = Material('fallout/perks/perk_entomologist.png'),
        func = function() 
        
        end,
    },

    RadChild = {
        name = 'Дитя радиации',
        level = 4,
        desc = [[Чем выше уровень вашего облучения, тем больше бонус к лечению.]],
        effect = 5,
        material = Material('fallout/perks/perk_rad_child.png'),
        func = function() 
        
        end,
    },

    RunGun = {
        name = 'Беги-стреляй',
        level = 4,
        desc = [[Уменьшает разброс при стрельбе из одноручного оружия на ходу.]],
        effect = 2,
        material = Material('fallout/perks/perk_run_n_gun.png'),
        func = function() 
        
        end,
    },

    TravelLight = {
        name = 'Путешествие налегке',
        level = 4,
        desc = [[+10% к скорости передвижения, если одета легкая броня или броня отсутствует.]],
        effect = 10,
        material = Material('fallout/perks/perk_travel_light.png'),
        func = function() 
        
        end,
    },

    DemolitionExpert = {
        name = 'Эксперт-сапер',
        level = 6,
        desc = [[+20% к повреждениям при использовании взрывчатки.]],
        effect = 20,
        material = Material('fallout/perks/perk_demolition expert.png'),
        func = function() 
        
        end,
    },

    FortuneFinder = {
        name = 'Кладоискатель',
        level = 6,
        desc = [[Находите больше крышек.]],
        effect = 6,
        material = Material('fallout/perks/perk_fortune finder.png'),
        func = function() 
        
        end,
    },

    LeadBelly = {
        name = 'Свинцовое брюхо',
        level = 6,
        desc = [[-50% радиации от еды и воды.]],
        effect = 50,
        material = Material('fallout/perks/perk_lead belly.png'),
        func = function() 
        
        end,
    },

    Cowboy = {
        name = 'Ковбой',
        level = 8,
        desc = [[Увеличивает повреждения при использовании динамита, тесаков, ножей, револьверов и оружия с рычажным взводом.]],
        effect = 5,
        material = Material('fallout/perks/perk_cowboy.png'),
        func = function() 
        
        end,
    },

    PackRat = {
        name = 'Барахольщик',
        level = 8,
        desc = [[В 2 раза снижается вес вещей до 2 фунтов.]],
        effect = 2,
        material = Material('fallout/perks/perk_pack_rat.png'),
        func = function() 
        
        end,
    },

    QuickDraw = {
        name = 'Быстрая реакция',
        level = 8,
        desc = [[+50% к скорости доставания и убирания оружия.]],
        effect = 50,
        material = Material('fallout/perks/perk_quick_draw.png'),
        func = function() 
        
        end,
    },

    RadResistance = {
        name = 'Рад-сопротивление',
        level = 8,
        desc = [[+25% к сопротивлению радиации.]],
        effect = 25,
        material = Material('fallout/perks/perk_rad resistance.png'),
        func = function() 
        
        end,
    },

    Scrounger = {
        name = 'Халявщик',
        level = 8,
        desc = [[Находите больше патронов.]],
        effect = 5,
        material = Material('fallout/perks/perk_scrounger.png'),
        func = function() 
        
        end,
    },

    StrongBack = {
        name = 'Крепкий хребет',
        level = 8,
        desc = [[+50 к максимальному переносимому весу.]],
        effect = 50,
        material = Material('fallout/perks/perk_strong back.png'),
        func = function() 
        
        end,
    },

    HereAndNow = {
        name = 'Здесь и сейчас',
        level = 10,
        desc = [[+1 уровень.]],
        effect = 1,
        material = Material('fallout/perks/perk_here and now.png'),
        func = function() 
        
        end,
    },

    FastMetabolism = {
        name = 'Ускоренный метаболизм',
        level = 12,
        desc = [[Cтимпаки восстанавливают на 20% здоровья больше.]],
        effect = 20,
        material = Material('fallout/perks/perk_fast_metabolism.png'),
        func = function() 
        
        end,
    },

    LifeGiver = {
        name = 'Фонтан жизни',
        level = 12,
        desc = [[+30 к здоровью.]],
        effect = 30,
        material = Material('fallout/perks/perk_life giver.png'),
        func = function() 
        
        end,
    },

    AdamantiumSkeleton = {
        name = 'Алмазный скелет',
        level = 14,
        desc = [[Конечности получают на 50% меньше повреждений.]],
        effect = 50,
        material = Material('fallout/perks/perk_adamantium_skeleton.png'),
        func = function() 
        
        end,
    },

    Chemist = {
        name = 'Химик',
        level = 14,
        desc = [[Длительность действия всех лекарств и наркотиков увеличивается в 2 раза.]],
        effect = 2,
        material = Material('fallout/perks/perk_chemist.png'),
        func = function() 
        
        end,
    },

    Slayer = {
        name = 'Быстрый удар',
        level = 24,
        desc = [[+30 % к скорости ударов оружием ближнего боя.]],
        effect = 30,
        material = Material('fallout/perks/perk_slayer.png'),
        func = function() 
        
        end,
    },

    PowerArmor = {
        name = 'Ношение силовой брони',
        level = 30,
        desc = [[Возможность надевать силовую броню.]],
        effect = false,
        material = Material('fallout/perks/power_armor.png'),
        func = function() 
        
        end,
    }
} */