FO.Skills = {}

FO.Skills[ 0 ] = 
{
    name = 'Бартер',
    material = FO.Materials.barter,
    description = [[Навык 'Бартер' влияет на то, по каким ценам вы будете покупать и продавать. Чем выше ваш навык бартера, тем дешевле вам удастся что-то купить.]],
    add = function(ply) 
        net.Start('BarterChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('BarterChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 1 ] = 
{
    name = 'Без оружия',
    material = FO.Materials.unarmed,
    description = [[Навык 'Без оружия' используется в схватке без оружия или с таким оружием, как обычные или силовые кастеты и перчатки.]],
    add = function(ply) 
        net.Start('UnarmedChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('UnarmedChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 2 ] = 
{
    name = 'Взлом',
    material = FO.Materials.lockpick,
    description = [[Навык 'Взлом' используется для открывания запертых дверей и контейнеров.]],
    add = function(ply) 
        net.Start('BreakingChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('BreakingChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 3 ] = 
{
    name = 'Взрывчатка',
    material = FO.Materials.explosives,
    description = [[Навык «Взрывчатка» определяет мощность установленных персонажем мин, шанс на обезвреживание вражеских ловушек со взрывчаткой и эффективность брошенных им гранат. Чем выше навык, тем больше урон, который наносят мины и гранаты.]],
    add = function(ply) 
        net.Start('ExplosiveChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('ExplosiveChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 4 ] = 
{
    name = 'Выживание',
    material = FO.Materials.survival,
    description = [[Навык «Выживание» определяет, сколько очков здоровья вы восстанавливаете при употребляя пищу и напитки. Он так же помогает вам готовить еду у лагерного костра и тд.]],
    add = function(ply) 
        net.Start('SurvivalChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('SurvivalChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 5 ] = 
{
    name = 'Красноречие',
    material = FO.Materials.speech,
    description = [[По навыку «Красноречие» определяется, насколько вы можете влиять на собеседника во время разговора и получать доступ к информации, которая иначе осталась бы для вас тайной.]],
    add = function(ply) 
        net.Start('EloquenceChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('EloquenceChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 6 ] = 
{
    name = 'Медицина',
    material = FO.Materials.medicine,
    description = [[Навык «Медицина» определяет, сколько очков здоровья вы восстанавливаете при использовании стимулятора, а также эффективность Рад-X и антирадина.]],
    add = function(ply) 
        net.Start('MedicineChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('MedicineChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 7 ] = 
{
    name = 'Наука',
    material = FO.Materials.science,
    description = [[Навык «Наука» представляет ваши научные знания в целом и используется в первую очередь для взлома компьютеров. Этот навык также даёт возможность вторичной переработки боеприпасов энергетического оружия на верстаках.]],
    add = function(ply) 
        net.Start('ScienceChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('ScienceChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 8 ] = 
{
    name = 'Оружие',
    material = FO.Materials.small_guns,
    description = [[Навык «Оружие» определяет насколько эффективно вы можете пользоваться всем всеми видами оружия, использующего обычные боеприпасы.]],
    add = function(ply) 
        net.Start('WeaponChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('WeaponChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 9 ] = 
{
    name = 'Ремонт',
    material = FO.Materials.repair,
    description = [[Навык «Ремонт» позволяет вам поддерживать рабочее состояние оружия и снаряжения. Кроме того, навык ремонта позволяет создавать вам предметы и боеприпасы на верстаках для снаряжение патронов.]],
    add = function(ply) 
        net.Start('RepairChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('RepairChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 10 ] = 
{
    name = 'Скрытность',
    material = FO.Materials.sneak,
    description = [[Чем выше ваш навык скрытности, тем легче вам оставаться незамеченным, легче украсть предмет или залезть кому-то в карман. При успешной атаке с использованием этого навыка вам автоматически засчитывается критическое попадание.]],
    add = function(ply) 
        net.Start('StealthChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('StealthChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 11 ] = 
{
    name = 'Холодное оружие',
    material = FO.Materials.melee_weapons,
    description = [[Навык «Холодное оружие» определяет, насколько эффективно вы можете пользоваться оружием ближнего боя — от свинцовой трубы до высокотехнологичной суперкувалды.]],
    add = function(ply) 
        net.Start('ColdWeaponsChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('ColdWeaponsChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Skills[ 12 ] = 
{
    name = 'Энергооружие',
    material = FO.Materials.energy_weapons,
    description = [[Навык «Энергооружие» определяет, насколько эффективно вы можете пользоваться в бою таким оружием, как лазерный пистолет, лазерная винтовка, плазменная винтовка или плазменный пистолет.]],
    add = function(ply) 
        net.Start('EnergyWeaponsChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('EnergyWeaponsChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

table.sort( FO.Skills, function( a, b ) return a.name < b.name end )