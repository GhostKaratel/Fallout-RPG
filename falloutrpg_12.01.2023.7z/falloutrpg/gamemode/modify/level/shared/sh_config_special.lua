FO.Special = {}

FO.Special[ 0 ] = 
{
    name = 'Сила',
    material = FO.Materials.s_strength,
    description = [[Сила определяет ваши физические возможности. От неё зависит грузоподъёмность, рукопашный бой, навык владения тяжёлым оружием и навыки «Без оружия» и «Холодное оружие». Высокий показатель силы хорош для брутальных персонажей.]],
    add = function(ply) 
        net.Start('StrengthChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('StrengthChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 1 ] = 
{
    name = 'Восприятие',
    material = FO.Materials.s_perception,
    description = [[Высокое восприятие улучшает навыки 'Взрывчатка', 'Взлома', 'Энергооружие', а также ускоряет обнаружение врагов на компасе.]],
    add = function(ply) 
        net.Start('PerceptionChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('PerceptionChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 2 ] = 
{
    name = 'Выносливость',
    material = FO.Materials.s_endurance,
    description = [[Выносливость - мера вашей физической подготовки. Высокая выносливость даёт прибавку к здоровью, навыкам 'Выживание' и 'Без оружия', и устойчивость к вредным воздействиям.]],
    add = function(ply) 
        net.Start('EnduranceChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('EnduranceChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 3 ] = 
{
    name = 'Харизма',
    material = FO.Materials.s_charisma,
    description = [[Высокая харизма улучшает отношение окружающих людей к вам и даёт прибавку к навыкам 'Бартер' и 'Красноречие'.]],
    add = function(ply) 
        net.Start('CharismaChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('CharismaChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 4 ] = 
{
    name = 'Интеллект',
    material = FO.Materials.s_intelligence,
    description = [[Интеллект влияет на навыки 'Ремонт', 'Наука' и 'Медицина'. Чем выше ваш интеллект, тем больше очков навыков вы получаете при достижении нового уровня.]],
    add = function(ply) 
        net.Start('IntellectChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('IntellectChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 5 ] = 
{
    name = 'Ловкость',
    material = FO.Materials.s_agility,
    description = [[Ловкость влияет на навыки 'Оружие' и 'Скрытность', а также на количество очков действия в режиме V.A.T.S.]],
    add = function(ply) 
        net.Start('AgilityChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('AgilityChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

FO.Special[ 6 ] = 
{
    name = 'Удача',
    material = FO.Materials.s_luck,
    description = [[При высокой удаче все ваши навыки чуть улучшаются. Кроме того, удачливые персонажи имеют больший шанс критического попадания из всех видов оружия.]],
    add = function(ply) 
        net.Start('LuckChange')
            net.WriteEntity(ply)
            net.WriteBool(true)
        net.SendToServer()
    end,
    reduce = function(ply) 
        net.Start('LuckChange')
            net.WriteEntity(ply)
            net.WriteBool(false)
        net.SendToServer()
    end,
}

table.sort( FO.Special, function( a, b ) return a.name < b.name end )