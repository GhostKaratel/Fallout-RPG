local Meta = FindMetaTable('Player')

function Meta:GetLevel()
	return tonumber(self:GetNWInt('Level', 1))
end

function Meta:GetExp()
	return tonumber(self:GetNWInt('Exp', 0))
end

function Meta:GetMaxExp()
	return tonumber(25*(3*self:GetLevel()+2)*(self:GetLevel()))
end