local Meta = FindMetaTable('Player')

function Meta:GetBarter()
	return tonumber(self:GetNWInt('Barter', 0))
end

function Meta:GetUnarmed()
	return tonumber(self:GetNWInt('Unarmed', 0))
end

function Meta:GetBreaking()
	return tonumber(self:GetNWInt('Breaking', 0))
end

function Meta:GetExplosive()
	return tonumber(self:GetNWInt('Explosive', 0))
end

function Meta:GetSurvival()
	return tonumber(self:GetNWInt('Survival', 0))
end

function Meta:GetEloquence()
	return tonumber(self:GetNWInt('Eloquence', 0))
end

function Meta:GetMedicine()
	return tonumber(self:GetNWInt('Medicine', 0))
end

function Meta:GetScience()
	return tonumber(self:GetNWInt('Science', 0))
end

function Meta:GetGun()
	return tonumber(self:GetNWInt('Weapon', 0))
end

function Meta:GetRepair()
	return tonumber(self:GetNWInt('Repair', 0))
end

function Meta:GetStealth()
	return tonumber(self:GetNWInt('Stealth', 0))
end

function Meta:GetColdWeapons()
	return tonumber(self:GetNWInt('ColdWeapons', 0))
end

function Meta:GetEnergyWeapons()
	return tonumber(self:GetNWInt('EnergyWeapons', 0))
end

function Meta:GetSkillPoints()
	return tonumber(self:GetNWInt('SkillPoints', 0 ))
end