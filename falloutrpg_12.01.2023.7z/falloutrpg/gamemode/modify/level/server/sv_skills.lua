util.AddNetworkString('BarterChange')
util.AddNetworkString('UnarmedChange')
util.AddNetworkString('BreakingChange')
util.AddNetworkString('ExplosiveChange')
util.AddNetworkString('SurvivalChange')
util.AddNetworkString('EloquenceChange')
util.AddNetworkString('MedicineChange')
util.AddNetworkString('ScienceChange')
util.AddNetworkString('WeaponChange')
util.AddNetworkString('RepairChange')
util.AddNetworkString('StealthChange')
util.AddNetworkString('ColdWeaponsChange')
util.AddNetworkString('EnergyWeaponsChange')
util.AddNetworkString('ChangeSkills')
util.AddNetworkString('ChangePointSkills')

util.AddNetworkString('SkillMenu')

net.Receive('BarterChange', function(len, ply)
    local bool = net.ReadBool()
    
    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetBarter() != 100 then
                ply:AddBarter(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints() then
            if ply:GetBarter() != 0 and ply:GetBarter() != ply:GetSaveBarter() then
                ply:ReduceBarter(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('UnarmedChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetUnarmed() != 100 then
                ply:AddUnarmed(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints() then
            if ply:GetUnarmed() != 0 and ply:GetUnarmed() != ply:GetSaveUnarmed() then
                ply:ReduceUnarmed(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('BreakingChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetBreaking() != 100 then
                ply:AddBreaking(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints() then
            if ply:GetBreaking() != 0 and ply:GetBreaking() != ply:GetSaveBreaking() then
                ply:ReduceBreaking(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('ExplosiveChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetExplosive() != 100 then
                ply:AddExplosive(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints() then
            if ply:GetExplosive() != 0 and ply:GetExplosive() != ply:GetSaveExplosive() then
                ply:ReduceExplosive(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('SurvivalChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetSurvival() != 100 then
                ply:AddSurvival(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints() then
            if ply:GetSurvival() != 0 and ply:GetSurvival() != ply:GetSaveSurvival() then
                ply:ReduceSurvival(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('EloquenceChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetEloquence() != 100 then
                ply:AddEloquence(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetEloquence() != 0 and ply:GetEloquence() != ply:GetSaveEloquence() then
                ply:ReduceEloquence(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('MedicineChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetMedicine() != 100 then
                ply:AddMedicine(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetMedicine() != 0 and ply:GetMedicine() != ply:GetSaveMedicine() then
                ply:ReduceMedicine(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('ScienceChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetScience() != 100 then
                ply:AddScience(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetScience() != 0 and ply:GetScience() != ply:GetSaveScience() then
                ply:ReduceScience(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('WeaponChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetGun() != 100 then
                ply:AddWeapon(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetGun() != 0 and ply:GetGun() != ply:GetSaveWeapon() then
                ply:ReduceWeapon(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('RepairChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetRepair() != 100 then
                ply:AddRepair(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetRepair() != 0 and ply:GetRepair() != ply:GetSaveRepair() then
                ply:ReduceRepair(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('StealthChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetStealth() != 100 then
                ply:AddStealth(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetStealth() != 0 and ply:GetStealth() != ply:GetSaveStealth() then
                ply:ReduceStealth(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('ColdWeaponsChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetColdWeapons() != 100 then
                ply:AddColdWeapons(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetColdWeapons() != 0 and ply:GetColdWeapons() != ply:GetSaveColdWeapons() then
                ply:ReduceColdWeapons(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

net.Receive('EnergyWeaponsChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSkillPoints() > 0 then
            if ply:GetEnergyWeapons() != 100 then
                ply:AddEnergyWeapons(1)
                ply:ReduceSkillPoints(1)
            end
        end
    else
        if ply:GetSkillPoints() != ply:GetSaveSkillPoints()then
            if ply:GetEnergyWeapons() != 0 and ply:GetEnergyWeapons() != ply:GetSaveEnergyWeapons() then
                ply:ReduceEnergyWeapons(1)
                ply:AddSkillPoints(1)
            end
        end
    end
end)

local Meta = FindMetaTable('Player')

----------------------
    -- SET META --
----------------------

function Meta:SetBarter(num)
	self:SetNWInt('Barter', math.Round(math.Clamp( num, 0 , 100 ))) -- Бартер
end

function Meta:SetUnarmed(num)
	self:SetNWInt('Unarmed', math.Round(math.Clamp( num, 0, 100 ))) -- Без оружия
end

function Meta:SetBreaking(num)
	self:SetNWInt('Breaking', math.Round(math.Clamp( num, 0, 100 ))) -- Взлом
end

function Meta:SetExplosive(num)
	self:SetNWInt('Explosive', math.Round(math.Clamp( num, 0, 100 ))) -- Взрывчатка
end

function Meta:SetSurvival(num)
    self:SetNWInt('Survival', math.Round(math.Clamp( num, 0, 100 ))) -- Выживание
end

function Meta:SetEloquence(num)
	self:SetNWInt('Eloquence', math.Round(math.Clamp( num, 0, 100 ))) -- Красноречие
end

function Meta:SetMedicine(num)
    self:SetNWInt('Medicine', math.Round(math.Clamp( num, 0, 100 ))) -- Медицина
end

function Meta:SetScience(num)
	self:SetNWInt('Science', math.Round(math.Clamp( num, 0, 100 ))) -- Наука
end

function Meta:SetWeapon(num)
	self:SetNWInt('Weapon', math.Round(math.Clamp( num, 0, 100 ))) -- Оружие
end

function Meta:SetRepair(num)
	self:SetNWInt('Repair', math.Round(math.Clamp( num, 0, 100 ))) -- Ремонт
end

function Meta:SetStealth(num)
	self:SetNWInt('Stealth', math.Round(math.Clamp( num, 0, 100 ))) -- Скрытность
end

function Meta:SetColdWeapons(num)
	self:SetNWInt('ColdWeapons', math.Round(math.Clamp( num, 0, 100 ))) -- Холодное оружие
end

function Meta:SetEnergyWeapons(num)
	self:SetNWInt('EnergyWeapons', math.Round(math.Clamp( num, 0, 100 ))) -- Энергооружие
end

function Meta:SetSkillPoints(num)
	self:SetNWInt('SkillPoints', num ) -- Очки навыков
end

----------------------
    -- ADD META --
----------------------

function Meta:AddBarter(num)
    local Barter = self:GetBarter()
    self:SetBarter(Barter + num)
end

function Meta:AddUnarmed(num)
    local Unarmed = self:GetUnarmed()
    self:SetUnarmed(Unarmed + num)
end

function Meta:AddBreaking(num)
    local Breaking = self:GetBreaking()
    self:SetBreaking(Breaking + num)
end

function Meta:AddExplosive(num)
    local Explosive = self:GetExplosive()
    self:SetExplosive(Explosive + num)
end

function Meta:AddSurvival(num)
    local Survival = self:GetSurvival()
    self:SetSurvival(Survival + num)
end

function Meta:AddEloquence(num)
    local Eloquence = self:GetEloquence()
    self:SetEloquence(Eloquence + num)
end

function Meta:AddMedicine(num)
    local Medicine = self:GetMedicine()
    self:SetMedicine(Medicine + num)
end

function Meta:AddScience(num)
    local Science = self:GetScience()
    self:SetScience(Science + num)
end

function Meta:AddWeapon(num)
    local Weapon = self:GetGun()
    self:SetWeapon(Weapon + num)
end

function Meta:AddRepair(num)
    local Repair = self:GetRepair()
    self:SetRepair(Repair + num)
end

function Meta:AddStealth(num)
    local Stealth = self:GetStealth()
    self:SetStealth(Stealth + num)
end

function Meta:AddColdWeapons(num)
    local ColdWeapons = self:GetColdWeapons()
    self:SetColdWeapons(ColdWeapons + num)
end

function Meta:AddEnergyWeapons(num)
    local EnergyWeapons = self:GetEnergyWeapons()
    self:SetEnergyWeapons(EnergyWeapons + num)
end

function Meta:AddSkillPoints(num)
    local SkillPoints = self:GetSkillPoints()
    self:SetSkillPoints(SkillPoints + num)
end

---------------------
  -- REDUCE META --
---------------------

function Meta:ReduceBarter(num)
    local Barter = self:GetBarter()
    self:SetBarter(Barter - num)
end

function Meta:ReduceUnarmed(num)
    local Unarmed = self:GetUnarmed()
    self:SetUnarmed(Unarmed - num)
end

function Meta:ReduceBreaking(num)
    local Breaking = self:GetBreaking()
    self:SetBreaking(Breaking - num)
end

function Meta:ReduceExplosive(num)
    local Explosive = self:GetExplosive()
    self:SetExplosive(Explosive - num)
end

function Meta:ReduceSurvival(num)
    local Survival = self:GetSurvival()
    self:SetSurvival(Survival - num)
end

function Meta:ReduceEloquence(num)
    local Eloquence = self:GetEloquence()
    self:SetEloquence(Eloquence - num)
end

function Meta:ReduceMedicine(num)
    local Medicine = self:GetMedicine()
    self:SetMedicine(Medicine - num)
end

function Meta:ReduceScience(num)
    local Science = self:GetScience()
    self:SetScience(Science - num)
end

function Meta:ReduceWeapon(num)
    local Weapon = self:GetGun()
    self:SetWeapon(Weapon - num)
end

function Meta:ReduceRepair(num)
    local Repair = self:GetRepair()
    self:SetRepair(Repair - num)
end

function Meta:ReduceStealth(num)
    local Stealth = self:GetStealth()
    self:SetStealth(Stealth - num)
end

function Meta:ReduceColdWeapons(num)
    local ColdWeapons = self:GetColdWeapons()
    self:SetColdWeapons(ColdWeapons - num)
end

function Meta:ReduceEnergyWeapons(num)
    local EnergyWeapons = self:GetEnergyWeapons()
    self:SetEnergyWeapons(EnergyWeapons - num)
end

function Meta:ReduceSkillPoints(num)
    local SkillPoints = self:GetSkillPoints()
    self:SetSkillPoints(SkillPoints - num)
end

---------------------
   -- SAVE META --
---------------------

function Meta:SaveBarter()
    local Barter = self:GetBarter()
    self:SetPData('Barter', Barter)
end

function Meta:SaveUnarmed()
    local Unarmed = self:GetUnarmed()
    self:SetPData('Unarmed', Unarmed)
end

function Meta:SaveBreaking()
    local Breaking = self:GetBreaking()
    self:SetPData('Breaking', Breaking)
end

function Meta:SaveExplosive()
    local Explosive = self:GetExplosive()
    self:SetPData('Explosive', Explosive)
end

function Meta:SaveSurvival()
    local Survival = self:GetSurvival()
    self:SetPData('Survival', Survival)
end

function Meta:SaveEloquence()
    local Eloquence = self:GetEloquence()
    self:SetPData('Eloquence', Eloquence)
end

function Meta:SaveMedicine()
    local Medicine = self:GetMedicine()
    self:SetPData('Medicine', Medicine)
end

function Meta:SaveScience()
    local Science = self:GetScience()
    self:SetPData('Science', Science)
end

function Meta:SaveWeapon()
    local Weapon = self:GetGun()
    self:SetPData('Weapon', Weapon)
end

function Meta:SaveRepair()
    local Repair = self:GetRepair()
    self:SetPData('Repair', Repair)
end

function Meta:SaveStealth()
    local Stealth = self:GetStealth()
    self:SetPData('Stealth', Stealth)
end

function Meta:SaveColdWeapons()
    local ColdWeapons = self:GetColdWeapons()
    self:SetPData('ColdWeapons', ColdWeapons)
end

function Meta:SaveEnergyWeapons()
    local EnergyWeapons = self:GetEnergyWeapons()
    self:SetPData('EnergyWeapons', EnergyWeapons)
end

function Meta:SaveSkillPoints()
    local SkillPoints = self:GetSkillPoints()
    self:SetPData('SkillPoints', SkillPoints)
end

------------------------
   -- GETSAVE META --
------------------------

function Meta:GetSaveBarter()
    return tonumber(self:GetPData('Barter'))
end

function Meta:GetSaveUnarmed()
    return tonumber(self:GetPData('Unarmed'))
end

function Meta:GetSaveBreaking()
    return tonumber(self:GetPData('Breaking'))
end

function Meta:GetSaveExplosive()
    return tonumber(self:GetPData('Explosive'))
end

function Meta:GetSaveSurvival()
    return tonumber(self:GetPData('Survival'))
end

function Meta:GetSaveEloquence()
    return tonumber(self:GetPData('Eloquence'))
end

function Meta:GetSaveMedicine()
    return tonumber(self:GetPData('Medicine'))
end

function Meta:GetSaveScience()
    return tonumber(self:GetPData('Science'))
end

function Meta:GetSaveWeapon()
    return tonumber(self:GetPData('Weapon'))
end

function Meta:GetSaveRepair()
    return tonumber(self:GetPData('Repair'))
end

function Meta:GetSaveStealth()
    return tonumber(self:GetPData('Stealth'))
end

function Meta:GetSaveColdWeapons()
    return tonumber(self:GetPData('ColdWeapons'))
end

function Meta:GetSaveEnergyWeapons()
    return tonumber(self:GetPData('EnergyWeapons'))
end

function Meta:GetSaveSkillPoints()
    return tonumber(self:GetPData('SkillPoints'))
end

-------------------------
   -- HOOKS SKILLS --
-------------------------

function PlayerInitialSkills(ply)

    if (ply:GetSaveBarter() == nil) then
		ply:SetBarter(2)
	else
		ply:SetBarter(ply:GetSaveBarter())
    end

    if (ply:GetSaveUnarmed() == nil) then
		ply:SetUnarmed(2)
	else
		ply:SetUnarmed(ply:GetSaveUnarmed())
    end

    if (ply:GetSaveBreaking() == nil) then
		ply:SetBreaking(2)
	else
		ply:SetBreaking(ply:GetSaveBreaking())
    end

    if (ply:GetSaveExplosive() == nil) then
		ply:SetExplosive(2)
	else
		ply:SetExplosive(ply:GetSaveExplosive())
    end

    if (ply:GetSaveSurvival() == nil) then
		ply:SetSurvival(2)
	else
		ply:SetSurvival(ply:GetSaveSurvival())
    end

    if (ply:GetSaveEloquence() == nil) then
		ply:SetEloquence(2)
	else
		ply:SetEloquence(ply:GetSaveEloquence())
    end

    if (ply:GetSaveMedicine() == nil) then
		ply:SetMedicine(2)
	else
		ply:SetMedicine(ply:GetSaveMedicine())
    end

    if (ply:GetSaveScience() == nil) then
		ply:SetScience(2)
	else
		ply:SetScience(ply:GetSaveScience())
    end

    if (ply:GetSaveWeapon() == nil) then
		ply:SetWeapon(2)
	else
		ply:SetWeapon(ply:GetSaveWeapon())
    end

    if (ply:GetSaveRepair() == nil) then
		ply:SetRepair(2)
	else
		ply:SetRepair(ply:GetSaveRepair())
    end

    if (ply:GetSaveStealth() == nil) then
		ply:SetStealth(2)
	else
		ply:SetStealth(ply:GetSaveStealth())
    end

    if (ply:GetSaveColdWeapons() == nil) then
		ply:SetColdWeapons(2)
	else
		ply:SetColdWeapons(ply:GetSaveColdWeapons())
    end

    if (ply:GetSaveEnergyWeapons() == nil) then
		ply:SetEnergyWeapons(2)
	else
		ply:SetEnergyWeapons(ply:GetSaveEnergyWeapons())
    end

    if (ply:GetSaveSkillPoints() == nil) then
		ply:SetSkillPoints(FO.PointsLevel)
	else
		ply:SetSkillPoints(ply:GetSaveSkillPoints())
    end

end
hook.Add ('PlayerInitialSpawn', 'PlayerInitialSkills', PlayerInitialSkills)

-------------------------
  -- FUNCTION SKILLS --
-------------------------
function SV_PlayerSkills(ply)
    ply:SaveBarter()
    ply:SaveUnarmed()
    ply:SaveBreaking()
    ply:SaveExplosive()
    ply:SaveSurvival()
    ply:SaveEloquence()
    ply:SaveMedicine()
    ply:SaveScience()
    ply:SaveWeapon()
    ply:SaveRepair()
    ply:SaveStealth()
    ply:SaveColdWeapons()
    ply:SaveEnergyWeapons()
    ply:SaveSkillPoints()
end

net.Receive('ChangeSkills', function(len, ply)
    ply:SetBarter(ply:GetBarter() + (2 * ply:GetCharisma() + ply:GetLuck()/2))
    ply:SetUnarmed(ply:GetUnarmed() + (2 * ply:GetEndurance() + ply:GetLuck()/2))
    ply:SetBreaking(ply:GetBreaking() + (2 * ply:GetPerception() + ply:GetLuck()/2))
    ply:SetExplosive(ply:GetExplosive() + (2 * ply:GetPerception() + ply:GetLuck()/2))
    ply:SetSurvival(ply:GetSurvival() + (2 * ply:GetEndurance() + ply:GetLuck()/2))
    ply:SetEloquence(ply:GetEloquence() + (2 * ply:GetCharisma() + ply:GetLuck()/2))
    ply:SetMedicine(ply:GetMedicine() + (2 * ply:GetIntellect() + ply:GetLuck()/2))
    ply:SetScience(ply:GetScience() + (2 * ply:GetIntellect() + ply:GetLuck()/2))
    ply:SetWeapon(ply:GetGun() + (2 * ply:GetAgility() + ply:GetLuck()/2))
    ply:SetRepair(ply:GetRepair() + (2 * ply:GetIntellect() + ply:GetLuck()/2))
    ply:SetStealth(ply:GetStealth() + (2 * ply:GetAgility() + ply:GetLuck()/2))
    ply:SetColdWeapons(ply:GetColdWeapons() + (2 * ply:GetStrength() + ply:GetAgility() + ply:GetLuck()/2))
    ply:SetEnergyWeapons(ply:GetEnergyWeapons() + (2 * ply:GetPerception() + ply:GetLuck()/2))
    ply:SetMaxWeight(FO.StartWeightMax + (10 * ply:GetStrength()))
    
    ForceHealthAdd(ply)

    SV_PlayerSkills(ply)
end)

net.Receive('ChangePointSkills', function(len, ply)
    local Skills = net.ReadTable()

    ply:SetBarter(Skills['BR'])
    ply:SetUnarmed(Skills['U'])
    ply:SetBreaking(Skills['B'])
    ply:SetExplosive(Skills['ES'])
    ply:SetSurvival(Skills['SL'])
    ply:SetEloquence(Skills['E'])
    ply:SetMedicine(Skills['M'])
    ply:SetScience(Skills['S'])
    ply:SetWeapon(Skills['W'])
    ply:SetRepair(Skills['R'])
    ply:SetStealth(Skills['SH'])
    ply:SetColdWeapons(Skills['CW'])
    ply:SetEnergyWeapons(Skills['EW'])
    ply:SetSkillPoints(Skills['POINT'])
end)