util.AddNetworkString('NotifyLevelUP')

local Meta = FindMetaTable('Player')

function Meta:SetLevel(lvl)
	self:SetNWInt('Level', lvl )
end

function Meta:AddExp(amount)
	local Exp = self:GetExp()

	self:SetExp(Exp + amount)
end

function Meta:SetExp(exp)
	self:SetNWInt('Exp', exp )
end

function Meta:SaveLevel()
	local Level = self:GetLevel()

	self:SetPData('Level', Level)
end

function Meta:GetSaveLevel()
	return tonumber(self:GetPData('Level'))
end

function Meta:SaveExp()
	local Exp = self:GetExp()

	self:SetPData('Exp', Exp)
end

function Meta:GetSaveExp()
	return tonumber(self:GetPData('Exp'))
end

function CheckNextLvl(ply)
	local Exp = ply:GetExp()
	local Level = ply:GetLevel()	
	local ToLvlExp = ply:GetMaxExp()

	if (Exp >= ToLvlExp) then
		ply:SetExp(0)
		ply:SetLevel(Level+1)

		net.Start('NotifyLevelUP')
			net.WriteEntity(ply)
		net.Send(ply)

		for k, v in pairs( FO.Level ) do
			if Level == FO.Level[k].level then
				ply:AddSkillPoints(FO.Level[k].points)

				--timer.Create( 'SkillMenu', 6, 1, function() 
					--net.Start('SkillMenu')
						--net.WriteEntity(ply)
					--net.Send(ply)
				--end)

				SV_PlayerSkills(ply)
			end
		end
	end
end