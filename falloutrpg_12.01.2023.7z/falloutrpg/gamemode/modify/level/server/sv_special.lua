util.AddNetworkString('StrengthChange')
util.AddNetworkString('PerceptionChange')
util.AddNetworkString('EnduranceChange')
util.AddNetworkString('CharismaChange')
util.AddNetworkString('IntellectChange')
util.AddNetworkString('AgilityChange')
util.AddNetworkString('LuckChange')
util.AddNetworkString('SpecialMenu')
util.AddNetworkString('ChangeSpecial')

local Meta = FindMetaTable('Player')

----------------------
    -- SET META --
----------------------

function Meta:SetStrength(num)
	self:SetNWInt('Strength', math.Clamp( num, 0, 10 ) ) -- Сила
end

function Meta:SetPerception(num)
	self:SetNWInt('Perception', math.Clamp( num, 0, 10 ) ) -- Восприятие
end

function Meta:SetEndurance(num)
	self:SetNWInt('Endurance', math.Clamp( num, 0, 10 ) ) -- Выносливость
end

function Meta:SetCharisma(num)
	self:SetNWInt('Charisma', math.Clamp( num, 0, 10 ) ) -- Харизма
end

function Meta:SetIntellect(num)
	self:SetNWInt('Intellect', math.Clamp( num, 0, 10 ) ) -- Интеллект
end

function Meta:SetAgility(num)
	self:SetNWInt('Agility', math.Clamp( num, 0, 10 ) ) -- Ловкость
end

function Meta:SetLuck(num)
	self:SetNWInt('Luck', math.Clamp( num, 0, 10 ) ) -- Удача
end

function Meta:SetSpecialPoints(num)
	self:SetNWInt('SpecialPoints', num ) -- Очки спешл
end

----------------------
    -- ADD META --
----------------------

function Meta:AddStrength(amount)
	local Strength = self:GetStrength()

	self:SetStrength(Strength + amount)
end

function Meta:AddPerception(amount)
	local Perception = self:GetPerception()

	self:SetPerception(Perception + amount)
end

function Meta:AddEndurance(amount)
	local Endurance = self:GetEndurance()

	self:SetEndurance(Endurance + amount)
end

function Meta:AddCharisma(amount)
	local Charisma = self:GetCharisma()

	self:SetCharisma(Charisma + amount)
end

function Meta:AddIntellect(amount)
	local Intellect = self:GetIntellect()

	self:SetIntellect(Intellect + amount)
end

function Meta:AddAgility(amount)
	local Agility = self:GetAgility()

	self:SetAgility(Agility + amount)
end

function Meta:AddLuck(amount)
	local Luck = self:GetLuck()

	self:SetLuck(Luck + amount)
end

function Meta:AddSpecialPoints(amount)
	local SpecialPoints = self:GetSpecialPoints()

	self:SetSpecialPoints(SpecialPoints + amount)
end

---------------------
  -- REDUCE META --
---------------------

function Meta:ReduceStrength(amount)
	local Strength = self:GetStrength()

	self:SetStrength(Strength - amount)
end

function Meta:ReducePerception(amount)
	local Perception = self:GetPerception()

	self:SetPerception(Perception - amount)
end

function Meta:ReduceEndurance(amount)
	local Endurance = self:GetEndurance()

	self:SetEndurance(Endurance - amount)
end

function Meta:ReduceCharisma(amount)
	local Charisma = self:GetCharisma()

	self:SetCharisma(Charisma - amount)
end

function Meta:ReduceIntellect(amount)
	local Intellect = self:GetIntellect()

	self:SetIntellect(Intellect - amount)
end

function Meta:ReduceAgility(amount)
	local Agility = self:GetAgility()

	self:SetAgility(Agility - amount)
end

function Meta:ReduceLuck(amount)
	local Luck = self:GetLuck()

	self:SetLuck(Luck - amount)
end

function Meta:ReduceSpecialPoints(amount)
	local SpecialPoints = self:GetSpecialPoints()

	self:SetSpecialPoints(SpecialPoints - amount)
end

---------------------
   -- SAVE META --
---------------------

function Meta:SaveStrength()
	local Strength = self:GetStrength()

	self:SetPData('Strength', Strength)
end

function Meta:SavePerception()
	local Perception = self:GetPerception()

	self:SetPData('Perception', Perception)
end

function Meta:SaveEndurance()
	local Endurance = self:GetEndurance()

	self:SetPData('Endurance', Endurance)
end

function Meta:SaveCharisma()
	local Charisma = self:GetCharisma()

	self:SetPData('Charisma', Charisma)
end

function Meta:SaveIntellect()
	local Intellect = self:GetIntellect()

	self:SetPData('Intellect', Intellect)
end

function Meta:SaveAgility()
	local Agility = self:GetAgility()

	self:SetPData('Agility', Agility)
end

function Meta:SaveLuck()
	local Luck = self:GetLuck()

	self:SetPData('Luck', Luck)
end

function Meta:SaveSpecialPoints()
	local SpecialPoints = self:GetSpecialPoints()

	self:SetPData('SpecialPoints', SpecialPoints)
end

------------------------
   -- GETSAVE META --
------------------------

function Meta:GetSaveStrength()
	return tonumber(self:GetPData('Strength'))
end

function Meta:GetSavePerception()
	return tonumber(self:GetPData('Perception'))
end

function Meta:GetSaveEndurance()
	return tonumber(self:GetPData('Endurance'))
end

function Meta:GetSaveCharisma()
	return tonumber(self:GetPData('Charisma'))
end

function Meta:GetSaveIntellect()
	return tonumber(self:GetPData('Intellect'))
end

function Meta:GetSaveAgility()
	return tonumber(self:GetPData('Agility'))
end

function Meta:GetSaveLuck()
	return tonumber(self:GetPData('Luck'))
end

function Meta:GetSaveSpecialPoints()
	return tonumber(self:GetPData('SpecialPoints'))
end

-------------------------
   -- HOOKS SPECIAL --
-------------------------

function PlayerInitialSpecial(ply)

    if (ply:GetSaveStrength() == nil) then
		ply:SetStrength(0)
	else
		ply:SetStrength(ply:GetSaveStrength())
    end
    
    if (ply:GetSavePerception() == nil) then
		ply:SetPerception(0)
	else
		ply:SetPerception(ply:GetSavePerception())
    end
    
    if (ply:GetSaveEndurance() == nil) then
		ply:SetEndurance(0)
	else
		ply:SetEndurance(ply:GetSaveEndurance())
    end
    
    if (ply:GetSaveCharisma() == nil) then
		ply:SetCharisma(0)
	else
		ply:SetCharisma(ply:GetSaveCharisma())
    end
    
    if (ply:GetSaveIntellect() == nil) then
		ply:SetIntellect(0)
	else
		ply:SetIntellect(ply:GetSaveIntellect())
    end
    
    if (ply:GetSaveAgility() == nil) then
		ply:SetAgility(0)
	else
		ply:SetAgility(ply:GetSaveAgility())
    end
    
    if (ply:GetSaveLuck() == nil) then
		ply:SetLuck(0)
	else
		ply:SetLuck(ply:GetSaveLuck())
    end
    
    if (ply:GetSaveSpecialPoints() == nil) then
		ply:SetSpecialPoints(FO.StartPoints)
	else
		ply:SetSpecialPoints(ply:GetSaveSpecialPoints())
    end

end
hook.Add ('PlayerInitialSpawn', 'PlayerInitialSpecial', PlayerInitialSpecial)

-------------------------
    -- NET SPECIAL --
-------------------------

net.Receive('StrengthChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetStrength() != 10 then
                ply:AddStrength(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetStrength() != 0 then
            ply:ReduceStrength(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('PerceptionChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetPerception() != 10 then
                ply:AddPerception(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetPerception() != 0 then
            ply:ReducePerception(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('EnduranceChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetEndurance() != 10 then
                ply:AddEndurance(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetEndurance() != 0 then
            ply:ReduceEndurance(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('CharismaChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetCharisma() != 10 then
                ply:AddCharisma(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetCharisma() != 0 then
            ply:ReduceCharisma(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('IntellectChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetIntellect() != 10 then
                ply:AddIntellect(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetIntellect() != 0 then
            ply:ReduceIntellect(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('AgilityChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetAgility() != 10 then
                ply:AddAgility(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetAgility() != 0 then
            ply:ReduceAgility(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('LuckChange', function(len, ply)
    local bool = net.ReadBool()

    if bool then
        if ply:GetSpecialPoints() > 0 then
            if ply:GetLuck() != 10 then
                ply:AddLuck(1)
                ply:ReduceSpecialPoints(1)
            end
        end
    else
        if ply:GetLuck() != 0 then
            ply:ReduceLuck(1)
            ply:AddSpecialPoints(1)
        end
    end
end)

net.Receive('ChangeSpecial', function(len, ply)
    local Special = net.ReadTable()

    ply:SetStrength(Special['S'])
    ply:SetPerception(Special['P'])
    ply:SetEndurance(Special['E'])
    ply:SetCharisma(Special['C'])
    ply:SetIntellect(Special['I'])
    ply:SetAgility(Special['A'])
    ply:SetLuck(Special['L'])
    ply:SetSpecialPoints(Special['POINT'])
end)