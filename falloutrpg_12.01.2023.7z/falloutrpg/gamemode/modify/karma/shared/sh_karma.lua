local Meta = FindMetaTable('Player')

function Meta:GetKarma()
	return tonumber(self:GetNWInt('Karma', 0))
end