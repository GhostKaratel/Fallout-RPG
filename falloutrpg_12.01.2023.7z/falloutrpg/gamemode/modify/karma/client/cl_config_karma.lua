FO.Karma = {}

FO.Karma['karma_saintly'] = 
{
    name = 'Очень добрый',
    material = Material('icons/pipboyimages/karma icons/karma_saintly.png'),
    description = [[]],
    carm = 75,
    func = function(ply) 
    end,
}

FO.Karma['karma_neutral'] = 
{
    name = 'Нейтральный',
    material = Material('icons/pipboyimages/karma icons/karma_neutral.png'),
    description = [[]],
    carm = {24,-24},
    func = function(ply) 
    end,
}

FO.Karma['karma_good'] = 
{
    name = 'Добрый',
    material = Material('icons/pipboyimages/karma icons/karma_good.png'),
    description = [[]],
    carm = 25,
    func = function(ply) 
    end,
}

FO.Karma['karma_evil'] = 
{
    name = 'Злой',
    material = Material('icons/pipboyimages/karma icons/karma_bad.png'),
    description = [[]],
    carm = -75,
    func = function(ply) 
    end,
}

FO.Karma['karma_bad'] = 
{
    name = 'Очень злой',
    material = Material('icons/pipboyimages/karma icons/karma_evil.png'),
    description = [[]],
    carm = -25,
    func = function(ply) 
    end,
}