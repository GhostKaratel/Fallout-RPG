function InterfacePlayer()
	local w,h = ScrW(), ScrH()
	local ply = LocalPlayer()

	if !ply:Alive() then
		return
	end
	
	local HP = ply:Health()
	local AP = ply:GetAP()
	local MN = ply:GetMoney()
	local LV = ply:GetLevel()
	local EX = ply:GetExp()
	local TM = ply:GetNWInt('PlayTime')
	local HPMax = ply:GetMaxHealth()
	local ToLvlExp = 25*(3*LV+2)*(LV-1)
	local WEP = ply:GetActiveWeapon()	
	local PC = PrimaryСolor()
	local SC = SecondaryСolor()

	--[[LerpHP = Lerp(FrameTime()*5, LerpHP or 0, HP or 0)
	LerpAP = Lerp(FrameTime()*5, LerpAP or 0, AP or 0)
	LerpMN = Lerp(FrameTime()*2, LerpMN or 0, MN or 0)
	LerpLV = Lerp(FrameTime()*2, LerpLV or 0, LV or 0)
	LerpEX = Lerp(FrameTime()*2, LerpEX or 0, EX or 0)
	LerpToEX = Lerp(FrameTime()*2, LerpToEX or 0, ToLvlExp or 0)
	LerpTM = Lerp(FrameTime()*2, LerpTM or 0, TM or 0)
	LerpCP = Lerp(FrameTime()*5, LerpCP or 0, (-ply:GetAngles().y/360) or 0)

	surface.SetFont( FO.fonts('28:CQ Mono [RUS by Daymarius]') )
	local hx, hy = surface.GetTextSize( FO.Language.hudhealth )

	FO.Image( 10, h - 131, 363, 122, PC, FO.Materials.left_seperatorglow )
	FO.Image( w - 371, h - 131, 361, 121, PC, FO.Materials.right_seperatorglow )
	FO.Image( w/2 - 18, h/2 - 18, 36, 36, SC, FO.Materials.crosshair01 )

	--surface.SetDrawColor( FO.Theme.basecolor )
	--surface.SetMaterial( FO.Materials.comp_direction_strip )
	--surface.DrawPartialTexturedRect( 28, h - 100, 370, 64, LerpCP * 1024, 0, 370, 16, 1024, 16 )

	if HP > 0 then
		for i=0, math.Clamp( LerpHP, 0, 100 ) / 2.7 do
			FO.Image( 17 + i * 8, h - 100, 8, 32, SC, FO.Materials.tick_mark )
		end
	end

	if AP > 0 then
		for i=0,math.Clamp( LerpAP, 0, 255 ) / 2.75 do
			FO.Image( w - 23 - i * 8, h - 100, 8, 32, SC, FO.Materials.tick_mark )
		end
	end

	--FO.Text( 'ОЗ  '..ply:Health(), 'HP_INTERFACE', 'HP_INTERFACE_SHADOW', 37, h - 164, FO.Theme.basecolor, 0, 0, FO.Theme.shadowcolor )
	FO.Text( 'ОД: '..AP, 'HP_INTERFACE', w-37, h - 164, FO.Theme.basecolor, 2, 0 )
	--FO.Text( ply:GetKarma(), 'HP_INTERFACE', 'HP_INTERFACE_SHADOW', 25, h/2, FO.Theme.basecolor, 0, 0, FO.Theme.shadowcolor )
	
	FO.Text(FO.Language.hudhealth, FO.fonts('28:CQ Mono [RUS by Daymarius]'), 37, h-164, PC, 0, 0)
	FO.Text(ply:Health(), FO.fonts('28:CQ Mono [RUS by Daymarius]'), 25 + hx, h-164, SC, 0, 0)

	for k,v in pairs(ents.FindInSphere(ply:GetPos(),1024)) do

		if(v:IsNPC()) then

			ang = ply:GetAngles().y - GetAngleOfLineBetweenTwoPoints(ply,v)

			if(ang < -180) then
				ang = -180
			elseif(ang > 180) then
				ang = 180
			end

			if v:GetNWBool('Enemy') == true then
				surface.SetDrawColor(FO.Theme.enemycolor)
			else
				surface.SetDrawColor(FO.Theme.basecolor)
			end
			
			surface.SetMaterial( FO.Materials.tick_mark )
			surface.DrawTexturedRectRotated(ang + 218, h - 85, 32,32,0 )
		end

		if(v:IsPlayer() && v != ply) then

			if(v:LookupAttachment('eyes') != 0) then

				ang = ply:GetAngles().y - GetAngleOfLineBetweenTwoPoints(ply,v)

				if(ang < -180) then
					ang = -180
				elseif(ang > 180) then
					ang = 180
				end

				if v:GetNWBool('Enemy') == true then
					surface.SetDrawColor(FO.Theme.enemycolor)
				elseif v:GetNWBool('EnemyDamage') == true then
					surface.SetDrawColor(FO.Theme.warncolor)
				else
					surface.SetDrawColor(FO.Theme.basecolor)
				end

				surface.SetMaterial( FO.Materials.tick_mark )
				surface.DrawTexturedRectRotated(ang + 218, h - 85, 32,32,0 )

			end

		end

	end

	if not IsValid(WEP) or WEP:GetPrimaryAmmoType() < 0 then  
	else        
		local Ammo = ply:GetAmmoCount(ply:GetActiveWeapon():GetPrimaryAmmoType())
		local Magazine = (math.max((ply:GetActiveWeapon():Clip1()), 0)) 
		local Weapon = ply:GetActiveWeapon():GetPrintName()

		surface.SetFont( FO.fonts('30:CQ Mono [RUS by Daymarius]') )
		local ax, ay = surface.GetTextSize( '/'..Ammo )

		FO.Text( '/'..math.Clamp(Ammo, 0, 999), FO.fonts('30:CQ Mono [RUS by Daymarius]'), w-25, h - 60, SC, 2, 0 )
		FO.Text( math.Clamp(Magazine, 0, 999), FO.fonts('30:CQ Mono [RUS by Daymarius]'), w-ax-25, h - 60, SC, 2, 0 )
		
		--FO.Text( Weapon, 'LVL_INTERFACE', 'LVL_INTERFACE_SHADOW', w-70, h - 60, Color(255,255,255), 2, 0, Color(0, 0, 0) 
	end

	--FO.Text( math.Round(LerpEX), 'EXP_INTERFACE', 'EXP_INTERFACE_SHADOW', w/2 - 160, h - 36, Color(225,225,225), 2, 0, Color(0, 0, 0) )
	--FO.Text( math.Round(LerpToEX), 'EXP_INTERFACE', 'EXP_INTERFACE_SHADOW', w/2 + 160, h - 36, Color(225,225,225), 0, 0, Color(0, 0, 0) )
	--FO.Text( FO.Language.hudlevel..math.Round(LerpLV), 'LVL_INTERFACE', 'LVL_INTERFACE_SHADOW', w/2, h - 60, Color(255,255,255), 1, 0, Color(0, 0, 0) )
	

	local tr = ply:GetEyeTrace()

	if IsValid(tr.Entity) and tr.Entity.DropItem then
		local ITEMdata = FO.INV.Items[tr.Entity.classname]

		if not ITEMdata then return end

		if ( tr.Entity:GetPos():Distance(ply:GetPos()) < 150 ) then
			FO.Image( w/2 - 160, h - 120, 512, 128, FO.Theme.basecolor, FO.Materials.bottom_info_seperator_divider )
			FO.Text( 'E) Take', 'HP_INTERFACE', w/2, h - 175, FO.Theme.basecolor, 1, 0)
			
			if tr.Entity.amount != nil and tr.Entity.amount > 1 then 
				FO.Text( ITEMdata.name..' ('..tr.Entity.amount..')', 'HP_INTERFACE', w/2, h - 145, FO.Theme.basecolor, 1, 0 )
			else
				FO.Text( ITEMdata.name, 'HP_INTERFACE', w/2, h - 145, FO.Theme.basecolor, 1, 0)
			end

			FO.Text( 'WG', 'HP_INTERFACE', w/2 - 135, h - 95, FO.Theme.basecolor, 0, 0 )
			FO.Text( 'VAL', 'HP_INTERFACE', w/2 + 17, h - 95, FO.Theme.basecolor, 0, 0 )
			FO.Text( ITEMdata.weight, 'HP_INTERFACE', w/2 - 15, h - 95, FO.Theme.basecolor, 2, 0 )
			FO.Text( ITEMdata.price, 'HP_INTERFACE', w/2 + 140, h - 95, FO.Theme.basecolor, 2, 0 )
		end
    end

	if IsValid(tr.Entity) and tr.Entity.Loot then
		if ( tr.Entity:GetPos():Distance(ply:GetPos()) < 150 ) then
			FO.Text( 'E) Open', 'HP_INTERFACE', w/2, h - 175, FO.Theme.basecolor, 1, 0 )
			FO.Text( tr.Entity.Name, 'HP_INTERFACE', w/2, h - 145, FO.Theme.basecolor, 1, 0 )

			if !tr.Entity.FO.LOOT[1] then
				FO.Text( '[EMPTY]', 'HP_INTERFACE', w/2, h - 100, FO.Theme.basecolor, 1, 0 )
			end
		end
	end

	--[[
		draw.RoundedBox(8, w - 250, 12, 240, 30, Color( 35, 35, 35 ))
		draw.RoundedBox(2, 28, h - 25, 291, 10, Color( 60, 60, 60 ))
		draw.RoundedBox(2, w/2 - 146, h - 25, 291, 10, Color( 60, 60, 60 ))
		draw.RoundedBox(2, w/2 - 144, h - 23, math.Clamp( LerpEX/LerpToEX * 100, 0, ToLvlExp ) * 2.86, 6, Color( 255, 160, 60 ))
		draw.RoundedBox(2, 31, h - 23, math.Clamp( LerpHP, 0, HPMax ) * 2.86, 6, Color( 170, 45, 45 ))

		FO.Text( FO.Language.hudmoney..string.Comma(math.Round(LerpMN)), 'MN_INTERFACE', 'MN_INTERFACE_SHADOW', 35, h - 60, Color(225,225,225), 0, 0, Color(0, 0, 0) )
		FO.Text( FO.Language.hudtime..timeToStr(LerpTM), 'TM_INTERFACE', 'TM_INTERFACE_SHADOW', w - 20, 15, Color(255,255,255), 2, 0, Color(0, 0, 0) )
		FO.Text( math.Round(LerpEX), 'EXP_INTERFACE', 'EXP_INTERFACE_SHADOW', w/2 - 160, h - 36, Color(225,225,225), 2, 0, Color(0, 0, 0) )
		FO.Text( math.Round(LerpToEX), 'EXP_INTERFACE', 'EXP_INTERFACE_SHADOW', w/2 + 160, h - 36, Color(225,225,225), 0, 0, Color(0, 0, 0) )
		FO.Text( math.Round(LerpHP), 'HP_INTERFACE', 'HP_INTERFACE_SHADOW', 330, h - 36, Color(225,225,225), 0, 0, Color(0, 0, 0) )
		FO.Text( FO.Language.hudlevel..math.Round(LerpLV), 'LVL_INTERFACE', 'LVL_INTERFACE_SHADOW', w/2, h - 60, Color(255,255,255), 1, 0, Color(0, 0, 0) )

		

		FO.Text( math.Round(LerpHP), 'HP_INTERFACE', 'HP_INTERFACE_SHADOW', 280, h - 75, Color(225,225,225), 0, 0, Color(0, 0, 0) )
		FO.Text( math.Round(LerpAR), 'HP_INTERFACE', 'HP_INTERFACE_SHADOW', 150, h - 50, Color(225,225,225), 0, 0, Color(0, 0, 0) )
	]]
end
hook.Add('HUDPaint', 'InterfacePlayer', InterfacePlayer) 

local Fov = 0
hook.Add( "PlayerTick", "FO.ActionPoints", function( ply, move ) 
	local GetFov = ply:GetInfoNum( "fov_desired", 75 )
	local Sprint

	Sprint = ply:GetVelocity():Length2D() > ply:GetRunSpeed() * 0.6 and ply:IsSprinting() and ply:OnGround()

	if Sprint then 
		Fov = Lerp(FrameTime()*0.5, Fov, GetFov+10)
	elseif not ply:OnGround() and not ply:IsSprinting() then
		Fov = Lerp(FrameTime()*0.5, Fov, math.Clamp(GetFov+10*(ply:GetVelocity():Length()/1000), 75, 110))
	else
		Fov = Lerp(FrameTime()*2, Fov, GetFov)
	end

	ply:SetFOV(Fov)
end )













































function RemoveHud( name )
	
	local RemoveElement = {
		'CHudHealth', 
		'CHudBattery', 
		'CHudAmmo', 
		'CHudSecondAmmo',
		'CHudCrosshair',
		'CHudGeiger',
		'CHudPoisonDamageIndicator',
		'CHudSquadStatus',
		'CHudTrain',
		'CHudVehicle',
		'CHudZoom',
		'CHUDQuickInfo',
		'CHudSuitPower',
		'CHudSecondaryAmmo'
	}

	for k, v in pairs(RemoveElement) do

		if name == v then
			return false
		end

	end
end
hook.Add('HUDShouldDraw', 'Remove', RemoveHud)

function DrawDeathNotice()
    return false
end
hook.Add ('DrawDeathNotice', 'DrawDeathNotice', DrawDeathNotice)

function HUDDrawTargetID()
    return false
end
hook.Add ('HUDDrawTargetID', 'HUDDrawTargetID', HUDDrawTargetID)

function NPCHappyDeathSounds()
    return false
end
hook.Add ('NPCHappyDeathSounds', 'NPCHappyDeathSounds', NPCHappyDeathSounds)

function PlayerHappyDeathSounds()
    return false
end
hook.Add ('PlayerHappyDeathSounds', 'PlayerHappyDeathSounds', PlayerHappyDeathSounds)

function PlayerDeathSound()
    return false
end
hook.Add ('PlayerDeathSound', 'PlayerDeathSound', PlayerDeathSound)

function CanPlayerSuicide()
    return false
end
hook.Add ('CanPlayerSuicide', 'CanPlayerSuicide', CanPlayerSuicide)

function HUDAmmoPickedUp()
	return false
end
hook.Add ('HUDAmmoPickedUp', 'HUDAmmoPickedUp', HUDAmmoPickedUp)

function HUDItemPickedUp()
	return false
end
hook.Add ('HUDItemPickedUp', 'HUDItemPickedUp', HUDItemPickedUp)

function HUDWeaponPickedUp()
	return false
end
hook.Add ('HUDWeaponPickedUp', 'HUDWeaponPickedUp', HUDWeaponPickedUp)

function OnEntityCreated( ent )
	return false
end
hook.Add ('OnEntityCreated', 'OnEntityCreated', OnEntityCreated)