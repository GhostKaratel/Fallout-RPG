hook.Add('Think','SearchForNPC',function()

	for k,v in pairs(ents.GetAll()) do

		if v:IsNPC() then

			if(v:Classify() >= 9 || v:Classify() == 4 || v:Classify() == 5) then
	
				if(v:GetNWBool('Enemy') == false) then
					v:SetNWBool('Enemy',true)
				end

			end

		end

	end

end)

--[[hook.Add( 'PlayerShouldTakeDamage', 'AntiTeamkill', function( ply, attacker )
	return ply:Team() != attacker:Team() -- that will return false if attacker and ply is on the same team.
end )]]
