if CLIENT then

surface.CreateFont('Title', {font = 'DINRoundPro-Medi', size = 40, weight = 0, antialias = true, extended = true})
surface.CreateFont('Title_shadow', {font = 'DINRoundPro-Medi', size = 40, weight = 0, antialias = true, extended = true, blursize = 2})
surface.CreateFont('Title2', {font = 'Teko', size = 50, weight = 0, antialias = true, extended = true})
surface.CreateFont('Title2_shadow', {font = 'Teko', size = 50, weight = 0, antialias = true, extended = true, blursize = 2})
surface.CreateFont('Name', {font = 'New_Channel_Font-Black', size = 18, weight = 0, antialias = true, extended = true})
surface.CreateFont('Name_shadow', {font = 'New_Channel_Font-Black', size = 18, weight = 0, antialias = true, extended = true, blursize = 2})
surface.CreateFont('Health', {font = 'Jefferies', size = 24, weight = 0, antialias = true, extended = true})
surface.CreateFont('Online', {font = 'Jefferies', size = 25, weight = 0, antialias = true, extended = true})
surface.CreateFont('Online_shadow', {font = 'Jefferies', size = 25, weight = 0, antialias = true, extended = true, blursize = 3})
surface.CreateFont('Time', {font = 'Jefferies', size = 25, weight = 0, antialias = true, extended = true})
surface.CreateFont('Time_shadow', {font = 'Jefferies', size = 25, weight = 0, antialias = true, extended = true, blursize = 3})
surface.CreateFont('Rules', {font = 'Montserrat Medium', size = 18, weight = 0, antialias = true, extended = true})
surface.CreateFont('Command', {font = 'New_Channel_Font-Black', size = 16, weight = 0, antialias = true, extended = true})

end

local function ToggleScoreboard(toggle)

	if toggle then
		local time = os.time()
		local timedata = os.date( '%H:%M - %d/%m/%Y' , time )
        local online

        local scrw,scrh = ScrW(), ScrH()
        Tab = vgui.Create('DFrame')
        Tab:SetTitle('')
        Tab:SetSize(1024, 768)
        Tab:Center()
        Tab:MakePopup()
        Tab:ShowCloseButton(false)
        Tab:SetDraggable(false)
        Tab.Paint = function(self,w,h)  
            draw.RoundedBox(0, 0, 0, w, h, Color(40,25,15,200))
            FO.BackgroundBlur(self, 8)
        end                             

		local Panel = vgui.Create( 'DPanel', Tab )
        Panel:SetSize(Tab:GetWide(), Tab:GetTall())
        Panel:Center()
		Panel:SetText( '' )
        Panel.Paint = function( self, w, h )
            --local tw, th = surface.GetTextSize()
            
            FO.Image( 15, 22, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png' )
            FO.Image( 355, 22, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_bottom.png' )
            --FO.Image( w/2, 22, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') )
            --FO.Image( w/2 + 158, 22, 2, 48, Color(240,170,80,255), 'shared/line/fade_to_bottom.png') )
            FO.Image( w-17, 22, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_bottom.png' )
            FO.Image( 15, h-148, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png' )
            FO.Image( w-17, h-148, 2, 128, Color(240,170,80,255), 'shared/line/fade_to_top.png' )
            
            draw.RoundedBox(0, 15, 22, 50, 2, Color(240,170,80))
            draw.RoundedBox(0, 205, 22, 150, 2, Color(240,170,80))
            --draw.RoundedBox(0, w/2-150, 22, 150, 2, Color(240,170,80))
           --draw.RoundedBox(0, w/2 + 8, 22, 150, 2, Color(240,170,80))
            draw.RoundedBox(0, w - 92, 22, 75, 2, Color(240,170,80))
            draw.RoundedBox(0, 15, h-20, w-30, 2, Color(240,170,80))

            --[[draw.SimpleText( FO.Language.infof4weight, 'INFO_F4', 210, 40, Color(240,170,80), 0, 1)     
            draw.SimpleText( LocalPlayer():GetWeight()..'/'..LocalPlayer():GetMaxWeight(), 'INFO_F4', w/2 - 161, 40, Color(240,170,80), 2, 1)   
            
            draw.SimpleText( FO.Language.infof4ap, 'INFO_F4', w/2 + 15, 40, Color(240,170,80), 0, 1)     
            draw.SimpleText( '100'..'/'..'100', 'INFO_F4', w/2 + 154, 40, Color(240,170,80), 2, 1)   

            draw.SimpleText( FO.Language.infof4caps, 'INFO_F4', w/2 + 170, 40, Color(240,170,80), 0, 1)     
            draw.SimpleText( LocalPlayer():GetMoney(), 'INFO_F4', w - 24, 40, Color(240,170,80), 2, 1) 

            draw.SimpleText( FO.Language.infof4health, 'INFO_F4', w/2 - 145, 40, Color(240,170,80), 0, 1)     
            draw.SimpleText( LocalPlayer():Health()..'/'..LocalPlayer():GetMaxHealth(), 'INFO_F4', w/2 - 5, 40, Color(240,170,80), 2, 1) ]]

            draw.SimpleText( FO.Language.tabonline..online, FO.fonts('25:Akrobat-Bold'), w/2 - 165, 38, Color(240,170,80), 2, 1)  

            draw.SimpleText(FO.Language.tabtitle, FO.fonts('36:MonofontoRUSBYMelman-Regular'), w/8, 25, Color(240,170,80), 1, 1) 
        end		

        local scroll = vgui.Create('DScrollPanel', Panel)
        scroll:Dock(FILL)
	    scroll:DockMargin(10,60,10,15)
        scroll.Paint = function( self, w, h ) end
        local sbar = scroll:GetVBar()
	    function sbar:Paint( w, h ) 
	    	draw.RoundedBox( 0, 2, 0, w-4, h, Color(40,40,40) )
	    end
	    function sbar.btnUp:Paint( w, h )
		    draw.RoundedBox( 0, 2, 0, w-4, h, Color(65,65,65) )
	    end
	    function sbar.btnDown:Paint( w, h )
		    draw.RoundedBox( 0, 2, 0, w-4, h, Color(65,65,65) )
	    end
	    function sbar.btnGrip:Paint( w, h )
		    draw.RoundedBox( 0, 2, 0, w-4, h, Color(65,65,65) )
	    end

        for k, v in pairs(player.GetAll()) do

            if not IsValid(v) then return end   
            online = k    

            local SelectPlayer = vgui.Create('DCollapsibleCategory', scroll)
            SelectPlayer:Dock(TOP)
            SelectPlayer:DockMargin(10, 10, 10, 0)
            SelectPlayer.Header:SetTall(30)
            SelectPlayer:SetExpanded(0)
            SelectPlayer:SetAnimTime( 0.5 )
            SelectPlayer.Hover = 0
            SelectPlayer.Hover2 = 0
            SelectPlayer:SetLabel('')
            function SelectPlayer:Paint(w, h)

                --[[draw.RoundedBox( 8, 16, 4, w-15, 32, Color(40,40,40) )
                draw.RoundedBox( 36, 2, 2, 36, 36, Color(70,70,70) )
                draw.SimpleText(v:GetRPName(),'Name', 50, 20, Color(225,225,225), 0, 1) 
                draw.SimpleText(team.GetName( v:Team() ),'Name', w/4.5, 20, Color(225,225,125), 0, 1) 
                draw.SimpleText(v:Ping(),'Name', w - 15, 20, Color(225,175,125), 2, 1) 
                draw.SimpleText(v:GetLevel(),'Name', 20, 20, Color(125,200,225), 1, 1)
                draw.SimpleText(string.Comma(math.Round(v:GetNWInt('PlayerMoney')))..' $','Name', w/2, 20, Color(125,225,175), 1, 1)  
                draw.SimpleText(timeToStr(v:GetPlayTime()),'Name', w/1.3, 20, Color(225,125,125), 1, 1)  ]]
                draw.RoundedBox(0, 0, 0, w, h, Color(40,25,15,100))
                draw.SimpleText(v:GetRPName(), FO.fonts('24:CQ Mono [RUS by Daymarius]'), 50, 15, Color(225,225,225), 0, 1) 
            end

            local Editor = vgui.Create('DLabel', SelectPlayer)
            Editor:Dock(TOP)
            Editor:SetSize(0,40)
            Editor:DockMargin(0,5,0,0)
            Editor:SetText( '' )
            Editor:IsVisible()
            Editor.Paint = function(self,w,h)
                --draw.RoundedBox( 8, 0, 0, w, h-5, Color(40,40,40) )             
            end
            Editor:SetMouseInputEnabled( true )

            local DHorizontalScroller = vgui.Create( 'DHorizontalScroller', Editor )
            DHorizontalScroller:Dock( FILL )
            DHorizontalScroller:SetOverlap( -1 )
            DHorizontalScroller:DockMargin(3,5,3,10)    
            DHorizontalScroller.Paint = function( self, w, h )
            end    
            function DHorizontalScroller.btnLeft:Paint( w, h )
                draw.SimpleText('⯇', 'Name', 0, -2, Color( 225,225,225,225 ), 0, 0)
            end
            function DHorizontalScroller.btnRight:Paint( w, h )
                draw.SimpleText('⯈', 'Name', 0, -2, Color( 225,225,225,225 ), 0, 0)
            end  

        end

	else
       
        if IsValid(Tab) then 
        	Tab:Remove()
        end
    
    end
	
end

hook.Add('ScoreboardShow', 'TabOpenScoreboard', function()
    ToggleScoreboard(true)
	return false
end)

hook.Add('ScoreboardHide', 'TabHideScoreboard', function()
    ToggleScoreboard(false)
end)