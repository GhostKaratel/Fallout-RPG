local Meta = FindMetaTable('Player')

function Meta:GetPlayTime()
	return tonumber(self:GetNWInt('PlayTime'))
end