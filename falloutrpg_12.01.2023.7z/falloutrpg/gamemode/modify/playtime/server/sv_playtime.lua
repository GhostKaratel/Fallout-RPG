local Meta = FindMetaTable('Player')

function Meta:SetPlayTime(time)
	self:SetNWInt('PlayTime', time )
end

function Meta:SavePlayTime()
	local Time = self:GetPlayTime()

	self:SetPData('PlayTime', Time)
end

function Meta:GetSavePlayTime()
	return tonumber(self:GetPData('PlayTime', 0))
end

