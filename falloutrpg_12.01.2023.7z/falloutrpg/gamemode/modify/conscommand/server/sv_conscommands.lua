function buyEntity(ply, cmd, args)

    if (args[1] != nil ) then
        local ent = ents.Create(args[1])
        local tr = ply:GetEyeTrace()
        local balance = tonumber( ply:GetNWInt('PlayerMoney') )

        if (IsValid(ent)) then 
            local ClassName = ent:GetClass()

            if (!tr.Hit) then return end

            local entCount = ply:GetNWInt(ClassName..'count')
        
            if (entCount < ent.Limit  ) then 
                if (balance >= ent.Cost) then
                    local SpawnPos = ply:GetShootPos() + ply:GetForward() * 80
            
                    ent.Owner = ply
            
                    local ent = ents.Create(ClassName)
                    ent:SetPos(SpawnPos)
                    ent:Spawn()
                    ent:Activate()

                    ply:SetNWInt('PlayerMoney', balance - ent.Cost)
            
                    ply:SetNWInt(ClassName..'count', entCount + 1)
            
                    return ent
                end
            end
        
            return
        end

    end

end
concommand.Add('buy_ent', buyEntity)

function buyGun(ply, cmd, args)

    local weaponPrices = {}
    weaponPrices[1] = {'weapon_smg1','100','8'}

    for k,v in pairs(weaponPrices) do

    if (args[1] == v[1]) then

        local balance = tonumber( ply:GetNWInt('PlayerMoney') )
        local level = tonumber( ply:GetNWInt('PlayerLevel') )
        local gunCost = tonumber( v[2]) 
        local levelReq = tonumber( v[3] )

        if ( level >= levelReq ) then

            if ( balance >= gunCost ) then

                ply:SetNWInt('PlayerMoney', balance - gunCost)
                ply:SetNWInt('PlayerWeapon', args[1])
                ply:Give(v[1])
                ply:GiveAmmo(20, ply:GetWeapon(args[1]):GetPrimaryAmmoType(), false)

            end

        end
        
        return
    
    end

    end

end
concommand.Add('buy_wep', buyGun)

function dropWeapon(ply, text)
    if ( !IsValid( ply ) ) then return end
    
    if string.lower(text) == '!drop' then
        ply:DropWeapon( ply:GetActiveWeapon() )
    end
end
hook.Add('PlayerSay', 'dropWeapon', dropWeapon)

function dropMoney(ply, text)
    if ( !IsValid( ply ) ) then return end

    local playerMsg = string.Explode(' ', text)
    
    if playerMsg[1] == '!dropmoney' then
        if (tonumber(playerMsg[2])) then
            local amount = tonumber(playerMsg[2])
            local Money = tonumber(ply:GetMoney())

            if (amount > 0 and amount <= Money) then
                ply:RemoveMoney(amount)

                scripted_ents.Get('spawned_money'):SpawnFunction(ply, ply:GetEyeTrace(), 'spawned_money'):SetValue(amount)
            end

            return ''
        end
    end
end
hook.Add('PlayerSay', 'dropMoney', dropMoney)
