local nets = {
    'hp_update',
    'hp_init',
    'hp_remove',
    'hp_refresh',
}

for k, v in ipairs(nets) do
    util.AddNetworkString(v)
end

function ForceHealthAdd(ply)
    ply:SetMaxHealth( 95 + (ply:GetEndurance() * 20) + (ply:GetLevel() * 5) )
    ply:SetHealth( 95 + (ply:GetEndurance() * 20) + (ply:GetLevel() * 5) )
end

local Meta = FindMetaTable('Player')

function PlayerSpawnHP(ply)
	timer.Create( 'IntHP', 1, 1, function() 
		ply:HPinit()
        ForceHealthAdd(ply)
    end)
end
hook.Add ('PlayerSpawn', 'PlayerSpawnHP', PlayerSpawnHP)

function Meta:HPinit()
    self.Head = FO.Head
    self.Torso = FO.Torso
    self.LeftArm = FO.LeftArm
    self.RightArm = FO.RightArm
    self.LeftLeg = FO.LeftLeg
    self.RightLeg = FO.RightLeg
    
    net.Start('hp_init')
    net.Send(self)
end

function Meta:HPUpdate()
	net.Start( 'hp_update' )
		net.WriteInt( self.Head, 32 )
		net.WriteInt( self.Torso, 32 )
		net.WriteInt( self.LeftArm, 32 ) 
		net.WriteInt( self.RightArm, 32 ) 
		net.WriteInt( self.LeftLeg, 32 ) 
		net.WriteInt( self.RightLeg, 32 ) 
	net.Send( self )
end

concommand.Add('hp_reoload', function(ply, cmd, args)
    ply:HPinit()
end)

function Meta:HPrefresh()
    net.Start('hp_refresh')
    net.Send(self)
end

local function FOScalePlayerDamage(ply, hitgroup, dmginfo)
	if(!IsValid(ply) or !ply:IsPlayer()) then return end
    local DmgLimbs
	local ArmorProtect
	
	if(	ply.Torso==0 ) then
		DmgLimbs = 2
	else
		DmgLimbs = 1
	end
	
	if( ply:Armor()>0 ) then
		ArmorProtect = 1/3
	else
		ArmorProtect = 1
	end
			
	if(dmginfo:IsBulletDamage()) then
		if(hitgroup == HITGROUP_HEAD) then
			dmginfo:ScaleDamage( FO.HShotMultiplier * DmgLimbs )
			ply.Head = math.max(ply.Head - dmginfo:GetDamage() * ArmorProtect,0)
		elseif(hitgroup == HITGROUP_LEFTARM) then
			dmginfo:ScaleDamage( FO.AShotMultiplier * DmgLimbs )
			ply.LeftArm = math.max(ply.LeftArm - dmginfo:GetDamage(),0)
		elseif(hitgroup == HITGROUP_RIGHTARM) then
			dmginfo:ScaleDamage( FO.AShotMultiplier * DmgLimbs )
			ply.RightArm = math.max(ply.RightArm - dmginfo:GetDamage(),0)
		elseif(hitgroup == HITGROUP_LEFTLEG) then
			ply.LeftLeg = math.max(ply.LeftLeg - dmginfo:GetDamage(),0)
			dmginfo:ScaleDamage( FO.LShotMultiplier * DmgLimbs )
		elseif(hitgroup == HITGROUP_RIGHTLEG) then
			dmginfo:ScaleDamage( FO.LShotMultiplier * DmgLimbs )
			ply.RightLeg = math.max(ply.RightLeg - dmginfo:GetDamage(),0)
		else
			dmginfo:ScaleDamage( FO.OShotMultiplier * DmgLimbs )
			ply.Torso = math.max(ply.Torso - dmginfo:GetDamage() * ArmorProtect,0)
		end
	end

    ply:HPUpdate()
end
hook.Add('ScalePlayerDamage', 'FOScalePlayerDamage', FOScalePlayerDamage)

local function FOEntityTakeDamage(ply, dmginfo)
	if(!IsValid(ply) or !ply:IsPlayer()) then return end
	if(dmginfo:GetMaxDamage()<=0) then return end

	if(!dmginfo:IsBulletDamage()) then
		if(dmginfo:IsFallDamage()) then
			ply.RightLeg = math.max(ply.RightLeg - dmginfo:GetDamage()/2,0)
			ply.LeftLeg = math.max(ply.LeftLeg - dmginfo:GetDamage()/2,0)
		elseif(dmginfo:IsExplosionDamage() or dmginfo:IsDamageType(DMG_GENERIC) or dmginfo:IsDamageType(DMG_CRUSH) or dmginfo:IsDamageType(DMG_SLASH) or dmginfo:IsDamageType(DMG_BURN) or dmginfo:IsDamageType(DMG_AIRBOAT)) then
			ply.Head = math.max(ply.Head - dmginfo:GetDamage()/2,0)
			ply.LeftArm = math.max(ply.LeftArm - dmginfo:GetDamage()/2,0)
			ply.RightArm = math.max(ply.RightArm - dmginfo:GetDamage()/2,0)
			ply.LeftLeg = math.max(ply.LeftLeg - dmginfo:GetDamage()/2,0)
			ply.RightLeg = math.max(ply.RightLeg - dmginfo:GetDamage()/2,0)
			ply.Torso = math.max(ply.Torso - dmginfo:GetDamage()/2,0)
		else
			ply.Head = math.max(ply.Head - dmginfo:GetDamage()/8,0)
			ply.LeftArm = math.max(ply.LeftArm - dmginfo:GetDamage()/8,0)
			ply.RightArm = math.max(ply.RightArm - dmginfo:GetDamage()/8,0)
			ply.LeftLeg = math.max(ply.LeftLeg - dmginfo:GetDamage()/8,0)
			ply.RightLeg = math.max(ply.RightLeg - dmginfo:GetDamage()/8,0)
			ply.Torso = math.max(ply.Torso - dmginfo:GetDamage()/8,0)
		end
	end

    ply:HPUpdate()
end
hook.Add('EntityTakeDamage', 'FOEntityTakeDamage', FOEntityTakeDamage)