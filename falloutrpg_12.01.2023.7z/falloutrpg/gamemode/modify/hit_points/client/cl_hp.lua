net.Receive('hp_init', function()
    local pl = LocalPlayer()

    pl.Head = FO.Head
    pl.Torso = FO.Torso
    pl.LeftArm = FO.LeftArm
    pl.RightArm = FO.RightArm
    pl.LeftLeg = FO.LeftLeg
    pl.RightLeg = FO.RightLeg
end)

net.Receive( 'hp_update', function() 
    local pl = LocalPlayer()

	pl.Head = net.ReadInt(32)
	pl.Torso = net.ReadInt(32)
	pl.LeftArm = net.ReadInt(32)
	pl.RightArm = net.ReadInt(32)
	pl.LeftLeg = net.ReadInt(32)
	pl.RightLeg = net.ReadInt(32)
end)

function GetBrokenLimbs(ply)
    if ply.Head <= 0 or ply.Torso <= 0 or ply.LeftArm <= 0 or ply.RightArm <= 0 or ply.LeftLeg <= 0 or ply.RightLeg <= 0 then
        return true
    end
end

function GetDamagedLimbs(ply)
    if ply.Head <= FO.Head/2 or ply.Torso <= FO.Torso/2 or ply.LeftArm <= FO.LeftArm/2 or ply.RightArm <= FO.RightArm/2 or ply.LeftLeg <= FO.LeftLeg/2 or ply.RightLeg <= FO.RightLeg/2 then
        return true
    end
end

function GetAllDamagedLimbs(ply)
    if ply.Head < FO.Head or ply.Torso < FO.Torso or ply.LeftArm < FO.LeftArm or ply.RightArm < FO.RightArm or ply.LeftLeg < FO.LeftLeg or ply.RightLeg < FO.RightLeg then
        return true
    end
end