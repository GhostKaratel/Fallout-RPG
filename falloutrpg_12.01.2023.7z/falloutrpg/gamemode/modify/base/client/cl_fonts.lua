
FO.Fonts = FO.Fonts or {}

function FO.fonts(name)
    if FO.Fonts[name] then return FO.Fonts[name] end
	local font,size
	if isnumber(name) then
		font = 'Monofonto'
		size = name
	elseif isstring(name) then
		sizen,fontn = string.match(name,'(.*):(.*)')
		if sizen and fontn then
			size = tonumber(sizen) or 10
			font = fontn
		else
			FO.Fonts[name] = name
			return FO.Fonts[name]
		end
	end
    FO.Fonts[name] = 'fo_font.' .. size .. '.' .. font
    surface.CreateFont(FO.Fonts[name], {
        font = font,
        size = size,
        weight = 0,
        antialias = true,
        extended = true,
    })
    return FO.Fonts[name]
end

surface.CreateFont('SP_TITLE', {font = 'CQ Mono [RUS by Daymarius]', size = 34, weight = 0, antialias = true, extended = true})
surface.CreateFont('SP_DESC', {font = 'CQ Mono [RUS by Daymarius]', size = 20, weight = 0, antialias = true, extended = true})
surface.CreateFont('SP_POINT', {font = 'Monofonto', size = 64, weight = 0, antialias = true, extended = true})
surface.CreateFont('SP_SPECIALPOINT', {font = 'Monofonto', size = 100, weight = 0, antialias = true, extended = true})
surface.CreateFont('SP_BTN', {font = 'CQ Mono [RUS by Daymarius]', size = 20, weight = 0, antialias = true, extended = true})
surface.CreateFont('SP_NAME', {font = 'Akrobat-Bold', size = 28, weight = 0, antialias = true, extended = true})

surface.CreateFont('INV_NAME', {font = 'Akrobat-Bold', size = 22, weight = 0, antialias = true, extended = true})
surface.CreateFont('INV_DESC', {font = 'Akrobat-Bold', size = 26, weight = 0, antialias = true, extended = true})

surface.CreateFont('CH_BTN', {font = 'CQ Mono [RUS by Daymarius]', size = 25, weight = 0, antialias = true, extended = true})

surface.CreateFont('HP_INTERFACE', {font = 'CQ Mono [RUS by Daymarius]', size = 30, weight = 0, antialias = true, extended = true})
surface.CreateFont('HP_INTERFACE_SHADOW', {font = 'CQ Mono [RUS by Daymarius]', size = 30, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('EXP_INTERFACE', {font = 'Akrobat-Bold', size = 28, weight = 0, antialias = true, extended = true})
surface.CreateFont('EXP_INTERFACE_SHADOW', {font = 'Akrobat-Bold', size = 28, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('LVL_INTERFACE', {font = 'Akrobat-Bold', size = 26, weight = 0, antialias = true, extended = true})
surface.CreateFont('LVL_INTERFACE_SHADOW', {font = 'Akrobat-Bold', size = 26, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('MN_INTERFACE', {font = 'Akrobat-Bold', size = 26, weight = 0, antialias = true, extended = true})
surface.CreateFont('MN_INTERFACE_SHADOW', {font = 'Akrobat-Bold', size = 26, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('TM_INTERFACE', {font = 'Akrobat-Bold', size = 22, weight = 0, antialias = true, extended = true})
surface.CreateFont('TM_INTERFACE_SHADOW', {font = 'Akrobat-Bold', size = 22, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('AM_INTERFACE', {font = 'Akrobat-Bold', size = 40, weight = 0, antialias = true, extended = true})
surface.CreateFont('AM_INTERFACE_SHADOW', {font = 'Akrobat-Bold', size = 40, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('NOTIFYCATION', {font = 'Montserrat Medium', size = 20, antialias = true, weight = 0, extended = true})

surface.CreateFont('TITLE_F4', {font = 'Akrobat-Bold', size = 28, weight = 0, antialias = true, extended = true})
surface.CreateFont('TITLE_F4_SHADOW', {font = 'Akrobat-Bold', size = 28, weight = 0, antialias = true, extended = true, blursize = 2})

surface.CreateFont('CATEGORY_F4', {font = 'MonofontoRUSBYMelman-Regular', size = 40, weight = 0, antialias = true, extended = true})
surface.CreateFont('TEXT_F4', {font = 'MonofontoRUSBYMelman-Regular', size = 34, weight = 0, antialias = true, extended = true})
surface.CreateFont('INFO_F4', {font = 'Akrobat-Bold', size = 25, weight = 0, antialias = true, extended = true})

surface.CreateFont('TABS_F4', {font = 'New_Channel_Font-Medium', size = 22, antialias = true, weight = 0, extended = true})
surface.CreateFont('TABS_F4_SHADOW', {font = 'New_Channel_Font-Medium', size = 22, antialias = true, weight = 0, extended = true, blursize = 2})
--surface.CreateFont('TABS_F4', {font = 'Inter Extra Light BETA', size = 24, weight = 0, extended = true})

surface.CreateFont('MONEY_TEXT', {font = 'Montserrat Medium', size = 100, weight = 0, antialias = true, extended = true})
surface.CreateFont('MONEY_TEXT_SHADOW', {font = 'Montserrat Medium', size = 100, weight = 0, antialias = true, extended = true, blursize = 2})
