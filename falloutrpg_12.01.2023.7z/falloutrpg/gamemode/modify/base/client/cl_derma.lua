local blur = Material( 'pp/blurscreen' )

function PrimaryСolor()
	local col = Vector(LocalPlayer():GetInfo("cl_playercolor"))

	return Color(col.x * 255, col.y * 255, col.z * 255)
end

function SecondaryСolor()
	local col = Vector(LocalPlayer():GetInfo("cl_weaponcolor"))

	return Color(col.x * 255, col.y * 255, col.z * 255)
end

function FO.Sound( sound )
	surface.PlaySound(sound)
end

function FO.Text( text, font, w, h, color, xalign, yalign )
	draw.SimpleText( text, font, w, h, color, xalign, yalign )
end

function FO.Image( x, y, w, h, color, material )
	surface.SetDrawColor( color )
	surface.SetMaterial( Material( material ) )
	surface.DrawTexturedRect( x, y, w, h ) 
end

function FO.ColorAlpha( col, mul )
	return Color( col.r, col.g, col.b, col.a * mul )
end

function FO.BoxBlur( x, y, w, h, layers, density, alpha )
	local scrW, scrH = ScrW(), ScrH()
	local Fraction = 1

	surface.SetDrawColor( 255, 255, 255, alpha )
	surface.SetMaterial( blur )
		
	for i=0.33, layers, 0.33 do
		blur:SetFloat( '$blur', Fraction * 5 * ( i / layers ) * density )
		blur:Recompute()
	
		if ( render ) then render.UpdateScreenEffectTexture() end
		render.SetScissorRect( x, y, x + w, y + h, true )
			surface.DrawTexturedRect( 0, 0, scrW, scrH )
		render.SetScissorRect( 0, 0, 0, 0, false )
	end
end

function FO.PanelBlur( panel, amount )
	local Fraction = 1
	local x, y = panel:LocalToScreen(0, 0)
	local scrW, scrH = ScrW(), ScrH()
	
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(blur)
	for i=0.33, 1, 0.33 do
		blur:SetFloat('$blur', Fraction * amount * i)
		blur:Recompute()
		if ( render ) then render.UpdateScreenEffectTexture() end
		surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
	end
end

function FO.BackgroundBlur( panel, amount )
	local Fraction = 1
	local x, y = panel:LocalToScreen(0, 0)
	local scrW, scrH = ScrW(), ScrH()
	
	local wasEnabled = DisableClipping( true )
	
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(blur)
	for i=0.33, 1, 0.33 do
		blur:SetFloat('$blur', Fraction * amount * i)
		blur:Recompute()
		if ( render ) then render.UpdateScreenEffectTexture() end
		surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
	end

	DisableClipping( wasEnabled )
end

function ItemSelect(ITEMdata, k, v, type, ent)
	local BackgroundColor = Color(40,25,15,200)
	local PC = PrimaryСolor()
	local SC = SecondaryСolor()

	if IsValid(FO.INV.SelectPanel) then
		FO.INV.SelectPanel:Remove()
	end

    FO.INV.SelectPanel = vgui.Create('DFrame')
	FO.INV.SelectPanel:SetSize(ScrW(), ScrH())
	FO.INV.SelectPanel:Center()
	FO.INV.SelectPanel:SetTitle('')
	FO.INV.SelectPanel:ShowCloseButton(false)
	FO.INV.SelectPanel:SetDraggable(false)   
	FO.INV.SelectPanel:MakePopup()  
	FO.INV.SelectPanel.Paint = function(self, w, h) end
	
	local ParentPanel = vgui.Create( 'DPanel', FO.INV.SelectPanel)
	ParentPanel:SetSize(500, 200)
	ParentPanel:Center()
	ParentPanel.Paint = function(self, w, h)
		draw.RoundedBox(16, 0, 0, w, h, BackgroundColor)
		FO.BackgroundBlur(self, 8)	

		draw.RoundedBox(0, w/2 - 150, 60, 300, 25, ColorAlpha(PC,10))
		FO.Text(FO.Language.how_many, 'TITLE_F4', w/2, 30, SC, 1, 1)	

		FO.Image( 10, 10, 2, 32, PC, FO.Materials.fade_bottom )
		FO.Image( w-13, 10, 2, 32, PC, FO.Materials.fade_bottom )
		FO.Image( 10, h-44, 2, 32, PC, FO.Materials.fade_top )
		FO.Image( w-13, h-44, 2, 32, PC, FO.Materials.fade_top )
		
		draw.RoundedBox(0, 10, 10, w-20, 2, PC)
		draw.RoundedBox(0, 10, h-13, w-21, 2, PC)
	end

	local SliderAmount = vgui.Create( 'DNumSlider', ParentPanel)
	SliderAmount:SetSize( 300, 25 ) 
	SliderAmount:SetPos(ParentPanel:GetWide()/2 - 150, 60)
	SliderAmount:SetText( '' )
	SliderAmount:SetMinMax( 0, math.Clamp(v.amount,0,300) )
	SliderAmount:SetDecimals( 3 )
	function SliderAmount:Paint(w,h) 
		if SliderAmount:GetValue() then
			local value = SliderAmount:GetValue() * (300/v.amount)

			draw.RoundedBox(0, 0, 0, value, h, PC)
		end
	end	

	SliderAmount.PerformLayout = function()
		SliderAmount:GetTextArea():SetWide(0)
		SliderAmount.Label:SetWide(0)
		SliderAmount.Slider:SetPos(0,0)
		SliderAmount.Slider.Knob:SetSize(5,25)
		SliderAmount.Slider.Knob:SetPos(4,25)
		SliderAmount.Slider.Paint = function( self, w, h ) end
		SliderAmount.Slider.Knob.Paint = function( self, w, h ) end     
	end

	local AddButton = vgui.Create( 'DButton', ParentPanel )
	AddButton:SetText( '' )
	AddButton:SetPos( ParentPanel:GetWide()/2 + 155, 60 )
	AddButton:SetSize( 25, 25 )
	AddButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			FO.Text('►', 'TITLE_F4', w/2, h/2, FO.WHITE, 1, 1)	
		else
			FO.Text('►', 'TITLE_F4', w/2, h/2, PC, 1, 1)	
		end
	end
	
	AddButton.DoClick = function()
		SliderAmount:SetValue(math.Clamp(SliderAmount:GetValue() + 1,0,v.amount))
	end

	local TakeButton = vgui.Create( 'DButton', ParentPanel )
	TakeButton:SetText( '' )
	TakeButton:SetPos( ParentPanel:GetWide()/2 - 180, 60 )
	TakeButton:SetSize( 25, 25 )
	TakeButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			FO.Text('◄', 'TITLE_F4', w/2, h/2, FO.WHITE, 1, 1)	
		else
			FO.Text('◄', 'TITLE_F4', w/2, h/2, PC, 1, 1)	
		end
	end
	
	TakeButton.DoClick = function()
		SliderAmount:SetValue(math.Clamp(SliderAmount:GetValue() - 1,0,v.amount))
	end

	local DLabel = vgui.Create( 'DLabel', ParentPanel )
	DLabel:SetSize( 40, 40 )
	DLabel:SetPos(ParentPanel:GetWide()/2 - 20, ParentPanel:GetTall()/1.9)
	DLabel:SetText('')
	DLabel.Paint = function(self, w, h)
		FO.Text( math.Clamp(math.Round(SliderAmount:GetValue()),0,v.amount), 'TITLE_F4', w/2, h/2, PC, 1, 1)	
	end

	local EnterButton = vgui.Create( 'DButton', ParentPanel )
	EnterButton:SetText( '' )
	EnterButton:SetPos( ParentPanel:GetWide()-45, ParentPanel:GetTall()-120 )
	EnterButton:SetSize( 40, 30 )
	EnterButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(SC,10))

			surface.SetDrawColor(SC)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		
		FO.Text(FO.Language.ok, 'INV_NAME', w/2, h/2, PC, 1, 1)	
	end
	
	EnterButton.DoClick = function()
		if SliderAmount:GetValue() <= 0 then return end
		local value = math.Round(SliderAmount:GetValue())

		local ITEMtabl = {
            classname = v.classname, 
            amount = value,
            condition = v.condition,
            price = v.price
        }

		if type == 'drop' then
			net.Start('inv_drop')
				net.WriteTable(ITEMtabl)
			net.SendToServer()
		elseif type == 'use' then
			net.Start('inv_use')
				net.WriteTable(ITEMtabl)
			net.SendToServer()
		elseif type == 'loot_remove' then
			net.Start('inv_loot_remove')
				net.WriteEntity(ent)
				net.WriteTable(ITEMtabl)
			net.SendToServer()
		elseif type == 'loot_give' then
			net.Start('inv_loot_give')
				net.WriteEntity(ent)
				net.WriteTable(ITEMtabl)
			net.SendToServer()
		end

		FO.INV.SelectPanel:Remove()
	end

	local CloseButton = vgui.Create( 'DButton', ParentPanel )
	CloseButton:SetText( '' )
	CloseButton:SetPos( ParentPanel:GetWide()-70, ParentPanel:GetTall()-85 )
	CloseButton:SetSize( 65, 30 )
	CloseButton.Paint = function(self, w, h)
		if self:IsHovered() then 
			draw.RoundedBox(0, 0, 0, w, h, ColorAlpha(SC,10))

			surface.SetDrawColor(SC)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		
		FO.Text(FO.Language.cancel, 'INV_NAME', w/2, h/2, PC, 1, 1)	
	end
	
	CloseButton.DoClick = function()
		FO.INV.SelectPanel:Remove()
	end
	
end