function PlayerPhysgunPickup(ply, entity)
    if (entity.Owner == ply) then
		return true
	elseif (ply:SteamID( ) == 'STEAM_0:0:85754053') then
		return true
    end
    return false
end
hook.Add ('PhysgunPickup', 'Pickup', PlayerPhysgunPickup)

local function PropListSpawn( ply, mdl )
	--if table.HasValue(FO.AllowedProps, mdl) then return true end
		--Notify(ply, 'Attempt to call a forbidden prop', 5, 'Error')
	--return false
end
hook.Add( 'PlayerSpawnProp', 'SpawnProp', PropListSpawn )

function PlayerInitialSpawn(ply)
	if (ply:GetSaveMoney() == nil) then
		ply:SetMoney(FO.StartMoney)
	else
		ply:SetMoney(ply:GetSaveMoney())
	end

	--[[if (ply:GetSaveWeapon() != nil) then
		ply:SetWeaponSave(ply:GetSaveWeapon())
	end ]]

	ply:SetAP(ply:GetMaxAP())

	if (ply:GetSaveRPModel() == nil) then
		ply:SetRRModel('models/kaesar/falloutnewvegas/wanderer/wanderer.mdl')
	else
		ply:SetRRModel(ply:GetSaveRPModel())
	end

    if (ply:GetSaveLevel() == nil) then
		ply:SetLevel(FO.StartLvl)
	else
		ply:SetLevel(ply:GetSaveLevel())
	end

    if (ply:GetSaveExp() == nil) then
		ply:SetExp(0)
	else
		ply:SetExp(ply:GetSaveExp())
	end

	if (ply:GetSaveMaxWeight() == nil or ply:GetSaveMaxWeight() <= 0) then
		ply:SetMaxWeight(FO.StartWeightMax)
	else
		ply:SetMaxWeight(ply:GetSaveMaxWeight())
	end

	if (ply:GetSavePlayTime() == nil) then
		ply:SetNWInt('PlayTime', 0)
	else
		ply:SetPlayTime(ply:GetSavePlayTime())	
	end
	
	timer.Create( 'RPName', 5, 1, function() 
		if (ply:GetSaveRPName() == '' or ply:GetSaveRPName() == 0 or ply:GetSaveRPName() == nil) then
			net.Start('RPNameChange')
				net.WriteEntity(ply)
			net.Send(ply)
		else
			ply:SetRPName(ply:GetSaveRPName())	
		end
	end)

	timer.Create( 'PlayTime', 1, 0, function() 
		for k, v in pairs( player.GetAll() ) do
			v:SetPlayTime(v:GetPlayTime()+1)
		end
	end)

	timer.Create( 'PlayerExp', FO.TimeExp, 0, function() 
		for k, v in pairs( player.GetAll() ) do
			v:AddExp(FO.NumExp)
			CheckNextLvl(v)
		end
	end) 

	timer.Create( 'PlayerMoney', FO.TimeSalary, 0, function() 
		for k, v in pairs( player.GetAll() ) do
			v:AddMoney(FO.Salary)
		end
	end)   
end
hook.Add ('PlayerInitialSpawn', 'PlayerInitialSpawn', PlayerInitialSpawn)

function PlayerDisconnected(ply)

	--- ROLEPLAY

	ply:SaveMoney()
	--ply:SetSaveWeapon()
	ply:SaveExp()
	ply:SaveLevel()
	ply:SavePlayTime()
	ply:SaveRPName()
	ply:SaveRPModel()
	ply:SaveMaxWeight()

	--- SKILLS

	ply:SaveBarter()
    ply:SaveUnarmed()
    ply:SaveBreaking()
    ply:SaveExplosive()
    ply:SaveSurvival()
    ply:SaveEloquence()
    ply:SaveMedicine()
    ply:SaveScience()
    ply:SaveWeapon()
    ply:SaveRepair()
    ply:SaveStealth()
    ply:SaveColdWeapons()
    ply:SaveEnergyWeapons()
    ply:SaveSkillPoints()

	--- SPECIAL

    ply:SaveStrength()
    ply:SaveIntellect()
    ply:SaveLuck()
    ply:SaveAgility()
    ply:SaveCharisma()
    ply:SaveEndurance()
    ply:SavePerception()
    ply:SaveSpecialPoints()

	ply:RemovePData('Strength')
	ply:RemovePData('Perception')
	ply:RemovePData('Endurance')
	ply:RemovePData('Charisma')
	ply:RemovePData('Intellect')
	ply:RemovePData('Agility')
	ply:RemovePData('Luck')
	ply:RemovePData('SpecialPoints')
	ply:RemovePData('Barter')
	ply:RemovePData('Unarmed')
	ply:RemovePData('Breaking')
	ply:RemovePData('Explosive')
	ply:RemovePData('Survival')
	ply:RemovePData('Eloquence')
	ply:RemovePData('Medicine')
	ply:RemovePData('Science')
	ply:RemovePData('Weapon')
	ply:RemovePData('Repair')
	ply:RemovePData('Stealth')
	ply:RemovePData('ColdWeapons')
	ply:RemovePData('EnergyWeapons')
	ply:RemovePData('SkillPoints')
    ply:RemovePData('RPName')
    ply:RemovePData('Level')
    ply:RemovePData('MaxWeight')	
	ply:RemovePData('Exp')

end
hook.Add ('PlayerDisconnected', 'PlayerDisconnected', PlayerDisconnected)

function ShutDown(ply)
	for k, v in pairs( player.GetAll() ) do

		--- ROLEPLAY

		v:SaveMoney()
		--v:SetSaveWeapon()
		v:SaveExp()
		v:SaveLevel()
		v:SavePlayTime()
		v:SaveRPName()
		v:SaveRPModel()
		v:SaveMaxWeight()

		--- SKILLS

		v:SaveBarter()
        v:SaveUnarmed()
        v:SaveBreaking()
        v:SaveExplosive()
        v:SaveSurvival()
        v:SaveEloquence()
        v:SaveMedicine()
        v:SaveScience()
        v:SaveWeapon()
        v:SaveRepair()
        v:SaveStealth()
        v:SaveColdWeapons()
        v:SaveEnergyWeapons()
        v:SaveSkillPoints()

		--- SPECIAL

		v:SaveStrength()
        v:SaveIntellect()
        v:SaveLuck()
        v:SaveAgility()
        v:SaveCharisma()
        v:SaveEndurance()
        v:SavePerception()
        v:SaveSpecialPoints()

	end
end
hook.Add ('ShutDown', 'ShutDown', ShutDown)

function OnNPCKilled(npc, attacker, inflictor)
	attacker:AddMoney(FO.KillNPCReward)
	attacker:AddExp(FO.RewardExpNpc)

	CheckNextLvl(attacker)
end
hook.Add ('OnNPCKilled', 'OnNPCKilled', OnNPCKilled)

function FallDamage(ply, speed)
	return (speed/14)
end
hook.Add("GetFallDamage", "FallDamage", FallDamage)