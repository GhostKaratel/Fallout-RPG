NOTIFY_GENERIC	= 0
NOTIFY_ERROR	= 1
NOTIFY_UNDO		= 2
NOTIFY_HINT		= 3
NOTIFY_CLEANUP	= 4

module( 'notification', package.seeall )

yoff = 150
xoff = 20

local NoticeMaterial = {}

NoticeMaterial[ NOTIFY_GENERIC ] = Material( 'darkroleplay/generic.png' )
NoticeMaterial[ NOTIFY_ERROR ] = Material( 'darkroleplay/error.png' )
NoticeMaterial[ NOTIFY_UNDO ] = Material( 'darkroleplay/undo.png' )
NoticeMaterial[ NOTIFY_HINT ] = Material( 'darkroleplay/hint.png' )
NoticeMaterial[ NOTIFY_CLEANUP ] = Material( 'darkroleplay/cleanup.png' )

local LegacyColor = {
	[NOTIFY_GENERIC] = Color( 225, 225, 225 ),
	[NOTIFY_ERROR] = Color( 225, 45, 45 ),
	[NOTIFY_UNDO] = Color( 45, 150, 225),
	[NOTIFY_HINT] = Color( 255, 180, 70 ),
	[NOTIFY_CLEANUP] = Color( 45, 225, 150 ),
}

Notices = Notices or {}

function AddProgress( uid, text )
	local parent = nil
	if ( GetOverlayPanel ) then parent = GetOverlayPanel() end

	local Panel = vgui.Create( 'NoticePanel', parent )
	Panel.StartTime = SysTime()
	Panel.Length = 1000000
	Panel.VelX = -5
	Panel.VelY = 0
	Panel.fx = ScrW() + 200
	Panel.fy = ScrH()
	Panel:SetText( text )
	Panel:SetPos( Panel.fx, Panel.fy )
	
	Notices[ uid ] = Panel
end

function Kill( uid )
	if ( !IsValid( Notices[ uid ] ) ) then return end
	
	Notices[ uid ].StartTime = SysTime()
	Notices[ uid ].Length = 0.8
end

function AddLegacy( text, type, length )
	assert(isstring(text))
	assert(isnumber(type))
	assert(isnumber(length))

	local parent = nil
	if ( GetOverlayPanel ) then parent = GetOverlayPanel() end

	local Panel = vgui.Create( 'NoticePanel', parent )
	Panel.StartTime = SysTime()
	Panel.Length = length
	Panel.VelX = -5
	Panel.VelY = 0
	Panel.fx = ScrW() + 200
	Panel.fy = ScrH()
	Panel:SetText( text )
	Panel:SetPos( Panel.fx, Panel.fy )
	Panel:SetLegacyType( type )
	Panel:SetAlpha(0)
	Panel:AlphaTo(255, 0.5, 0)	


	table.insert( Notices, Panel )
end

local function UpdateNotice( i, Panel, Count )
	local x = Panel.fx
	local y = Panel.fy
	
	local w = Panel:GetWide()
	local h = Panel:GetTall()

	w = w + 16
	h = h + 16
	
	local ideal_y = ScrH() - (Count - i) * (h-10) - yoff
	local ideal_x = ScrW() - w - xoff

	local timeleft = Panel.StartTime - (SysTime() - Panel.Length)
	
	if ( timeleft < 0.7  ) then
		ideal_x = ideal_x - 50
	end
	 
	if ( timeleft < 0.2  ) then
		ideal_x = ideal_x + w * 2
	end
	
	local spd = RealFrameTime() * 11
	
	y = y + Panel.VelY * spd
	x = x + Panel.VelX * spd
	
	local dist = ideal_y - y
	Panel.VelY = Panel.VelY + dist * spd * 1
	if (math.abs(dist) < 2 && math.abs(Panel.VelY) < 0.1) then Panel.VelY = 0 end
	local dist = ideal_x - x
	Panel.VelX = Panel.VelX + dist * spd * 1
	if (math.abs(dist) < 2 && math.abs(Panel.VelX) < 0.1) then Panel.VelX = 0 end
	
	Panel.VelX = Panel.VelX * (0.95 - RealFrameTime() * 8 )
	Panel.VelY = Panel.VelY * (0.95 - RealFrameTime() * 8 )

	Panel.fx = x
	Panel.fy = y
	Panel:SetPos( Panel.fx, Panel.fy - 100 )
end

local function Update()
	if ( !Notices ) then return end
		
	local i = 0
	local Count = table.Count( Notices )
	for key, Panel in pairs( Notices ) do
		i = i + 1
		UpdateNotice( i, Panel, Count )
	end
	
	for k, Panel in pairs( Notices ) do
		if ( !IsValid(Panel) || Panel:KillSelf() ) then Notices[ k ] = nil end
	end
end

hook.Add( 'Think', 'NotificationThink', Update )


local PANEL = {}

function PANEL:Init(t)
	self:DockPadding( 0, 0, 8, 0 )

	self.Label = vgui.Create( 'DLabel', self )
	self.Label:Dock( FILL )
	self.Label:SetFont( 'NOTIFYCATION' )
	self.Label:SetTextColor( Color( 225, 225, 225, 0 ) )
	self.Label:SetContentAlignment( 5 )
	
	self:SetBackgroundColor( Color( 0, 0, 0, 0 ) )

	self.Paint = function( s, w, h )
   
	self.BaseClass.Paint( self, w, h )

		draw.RoundedBox(8, 0, 0, w, h, Color(40,40,40,0))

    end
end

function PANEL:SetText( txt )
	self.Label:SetText( txt )
	self:SizeToContents()
end

function PANEL:SizeToContents()
	self.Label:SizeToContents()
	
	local width = self.Label:GetWide()
	
	if ( IsValid( self.Image ) ) then
	
		width = width + 32 
	
	end

	width = width + 30
	
	self:SetWidth( width )
	
	self:SetHeight(self.Label:GetTall() + 26)
	
	self:InvalidateLayout()
end

function PANEL:SetLegacyType( t )
	self.Image = vgui.Create( 'DImageButton', self )
	self.Image:SetMaterial( NoticeMaterial[ t ] )
	self.Image:SetSize( 32, 32 )
	self.Image:Dock( LEFT )
	self.Image:DockMargin( 7, 7, 7, 7 )
	self.Image:SetColor(ColorAlpha(LegacyColor[ t ], 0))
	self.Image.DoClick = function()
		self.StartTime = 0
	end
	
	self:SizeToContents()
end

function PANEL:KillSelf()
	if ( self.StartTime + self.Length < SysTime() ) then
	
		self:Remove()
		return true
	
	end

	return false
end

vgui.Register( 'NoticePanel', PANEL, 'DPanel' )
