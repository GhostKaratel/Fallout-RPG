local Meta = FindMetaTable('Player')

function Meta:SetAP(point)
	self:SetNWInt('ActionPoint', math.Clamp(point, 0, 65+3*self:GetLuck()))
end

function Meta:AddAP(point)
	local AP = self:GetAP()

	self:SetAP(AP + point)
end

function Meta:TakeAP(point)
	local AP = self:GetAP()

	self:SetAP(AP - point)
end

function Jump(ply)

	timer.Create( "UniqueName2", 1, 0, function() ply:AddAP(1) end )
end

local Dealy = 15
local DRest = 25
hook.Add( "PlayerTick", "FO.AP", function( ply, mv )
	local Sprint
	local AP = ply:GetAP()
	local MaxAP = ply:GetMaxAP()
	local Move = ply:GetMoveType()

	Sprint = ply:GetVelocity():Length2D() > ply:GetRunSpeed() * 0.6 and ply:IsSprinting() and ply:OnGround()

	if Sprint and not mv:KeyDown(IN_JUMP) then 
		if Dealy > 0 then
			Dealy = Dealy - 1
		else
			ply:TakeAP(1)
			
			Dealy = 15
		end
	elseif not ply:OnGround() and mv:KeyDown(IN_JUMP) and Move != MOVETYPE_NOCLIP then
		ply:TakeAP(1)
	else
		if AP < MaxAP then
			if DRest > 0 then
				DRest = DRest - 1
				
				if DRest <= 0 then
					ply:AddAP(1)
	
					DRest = 25 
				end
			end	
		end
	end

	if AP <= 15 then
		ply:SetJumpPower(0)
		ply:SetRunSpeed(140)
		ply:SetWalkSpeed(140)
	else
		ply:SetJumpPower(FO.JumpPower)
		ply:SetRunSpeed(FO.RunSpeed)
		ply:SetWalkSpeed(FO.WalkSpeed)
	end
end )

	--[[if ( ply:WaterLevel() >= 2 ) then mv:SetUpSpeed( -100 ) cmd:SetUpMove( -100 ) end]]