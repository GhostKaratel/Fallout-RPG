local Meta = FindMetaTable('Player')

function Meta:GetAP()
	return tonumber(self:GetNWInt('ActionPoint'))
end

function Meta:GetMaxAP()
	return tonumber(65+3*self:GetLuck())
end