include('shared.lua')
include(GM.FolderName..'/gamemode/config/cfg.lua')
include(GM.FolderName..'/gamemode/config/jobs.lua')