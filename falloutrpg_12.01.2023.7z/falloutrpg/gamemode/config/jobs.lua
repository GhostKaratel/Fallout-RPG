FO.Teams:CreateCategies('Fallout')

TEAM_CITIZEN = FO.Teams:Create('Wastelander', {
    color = Color(240, 170, 80),
    weapons = {'weapon_fists'},
    models = {'models/player/gman_high.mdl','models/player/mossman.mdl'},
    salary = 40,
    isDefaultJob = true,
    description = [[...]],
    category = 'Fallout'
})