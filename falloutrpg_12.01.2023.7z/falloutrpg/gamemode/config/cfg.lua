/*
    Default config spawn player
*/

FO.JumpPower = 160
FO.RunSpeed = 225
FO.WalkSpeed = 140
FO.KillNPCReward = 100
FO.TimeSalary = 60
FO.Salary = 120
FO.StartMoney = 1500
FO.moneyModel100 = 'models/mark2580/gtav/mp_office_03c/accessories/cash_pile_02_1.mdl'
FO.moneyModel1000 = 'models/mark2580/gtav/mp_office_03c/accessories/cash_pile_01_1.mdl'
FO.moneyModel10000 = 'models/mark2580/gtav/mp_office_03c/accessories/cash_roll_01.mdl'
FO.moneyModel100000 = 'models/mark2580/gtav/mp_office_03c/accessories/swag_counterfeit2.mdl'
FO.moneyModel1000000 = 'models/mark2580/gtav/mp_office_03c/accessories/cash_case.mdl'
FO.moneyModelmore = 'models/mark2580/gtav/mp_office_03c/accessories/cash_crate_01.mdl'    
FO.StartWeightMax = 150

/*
    HP system
*/

FO.StartHealth = 95
FO.Head = 35
FO.Torso = 60
FO.LeftArm = 40
FO.RightArm = 40
FO.LeftLeg = 50
FO.RightLeg = 50
FO.HShotMultiplier = 1.75
FO.AShotMultiplier = 0.75
FO.LShotMultiplier = 0.75
FO.OShotMultiplier = 1.25

/*
    Level system
*/

FO.StartLvl = 1
FO.TimeExp = 900
FO.NumExp = 5
FO.RewardExpNpc = 125
FO.PointsLevel = 26
FO.StartPoints = 35

/*
    Color theme
*/

FO.Theme = {
    basecolor = Color(240,170,80),
    warncolor = Color(240,125,25),
    enemycolor = Color(240,25,25),
    shadowcolor = Color(0,0,0,175), 
}

/*
    Global color
*/

FO.WHITE = Color(255,255,255)
FO.RED = Color(212,21,21)
FO.ORANGE = Color(240,109,34)
FO.YELLOW = Color(255,233,40)
FO.GREEN = Color(16,231,27)
FO.BLUE = Color(11,148,240)
FO.BLACK = Color(0,0,0)

/*
    Sounds
*/

FO.Sounds = {
--  Hacking
 
    charenter_01 = 'hacking/ui_hacking_charenter_01.wav',
    charenter_02 = 'hacking/ui_hacking_charenter_02.wav',
    charenter_03 = 'hacking/ui_hacking_charenter_03.wav',
    
    charmultiple_01 = 'hacking/ui_hacking_charmultiple_01.wav',
    charmultiple_02 = 'hacking/ui_hacking_charmultiple_02.wav',
    charmultiple_03 = 'hacking/ui_hacking_charmultiple_03.wav',
    charmultiple_04 = 'hacking/ui_hacking_charmultiple_04.wav',
    
    charscroll = 'hacking/ui_hacking_charscroll.wav',
    charscroll_lp = 'hacking/ui_hacking_charscroll_lp.wav',
    charsingle_01 = 'hacking/ui_hacking_charsingle_01.wav',
    charsingle_02 = 'hacking/ui_hacking_charsingle_02.wav',
    charsingle_03 = 'hacking/ui_hacking_charsingle_03.wav',
    charsingle_04 = 'hacking/ui_hacking_charsingle_04.wav',
    charsingle_05 = 'hacking/ui_hacking_charsingle_05.wav',
    charsingle_06 = 'hacking/ui_hacking_charsingle_06.wav',
    
    passbad = 'hacking/ui_hacking_passbad.wav',
    passgood = 'hacking/ui_hacking_passgood.wav',

--  Health

    chems_addicted = 'health/ui_health_chems_addicted.wav',
    chems_wearoff = 'health/ui_health_chems_wearoff.wav',
    
    heartbeat_a_lp = 'health/ui_health_heartbeat_a_lp.wav',
    heartbeat_b_lp = 'health/ui_health_heartbeat_b_lp.wav',

--  Item

    ammo_bbs_down = 'items/ui_items_ammo_bbs_down.wav',
    ammo_bbs_up_01 = 'items/ui_items_ammo_bbs_up_01.wav',
    ammo_bbs_up_02 = 'items/ui_items_ammo_bbs_up_02.wav',
    
    bottlecaps_down_01 = 'items/ui_items_bottlecaps_down_01.wav',
    bottlecaps_down_02 = 'items/ui_items_bottlecaps_down_02.wav',
    bottlecaps_up_01 = 'items/ui_items_bottlecaps_up_01.wav',
    bottlecaps_up_02 = 'items/ui_items_bottlecaps_up_02.wav',
    bottlecaps_up_03 = 'items/ui_items_bottlecaps_up_03.wav',
    bottlecaps_up_04 = 'items/ui_items_bottlecaps_up_04.wav',
    
    clothing_down_01 = 'items/ui_items_clothing_down_01.wav',
    clothing_down_02 = 'items/ui_items_clothing_down_02.wav',
    clothing_down_03 = 'items/ui_items_clothing_down_03.wav',
    clothing_up_01 = 'items/ui_items_clothing_up_01.wav',
    clothing_up_02 = 'items/ui_items_clothing_up_02.wav',
    clothing_up_03 = 'items/ui_items_clothing_up_03.wav',
    
    generic_down = 'items/ui_items_generic_down.wav',
    generic_up_01 = 'items/ui_items_generic_up_01.wav',
    generic_up_02 = 'items/ui_items_generic_up_02.wav',
    generic_up_03 = 'items/ui_items_generic_up_03.wav',
    generic_up_04 = 'items/ui_items_generic_up_04.wav',
    
    grenade_down = 'items/ui_items_grenade_down.wav',
    grenade_up = 'items/ui_items_grenade_up.wav',
    
    gunsbig_down = 'items/ui_items_gunsbig_down.wav',
    gunsbig_up = 'items/ui_items_gunsbig_up.wav',
    gunssmall_down = 'items/ui_items_gunssmall_down.wav',
    gunssmall_up = 'items/ui_items_gunssmall_up.wav',
   
    melee_down = 'items/ui_items_melee_down.wav',
    melee_up = 'items/ui_items_melee_up.wav',
    
    ui_items_takeall = 'items/ui_items_takeall.wav',

--  Reputation

    rep_bad = 'reputation/ui_rep_bad.wav',
    rep_good = 'reputation/ui_rep_good.wav',

--  Menu
  
    cancel = 'menu/ui_menu_cancel.wav',
    focus = 'menu/ui_menu_focus.wav',
    ok = 'menu/ui_menu_ok.wav',
    prevnext = 'menu/ui_menu_prevnext.wav',
    
--  Pip-Boy
       
    down = 'pipboy/ui_pipboy_access_down.wav',
    up = 'pipboy/ui_pipboy_access_up.wav',
    clampon = 'pipboy/ui_pipboy_clampon.wav',
    highlight = 'pipboy/ui_pipboy_highlight.wav',
    
    holotape_start = 'pipboy/ui_pipboy_holotape_start.wav',
    holotape_stop = 'pipboy/ui_pipboy_holotape_stop.wav',
    
    hum_lp = 'pipboy/ui_pipboy_hum_lp.wav',

    light_off = 'pipboy/ui_pipboy_light_off.wav',
    light_on = 'pipboy/ui_pipboy_light_on.wav',

    radiation_a_01 = 'pipboy/ui_pipboy_radiation_a_01.wav',
    radiation_a_02 = 'pipboy/ui_pipboy_radiation_a_02.wav',
    radiation_a_03 = 'pipboy/ui_pipboy_radiation_a_03.wav',
    radiation_b_01 = 'pipboy/ui_pipboy_radiation_b_01.wav',
    radiation_b_02 = 'pipboy/ui_pipboy_radiation_b_02.wav',
    radiation_b_03 = 'pipboy/ui_pipboy_radiation_b_03.wav',
    radiation_c_01 = 'pipboy/ui_pipboy_radiation_c_01.wav',
    radiation_c_02 = 'pipboy/ui_pipboy_radiation_c_02.wav',
    radiation_c_03 = 'pipboy/ui_pipboy_radiation_c_03.wav',
    radiation_test_lp = 'pipboy/ui_pipboy_radiation_test_lp.wav',

    mode = 'pipboy/ui_pipboy_mode.wav',
    selects = 'pipboy/ui_pipboy_select.wav',
    tab = 'pipboy/ui_pipboy_tab.wav',
    tuner = 'pipboy/ui_pipboy_tuner.wav',

    static_c_01 = 'pipboy/ui_static_c_01.wav',
    static_c_02 = 'pipboy/ui_static_c_02.wav',
    static_c_03 = 'pipboy/ui_static_c_03.wav',
    static_c_04 = 'pipboy/ui_static_c_04.wav',
    static_c_05 = 'pipboy/ui_static_c_05.wav',
    static_d_01 = 'pipboy/ui_static_d_01.wav',
    static_d_02 = 'pipboy/ui_static_d_02.wav',
    static_d_03 = 'pipboy/ui_static_d_03.wav',
    static_d_04 = 'pipboy/ui_static_d_04.wav',
}

/*
    Materials
*/

FO.Materials = {  
--  HUD
     
    left_seperatorglow = 'hud/glow_hud_left_seperatorglow.png',
    right_seperatorglow = 'hud/glow_hud_right_seperatorglow.png',
    messages_radiation_seperator_right = 'hud/glow_messages_radiation_seperator_right.png',
    messages_radiation_seperator_new = 'hud/glow_messages_radiation_seperator_new.png',
    crosshair01 = 'hud/glow_crosshair.png',
    crosshair02 = 'hud/glow_crosshair2.png',
    tick_mark = 'hud/hud_tick_mark.png',
    bottom_info_seperator_divider = 'hud/glow_hud_bottom_info_seperator_divider.png',

--  Stats
    
    face_00 = 'stats/face_00.png',
    face_01 = 'stats/face_01.png',
    face_02 = 'stats/face_02.png',
    face_03 = 'stats/face_03.png',
    face_04 = 'stats/face_04.png',
    face_05 = 'stats/face_10.png',
    
    head = 'stats/head.png',
    head_broken = 'stats/head_broken.png',
    
    left_arm = 'stats/left_arm.png',
    left_arm_broken = 'stats/left_arm_broken.png',
    left_leg = 'stats/left_leg.png',
    left_leg_broken = 'stats/left_leg_broken.png',
    
    right_arm = 'stats/right_arm.png',
    right_arm_broken = 'stats/right_arm_broken.png',
    right_leg = 'stats/right_leg.png',
    right_leg_broken = 'stats/right_leg_broken.png',
    
    torso = 'stats/torso.png',
    torso_broken = 'stats/torso_broken.png',

--  Menu

    fade_bottom = 'shared/line/fade_bottom.png',
    fade_top = 'shared/line/fade_top.png',
    fade_left = 'shared/line/fade_left.png',
    fade_right = 'shared/line/fade_right.png',

--  Skills

    barter = 'icons/stats/skills_barter.png',
    big_guns = 'icons/stats/skills_big_guns.png',
    energy_weapons = 'icons/stats/skills_energy_weapons.png',
    explosives = 'icons/stats/skills_explosives.png',
    medicine = 'icons/stats/skills_medicine.png',
    melee_weapons = 'icons/stats/skills_melee_weapons.png',
    repair = 'icons/stats/skills_repair.png',
    science = 'icons/stats/skills_science.png',
    small_guns = 'icons/stats/skills_small_guns.png',
    sneak = 'icons/stats/skills_sneak.png',
    speech = 'icons/stats/skills_speech.png',
    survival = 'icons/stats/skills_survival.png',
    throwing = 'icons/stats/skills_throwing.png',
    unarmed = 'icons/stats/skills_unarmed.png',
    lockpick = 'icons/stats/skills_lockpick.png',

--  S.P.E.C.I.A.L.

    s_agility = 'icons/pipboyimages/s.p.e.c.i.a.l/special_agility.png',
    s_charisma = 'icons/pipboyimages/s.p.e.c.i.a.l/special_charisma.png',
    s_endurance = 'icons/pipboyimages/s.p.e.c.i.a.l/special_endurance.png',
    s_intelligence = 'icons/pipboyimages/s.p.e.c.i.a.l/special_intelligence.png',
    s_luck = 'icons/pipboyimages/s.p.e.c.i.a.l/special_luck.png',
    s_perception = 'icons/pipboyimages/s.p.e.c.i.a.l/special_perception.png',
    s_strength = 'icons/pipboyimages/s.p.e.c.i.a.l/special_strength.png',

--  Weapons
  
    assault_rifle = 'icons/pipboyimages/weapons/assault_rifle.png',
    mm10_pistol = 'icons/pipboyimages/weapons/weapons_10mm_pistol.png',

--  Items
   
    stimpack = 'icons/pipboyimages/items/items_stimpack.png',
    mm10_rounds = 'icons/pipboyimages/items/items_10mm_rounds.png',
    money_ncr_5 = 'icons/pipboyimages/items/items_money_ncr_5.png',

--  Appareal

    ncr_ranger_combat_armor = 'icons/pipboyimages/apparel/apparel_ncr_ranger_combat_armor.png',
}

/*
    Default spawn weapons
*/

FO.DefaultWeapon = {
    'weapon_physcannon',
    'weapon_physgun',
    'gmod_tool'
}

/*
    Language
*/

FO.Language = {
--  HUD

    hudhealth = 'ОЗ: ',
    hudactionpoint = 'ОД: ',
    hudmoney = 'Крышки: ',
    hudtime = 'Время: ',
    hudlevel = 'Урв: ',

--  F4Menu

    f4title = 'Pip-Boy',
    f4titlestats = 'С Т А Т',
    f4titleitems = 'С Н А Р',
    f4titledata = 'И Н Ф О',
    f4titleweapons = 'Оружие',
    f4titleapparel = 'Костюмы',
    f4titleaid = 'Помощь',
    f4titlemisc = 'Разное',
    f4titleammo = 'Боезапас',
    f4titlespawn = 'Спавн',
    f4titlestatus = 'Статус',
    f4titlespecial = 'S.P.E.C.I.A.L.',
    f4titleskills = 'Навыки',
    f4titleperks = 'Способности',
    f4titlegeneral = 'Общая',
    f4titlelocalmap = 'Локация',
    f4titleworldmap = 'Мир',
    f4titlequests = 'Задания',
    f4titlemiscs = 'Разное',
    f4titleradio = 'Радио',
    f4titlecnd = 'СТТ',
    f4titlerad = 'РАД',
    f4titleeff = 'ЭФ',
    f4enter = 'Готово А)',
    
    infof4health = 'ОЗ',
    infof4weight = 'Вс',
    infof4caps = 'Крыш.',
    infof4ap = 'ОД',
    infof4dt = 'ПУ',
    infof4lvl = 'УР',
    infof4exp = 'ОО',

-- SPECIAL

    TabStrength = 'Сила',
    TabPerception = 'Восприятие',
    TabEndurance = 'Выносливость',
    TabCharisma = 'Харизма',
    TabIntellect = 'Интеллект',
    TabAgility = 'Ловкость',
    TabLuck = 'Удача',

-- SKILLS

    TabBarter = 'Бартер',
    TabUnarmed = 'Без оружия',
    TabBreaking = 'Взлом',
    TabExplosive = 'Взрывчатка',
    TabSurvival = 'Выживание',
    TabEloquence = 'Красноречие',
    TabMedicine = 'Медицина',
    TabScience = 'Наука',
    TabGun = 'Оружие',
    TabRepair = 'Ремонт',
    TabStealth = 'Скрытность',
    TabColdWeapons = 'Холодное оружие',
    TabEnergyWeapons = 'Энергооружие',
    TabTitlePoint = 'Осталось очков: ',

--  TAB

    tabtitle = 'Таб',
    tabonline = 'Онлайн: ',    

--  Loot

    ok = 'Ок',
    how_many = 'Сколько?',
    cancel = 'Назад',

-- Name

    SelectName = 'Выбрать',
    ExtitGame = 'Выйти',
    ChangeName = 'Введите имя персонажа',
}

/*
    List of allowed generating props for all
*/

FO.AllowedProps = {
    'models/props/cs_assault/camera.mdl',
    'models/props/cs_assault/ConsolePanelLoadingBay.mdl',
    'models/props/cs_assault/dryer_box.mdl',
    'models/props/cs_assault/wall_vent.mdl',
    'models/props/CS_militia/bar01.mdl',
    'models/props/CS_militia/barstool01.mdl',
    'models/props/CS_militia/caseofbeer01.mdl',
    'models/props/CS_militia/couch.mdl',
    'models/props/CS_militia/dryer.mdl',
    'models/props/CS_militia/toilet.mdl',
    'models/props/CS_militia/toothbrushset01.mdl',
    'models/props/CS_militia/television_console01.mdl',
    'models/props/CS_militia/table_kitchen.mdl',
    'models/props/CS_militia/urine_trough.mdl',
    'models/props/CS_militia/vent01.mdl',
    'models/props/CS_militia/paintbucket01.mdl',
    'models/props/cs_office/Bookshelf1.mdl',
    'models/props/cs_office/Chair_office.mdl',
    'models/props/cs_office/coffee_mug.mdl',
    'models/props/cs_office/coffee_mug3.mdl',
    'models/props/cs_office/coffee_mug2.mdl',
    'models/props/cs_office/computer.mdl',
    'models/props/cs_office/computer_caseB.mdl',
    'models/props/cs_office/file_box.mdl',
    'models/props/cs_office/file_cabinet1.mdl',
    'models/props/cs_office/file_cabinet1_group.mdl',
    'models/props/cs_office/Fire_Extinguisher.mdl',
    'models/props/cs_office/file_cabinet3.mdl',
    'models/props/cs_office/file_cabinet2.mdl',
    'models/props/cs_office/microwave.mdl',
    'models/props/cs_office/offcertificatea.mdl',
    'models/props/cs_office/Paper_towels.mdl',
    'models/props/cs_office/phone.mdl',
    'models/props/cs_office/plant01.mdl',
    'models/props/cs_office/radio.mdl',
    'models/props/cs_office/Shelves_metal3.mdl',
    'models/props/cs_office/sofa.mdl',
    'models/props/cs_office/sofa_chair.mdl',
    'models/props/cs_office/trash_can.mdl',
    'models/props/cs_office/TV_plasma.mdl',
    'models/props/cs_office/Vending_machine.mdl',
    'models/props/cs_office/Water_bottle.mdl',
    'models/props/de_nuke/equipment1.mdl',
    'models/props/de_nuke/NuclearControlBox.mdl',
    'models/props/de_nuke/NuclearTestCabinet.mdl',
    'models/props/de_piranesi/pi_bucket.mdl',
    'models/props/de_inferno/Radiator01a.mdl',
    'models/props/de_inferno/bed.mdl',
    'models/props/de_inferno/potted_plant3.mdl',
    'models/props/de_tides/patio_table.mdl',
    'models/props/de_tides/Vending_turtle.mdl',
    'models/props_phx/construct/metal_tube.mdl',
    'models/props_phx/construct/metal_plate1.mdl',
    'models/props_phx/construct/windows/window1x1.mdl',
    'models/hunter/blocks/cube1x1x025.mdl',
    'models/hunter/triangles/1x1x1.mdl'
}