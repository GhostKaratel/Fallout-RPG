GM = GM or GAMEMODE
GAMEMODE = GM or GAMEMODE

GM.Name = 'Fallout RPG'
GM.Author = 'Ozor'
GM.Email = 'N/A'
GM.Website = 'N/A'

DeriveGamemode('sandbox')

FO = FO or {}
--include(GM.FolderName..'/gamemode/database/mysql.lua')

function GM:Initialize()
	-- body
end

AddCSLuaFile(GM.FolderName..'/gamemode/config/cfg.lua')
include(GM.FolderName..'/gamemode/config/cfg.lua')

function FO.AddFile(i, v)
	if ( i and v ) then 
		if ( v == 'server' ) then
			if ( SERVER ) then
				include(i)
			end
		elseif ( v == 'client' ) then
			if ( SERVER ) then
				AddCSLuaFile(i)
			else
				include(i)
			end
		else
			AddCSLuaFile(i)
			include(i)
		end
	end
end

function FO.Inclide()
	local fil, fol = file.Find(GM.FolderName .. '/gamemode/modify/*', 'LUA')

	for _, dir in pairs(fol) do
		local d, f = file.Find(GM.FolderName .. '/gamemode/modify/'.. dir ..'/*', 'LUA')

		for k, v in pairs(f) do
			local files = file.Find(GM.FolderName ..'/gamemode/modify/'..dir..'/'..v..'/*.lua', 'LUA')

			for _, i in pairs(files) do
				FO.AddFile(GM.FolderName..'/gamemode/modify/'..dir..'/'..v..'/'..i, v)
			end
		end
	end
end

FO.Inclide()

AddCSLuaFile(GM.FolderName..'/gamemode/config/jobs.lua')
include(GM.FolderName..'/gamemode/config/jobs.lua')
