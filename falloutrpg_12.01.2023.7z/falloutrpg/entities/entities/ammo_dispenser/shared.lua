ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.Category = 'FO'

ENT.BaseHealth = 100
ENT.Cost = 100
ENT.Limit = 5
ENT.Owner = nil
ENT.Model = 'models/props_lab/reciever_cart.mdl'

ENT.PrintName = 'Ammo Dispenser'
ENT.Author = 'Ozor'
ENT.Purpose = 'Give Ammo'
ENT.Instruction = 'Place'
ENT.Spawnable = true