ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'

ENT.Category = 'Fallout RPG:Loot'
ENT.PrintName = 'Base Loot'
ENT.Author = 'Ozor'
ENT.Purpose = 'Give'
ENT.Instruction = 'Place'
ENT.Spawnable = false 
ENT.AdminSpawnable = false

ENT.Loot = true