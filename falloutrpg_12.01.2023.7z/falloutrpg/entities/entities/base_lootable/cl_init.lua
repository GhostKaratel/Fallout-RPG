include('shared.lua')

function ENT:Initialize()
    self.FO = {LOOT = {}}

    net.Start('ent_loot_request')
        net.WriteEntity(self)
    net.SendToServer()
end

net.Receive('ent_loot_request', function(len, ply)
    local classname = net.ReadString()
    local name = net.ReadString()
    local ent = net.ReadEntity()

    ent.classname = classname
    ent.Name = name
end)

function ENT:Draw()
    if self.classname and self:GetPos():Distance(LocalPlayer():GetPos()) < 400 then
        self:DrawModel()
    end
end