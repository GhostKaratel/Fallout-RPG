AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

util.AddNetworkString('ent_loot_request')

function ENT:Initialize()
    self.FO = {LOOT = {}}
    
    self:SetModel('models/hunter/blocks/cube025x025x025.mdl')

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:DropToFloor()
end

function ENT:SetInt(ent)
    local ENTdata = FO.LT.Lootable[ent]
    
    self.classname = ENTdata.classname
	self.Name = ENTdata.name
    
    self:SetModel(ENTdata.model)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:DropToFloor()

    local phys = self:GetPhysicsObject()

    if (IsValid(phys)) then
        phys:Wake()
    end

	timer.Create( self.Name, FO.LT.Timer, 0, function() 
		if IsValid(self) and self.Loot and #self.FO.LOOT < 3 then
			self:CreateLOOT() 
		end
	end )
end

net.Receive('ent_loot_request', function(len, ply)
    local ent = net.ReadEntity()
    if ent:GetClass() != 'base_lootable' then return end
    if ent.classname then
		net.Start('ent_loot_request')
            net.WriteString(ent.classname)
			net.WriteString(ent.Name)
			net.WriteEntity(ent)
		net.Send(ply)
    end
end)

function ENT:FOHasLoot(classname, amount, condition, price)
	local amount = amount or 0
	local has = false
	local hasAmount = false
	local found = 0
    
	for k,v in pairs(self.FO.LOOT) do
		if v.classname == classname and v.condition == condition and v.price == price then
			has =  true
			found = found + v.amount

            break
		end
	end

	if found >= tonumber(amount) then
		hasAmount = true
	end

	return has, hasAmount
end

function ENT:CreateLOOT()
	local key = FO.LT.Spawn[math.random( #FO.LT.Spawn )]
	local ITEMdata = FO.INV.Items[key]
	local entLOOT = self.FO.LOOT
	local chance = 0
	local amt = 1
	local cnd = 100

	if ITEMdata.type == 'weapon' then
		chance = math.random(1, 50)

		if chance > 40 then
			cnd = math.random(5, 75)
		else
			key = FO.LT.Spawn[math.random( #FO.LT.Spawn )]
		end
	elseif ITEMdata.type == 'apparel' then
		cnd = math.random(5, 75)
	elseif ITEMdata.type == 'aid' then
		amt = math.random(1, 2)
	elseif ITEMdata.type == 'misc' then
		amt = math.random(1, 4)
	elseif ITEMdata.type == 'ammo' then 
		amt = math.random(2, 15)
	end

    if !entLOOT[1] then
        table.insert(entLOOT, {
            classname = ITEMdata.classname, 
            amount = amt or 1,
            condition = cnd,
            price = ITEMdata.price
        })
    else
        for k, v in pairs(entLOOT) do 
            if v.classname == ITEMdata.classname and v.condition == cnd and v.price == ITEMdata.price then
                v.amount = v.amount + amt
                
                break
            elseif not self:FOHasLoot(ITEMdata.classname, ITEMdata.amount, cnd, ITEMdata.price) then
                table.insert(entLOOT, {
                    classname = ITEMdata.classname, 
                    amount = amt or 1,
                    condition = cnd,
                    price = ITEMdata.price
                })

                break
            end
        end
    end

	net.Start('inv_loot_give_cl')
		net.WriteTable(entLOOT)
		net.WriteEntity(self)
	net.Broadcast()
end

function ENT:Use(activator, caller)
    net.Start('inv_loot_panel')
        net.WriteEntity(self)
	net.Send(caller)
end
