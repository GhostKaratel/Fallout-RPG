include('shared.lua')

function ENT:Draw()
    local value = self:GetValue()
    
    if self:GetPos():Distance(LocalPlayer():GetPos()) < 400 then

        local Ang = LocalPlayer():GetAngles()

        Ang:RotateAroundAxis( Ang:Forward(), 90)
        Ang:RotateAroundAxis( Ang:Right(), 90)

        self:DrawModel()

        cam.IgnoreZ(true)

        cam.Start3D2D(self:GetPos()+self:GetUp()*5, Ang, 0.05)
            render.PushFilterMin(TEXFILTER.ANISOTROPIC)
                draw.InterfaceText( string.Comma(value), 'MONEY_TEXT', 'MONEY_TEXT_SHADOW', 0, 0, Color(255,255,255), 1, 1, Color(0, 0, 0) )
            render.PopFilterMin()
        cam.End3D2D()

        cam.IgnoreZ(false)
    end
end