function ENT:SetupDataTables()
    self:NetworkVar('Int', 0, 'Value')
end

ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.Category = 'FO'

ENT.PrintName = 'Money'
ENT.Author = 'Ozor'
ENT.Purpose = 'Give'
ENT.Instruction = 'Place'
ENT.Spawnable = false