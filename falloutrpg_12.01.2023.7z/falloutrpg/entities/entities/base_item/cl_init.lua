include('shared.lua')

function ENT:Initialize()
    net.Start('inv_item_request')
        net.WriteEntity(self)
    net.SendToServer()
end

net.Receive('inv_item_request', function(len, ply)
    local classname = net.ReadString()
    local amount = net.ReadInt(32)
    local condition = net.ReadFloat()
    local price = net.ReadInt(32)
    local ent = net.ReadEntity()

    ent.classname = classname
    ent.amount = amount
    ent.condition = condition
    ent.price = price
end)

function ENT:Draw()

    self:DrawModel()
    
    if self.classname and self:GetPos():Distance(LocalPlayer():GetPos()) < 400 then

        local ITEMdata = FO.INV.Items[self.classname]

        local Ang = LocalPlayer():GetAngles()

        Ang:RotateAroundAxis( Ang:Forward(), 90)
        Ang:RotateAroundAxis( Ang:Right(), 90)

        cam.IgnoreZ(true)

        cam.Start3D2D(self:GetPos()+self:GetUp()*5, Ang, 0.05)
            render.PushFilterMin(TEXFILTER.ANISOTROPIC)
               -- draw.InterfaceText( self.amount, 'MONEY_TEXT', 'MONEY_TEXT_SHADOW', 0, 0, Color(255,255,255), 1, 1, Color(0, 0, 0) )
            render.PopFilterMin()
        cam.End3D2D()

        cam.IgnoreZ(false)
    end
end