AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

util.AddNetworkString('inv_item_request')

function ENT:Initialize()
    
    self:SetModel('models/props_junk/wood_crate001a_damaged.mdl')

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:DropToFloor()
end

function ENT:SetItem(item)
    local ITEMdata = FO.INV.Items[item.classname]
    
    self.classname = item.classname
    self.amount = item.amount
    self.condition = item.condition
    self.price = item.price
    
    self:SetModel(ITEMdata.model)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:DropToFloor()

    local phys = self:GetPhysicsObject()

    if (IsValid(phys)) then
        phys:Wake()
    end
end

net.Receive('inv_item_request', function(len, ply)
    local ent = net.ReadEntity()
    if ent:GetClass() != 'base_item' then return end
    if ent.classname then
        net.Start('inv_item_request')
            net.WriteString(ent.classname)
            net.WriteInt(ent.amount, 32)
            net.WriteFloat(ent.condition)
            net.WriteInt(ent.price, 32)
            net.WriteEntity(ent)
        net.Send(ply)
    end
end)

function ENT:Use(activator, caller)
    if self.classname then
        caller:INVpickup(self.classname, self.amount, self.condition, self.price)
        self:Remove()
    end
end