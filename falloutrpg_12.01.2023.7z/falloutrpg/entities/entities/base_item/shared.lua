ENT.Type = 'anim'
ENT.Base = 'base_gmodentity'
ENT.Category = 'FO'

ENT.PrintName = 'Base inventory item'
ENT.Author = 'Ozor'
ENT.Purpose = 'Give'
ENT.Instruction = 'Place'
ENT.Spawnable = false

ENT.DropItem = true